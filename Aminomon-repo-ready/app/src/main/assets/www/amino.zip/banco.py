"""Question bank for Study mode: hand-written packs + generators built from the amino-acid data.

Every question is a dict: id, topic, level (1-3), q, options (4, shuffled when asked), answer (index),
why (explanation).  Static ids look like "s:enz:7"; generated ones like "g:pI:K" so a review card can
rebuild the exact same question later.
Facts follow standard textbooks (Lehninger / Voet / Clayden). Have a subject expert proof-read the packs
before release.
"""
import random

import datos

TOPICS = {
    "aa": "Amino acids",
    "props": "Charge, pKa & pI",
    "peptide": "Peptides & protein structure",
    "enz": "Enzymes & kinetics",
    "groups": "Functional groups",
    "stereo": "Stereochemistry",
    "mech": "Reaction mechanisms",
    "signal": "Cell signalling",
}
ORDER = list(TOPICS)
FREE_TOPICS = ("aa", "props")        # the rest are Pro when the paywall is switched on

# (topic, level, question, correct, [3 wrong], why)
_S = []


def Q(topic, level, q, ok, bad, why):
    _S.append((topic, level, q, ok, bad, why))


# ------------------------------------------------------------------ charge, pKa & pI
Q("props", 1, "At physiological pH (about 7.4), a free amino acid with a non-ionisable side chain (such as alanine) is mainly:",
  "a zwitterion (NH3+ and COO-)", ["a cation (NH3+ and COOH)", "an anion (NH2 and COO-)", "an uncharged molecule (NH2 and COOH)"],
  "The alpha-carboxyl (pKa ~2.3) has lost its proton and the alpha-amino group (pKa ~9.7) still holds one, so the molecule carries both charges and is neutral overall.")
Q("props", 1, "The isoelectric point (pI) of an amino acid is the pH at which:",
  "its net charge is zero", ["its carboxyl group is exactly half ionised", "it is most soluble in water", "it carries the maximum positive charge"],
  "At the pI the positive and negative charges balance. Solubility is usually lowest there, not highest.")
Q("props", 2, "Glycine has pK1 = 2.34 and pK2 = 9.60. Its isoelectric point is about:",
  "5.97", ["2.34", "7.00", "9.60"],
  "With no ionisable side chain, pI = (pK1 + pK2) / 2 = (2.34 + 9.60) / 2 = 5.97.")
Q("props", 2, "Aspartate has pK1 = 1.88, pKR = 3.65 and pK2 = 9.60. Its pI is about:",
  "2.77", ["5.74", "6.63", "3.65"],
  "The neutral form lies between the two lowest pKa values, so pI = (1.88 + 3.65) / 2 = 2.77.")
Q("props", 2, "Lysine has pK1 = 2.18, pK2 = 8.95 and pKR = 10.53. Its pI is about:",
  "9.74", ["5.57", "6.50", "10.53"],
  "The neutral form lies between the two highest pKa values, so pI = (8.95 + 10.53) / 2 = 9.74.")
Q("props", 2, "What is the predominant net charge of glycine at pH 12?",
  "-1", ["0", "+1", "-2"],
  "pH 12 is far above the amino group pKa (9.6), so NH3+ has lost its proton and only COO- carries a charge.")
Q("props", 2, "What is the predominant net charge of alanine at pH 1?",
  "+1", ["0", "-1", "+2"],
  "pH 1 is below the carboxyl pKa (2.3), so the carboxyl is protonated (neutral) and the amino group is NH3+.")
Q("props", 1, "In electrophoresis at a pH above its pI, an amino acid moves toward the:",
  "anode (+)", ["cathode (-)", "neither electrode", "both electrodes equally"],
  "Above the pI the molecule has a net negative charge, so it is attracted to the positive electrode.")
Q("props", 2, "When the pH equals the pKa of a group, the ratio [A-]/[HA] is:",
  "1 (half is ionised)", ["10", "0.1", "0"],
  "Henderson-Hasselbalch: pH = pKa + log([A-]/[HA]). If pH = pKa the log term is zero, so the ratio is 1.")
Q("props", 2, "A weak acid buffers best when the pH is:",
  "within about 1 unit of its pKa", ["at least 3 units above its pKa", "exactly 7", "at its pI"],
  "Near the pKa both the acid and its conjugate base are present in useful amounts.")
Q("props", 2, "Which side chain can act as a buffer near physiological pH?",
  "Histidine (imidazole, pKa ~6)", ["Lysine (pKa ~10.5)", "Aspartate (pKa ~3.7)", "Arginine (pKa ~12.5)"],
  "Histidine's pKa is the closest to 7, so it can donate and accept protons in the physiological range (for example in haemoglobin and enzyme active sites).")
Q("props", 2, "How many buffering regions does the titration curve of glycine show?",
  "2", ["1", "3", "4"],
  "Each ionisable group gives one buffering region: the alpha-carboxyl and the alpha-amino group.")
Q("props", 3, "At pH 7.0, what fraction of histidine side chains (pKa 6.0) is protonated?",
  "about 9%", ["about 50%", "about 91%", "about 1%"],
  "[A]/[HA] = 10^(7-6) = 10, so the protonated fraction is 1/(1+10) = 9%.")
Q("props", 3, "The alpha-carboxyl of a free amino acid (pKa ~2.3) is a stronger acid than a normal carboxylic acid (pKa ~4.8) because:",
  "the nearby positive NH3+ group stabilises the carboxylate", ["it is attached to an aromatic ring", "it forms a disulfide bond", "it is hydrophobic"],
  "The positively charged ammonium group withdraws electrons (inductive effect) and stabilises COO-.")
Q("props", 3, "A protein has pI = 8.5. In a buffer at pH 6.0 its net charge is:",
  "positive", ["negative", "zero", "impossible to tell"],
  "pH below the pI means the protein has gained protons and carries a net positive charge.")
Q("props", 1, "Which amino acids have an acidic (negatively charged at pH 7) side chain?",
  "Aspartate and glutamate", ["Lysine and arginine", "Serine and threonine", "Leucine and isoleucine"],
  "Asp and Glu have side-chain carboxyl groups (pKa about 3.7 and 4.2) that are deprotonated at pH 7.")
Q("props", 3, "In ion-exchange chromatography at pH 7, a protein with pI 5 will bind to:",
  "an anion exchanger (positively charged resin)", ["a cation exchanger (negatively charged resin)", "neither kind of resin", "both equally"],
  "At pH 7 (above its pI) the protein is negative, so it sticks to a positively charged resin such as DEAE.")

# ------------------------------------------------------------------ peptides & protein structure
Q("peptide", 1, "A peptide bond joins:",
  "the alpha-carboxyl of one amino acid to the alpha-amino group of the next, releasing water",
  ["two side chains, releasing CO2", "two carboxyl groups, releasing ammonia", "the side chains of two cysteines"],
  "It is a condensation reaction that forms an amide bond.")
Q("peptide", 1, "A peptide sequence is written from the:",
  "N-terminus to the C-terminus", ["C-terminus to the N-terminus", "middle outward", "side chain with the highest pKa"],
  "By convention the free amino end is on the left and the free carboxyl end on the right.")
Q("peptide", 2, "Why is the peptide bond planar and rigid?",
  "resonance gives the C-N bond partial double-bond character", ["it is a true double bond", "hydrogen bonds hold it flat", "the side chains force it flat"],
  "The nitrogen lone pair delocalises into the carbonyl, so rotation about C-N is restricted.")
Q("peptide", 2, "Most peptide bonds in proteins are in the trans form. Which residue is most likely to have a cis peptide bond?",
  "Proline", ["Glycine", "Leucine", "Serine"],
  "Proline's ring makes cis and trans nearly equal in energy.")
Q("peptide", 1, "In an alpha helix the backbone is stabilised by hydrogen bonds between:",
  "the C=O of residue i and the N-H of residue i+4", ["side chains of residues i and i+1", "adjacent strands", "two cysteine thiols"],
  "These bonds run parallel to the helix axis.")
Q("peptide", 2, "How many amino acid residues are there per turn of an alpha helix?",
  "3.6", ["2", "5.1", "10"], "The alpha helix has 3.6 residues per turn and a rise of 1.5 angstroms per residue.")
Q("peptide", 2, "Which residue is most often called a helix breaker?",
  "Proline", ["Alanine", "Leucine", "Glutamate"],
  "Proline has no backbone N-H to donate and its ring restricts the phi angle.")
Q("peptide", 2, "Glycine is common in tight turns and in collagen mainly because:",
  "its side chain is only a hydrogen, so it is very flexible and small", ["it is strongly hydrophobic", "it is positively charged", "it forms disulfide bonds"],
  "Collagen's triple helix needs a glycine at every third position because there is no room for a larger side chain.")
Q("peptide", 1, "Disulfide bonds in proteins form between:",
  "two cysteine side chains", ["two serine side chains", "lysine and aspartate", "two methionines"],
  "Oxidation of two thiol (-SH) groups gives cystine (-S-S-). They stabilise many secreted proteins.")
Q("peptide", 1, "The primary structure of a protein is:",
  "its amino acid sequence", ["its alpha helices and beta sheets", "its overall 3D fold", "its assembly of several subunits"],
  "Secondary = local folds, tertiary = overall fold of one chain, quaternary = several chains together.")
Q("peptide", 2, "Quaternary structure refers to:",
  "the association of several polypeptide chains", ["the order of residues", "hydrogen bonding in helices", "the fold of a single chain"],
  "Haemoglobin (four subunits) is a classic example.")
Q("peptide", 2, "In a soluble globular protein, hydrophobic residues are usually found:",
  "in the interior core", ["on the surface facing water", "only at the termini", "only in loops"],
  "The hydrophobic effect drives nonpolar side chains together, away from water.")
Q("peptide", 3, "Anfinsen's ribonuclease experiments showed that:",
  "the amino acid sequence contains the information for the native fold", ["proteins always need chaperones", "disulfide bonds are never reformed", "folding requires ATP"],
  "Denatured, reduced RNase refolded spontaneously to its active form.")
Q("peptide", 2, "Molecular chaperones mainly:",
  "help proteins fold and prevent aggregation", ["cut proteins into peptides", "add phosphate groups", "carry amino acids to ribosomes"],
  "Examples include Hsp70 and GroEL.")
Q("peptide", 2, "Heat denaturation of a protein usually breaks:",
  "non-covalent interactions, not peptide bonds", ["peptide bonds only", "all covalent bonds", "nothing at all"],
  "Hydrogen bonds, hydrophobic and ionic interactions are disrupted; the sequence stays intact.")
Q("peptide", 3, "A Ramachandran plot shows:",
  "allowed phi and psi backbone angles", ["the charge of each residue", "the rate of folding", "hydrogen-bond lengths"],
  "Steric clashes forbid most phi/psi combinations; helices and sheets occupy the allowed regions.")
Q("peptide", 1, "How many peptide bonds are in a tripeptide?",
  "2", ["1", "3", "4"], "A chain of n residues has n - 1 peptide bonds.")
Q("peptide", 3, "Collagen's triple helix is built from a repeating pattern of:",
  "Gly-X-Y, often with proline and hydroxyproline", ["Leu-Leu-Leu", "Cys-X-X-Cys", "Asp-Glu-Lys"],
  "Hydroxylation of proline needs vitamin C; without it collagen is unstable (scurvy).")
Q("peptide", 2, "In a parallel beta sheet, the neighbouring strands:",
  "run in the same N to C direction", ["run in opposite directions", "are joined by disulfide bonds only", "must be connected by a helix"],
  "Antiparallel strands run in opposite directions and have straighter hydrogen bonds.")

# ------------------------------------------------------------------ enzymes & kinetics
Q("enz", 1, "Enzymes speed up reactions by lowering the:",
  "activation energy", ["free-energy change (delta G) of the reaction", "equilibrium constant", "temperature of the cell"],
  "They stabilise the transition state; the overall delta G and equilibrium position do not change.")
Q("enz", 1, "An enzyme changes the equilibrium constant of a reaction:",
  "never; it only speeds up reaching equilibrium", ["always, in favour of products", "only at high temperature", "only for exergonic reactions"],
  "Catalysts speed up the forward and reverse reactions equally.")
Q("enz", 2, "Km is the substrate concentration at which:",
  "the rate is half of Vmax", ["the enzyme is denatured", "the rate equals Vmax", "no product is formed"],
  "Km is a measure of apparent affinity: a low Km means the enzyme reaches half-maximal rate at low substrate.")
Q("enz", 2, "Vmax is reached when:",
  "the enzyme is saturated with substrate", ["the substrate is absent", "the inhibitor concentration is highest", "the pH is neutral"],
  "At saturating substrate every active site is occupied, so the rate is limited by kcat x [E total].")
Q("enz", 2, "A competitive inhibitor changes the apparent kinetics by:",
  "raising Km and leaving Vmax unchanged", ["lowering Vmax and leaving Km unchanged", "lowering both Km and Vmax", "raising Vmax"],
  "It competes for the active site, so more substrate is needed to reach half-maximal rate, but enough substrate still reaches Vmax.")
Q("enz", 2, "A pure noncompetitive inhibitor changes the apparent kinetics by:",
  "lowering Vmax and leaving Km unchanged", ["raising Km and leaving Vmax unchanged", "raising both", "changing nothing"],
  "It binds equally to enzyme and enzyme-substrate complex at another site, reducing the amount of active enzyme.")
Q("enz", 3, "An uncompetitive inhibitor (binds only the enzyme-substrate complex) causes:",
  "a decrease in both Vmax and Km", ["an increase in Km only", "an increase in Vmax only", "no change in either"],
  "Parallel lines appear on a Lineweaver-Burk plot.")
Q("enz", 2, "Competitive inhibition can be overcome by:",
  "increasing the substrate concentration", ["raising the temperature to 80 degrees C", "adding more inhibitor", "lowering the pH to 1"],
  "Substrate outcompetes the inhibitor for the active site.")
Q("enz", 3, "On a Lineweaver-Burk (double-reciprocal) plot the y-intercept equals:",
  "1/Vmax", ["-1/Km", "Km", "Vmax"], "The x-intercept is -1/Km and the slope is Km/Vmax.")
Q("enz", 2, "The catalytic triad of chymotrypsin consists of:",
  "Ser, His and Asp", ["Cys, Lys and Glu", "Tyr, Arg and Gly", "Trp, Phe and Pro"],
  "His acts as a general base to make Ser a strong nucleophile; Asp orients His.")
Q("enz", 2, "A zymogen is:",
  "an inactive enzyme precursor activated by cleavage", ["a coenzyme from a vitamin", "an enzyme inhibitor", "a membrane receptor"],
  "Trypsinogen and pepsinogen prevent digestive enzymes from attacking the cells that make them.")
Q("enz", 2, "Allosteric enzymes typically show kinetics that are:",
  "sigmoidal (cooperative)", ["hyperbolic only", "linear", "independent of substrate"],
  "Substrate binding to one subunit changes the affinity of the others.")
Q("enz", 1, "An organic molecule that an enzyme needs for activity, such as NAD+, is called a:",
  "coenzyme", ["zymogen", "isozyme", "proenzyme"], "Metal ions are cofactors that are not coenzymes.")
Q("enz", 2, "NAD+ is made from which vitamin?",
  "Niacin (B3)", ["Riboflavin (B2)", "Thiamine (B1)", "Vitamin C"], "FAD comes from riboflavin (B2).")
Q("enz", 2, "The induced-fit model says that:",
  "binding of the substrate changes the shape of the enzyme to fit better", ["the active site never changes shape", "the enzyme is consumed in the reaction", "the substrate is a rigid key"],
  "Koshland's model refined the older lock-and-key idea.")
Q("enz", 3, "kcat/Km is called the:",
  "specificity constant (catalytic efficiency)", ["equilibrium constant", "dissociation constant of the inhibitor", "turnover time"],
  "It describes how well an enzyme converts substrate at low concentration; the upper limit is diffusion control, about 10^8 to 10^9 per M per s.")
Q("enz", 2, "Regulation by phosphorylation usually adds phosphate to:",
  "Ser, Thr or Tyr side chains", ["Gly, Ala or Val", "Leu or Ile", "only the N-terminus"],
  "Protein kinases transfer the gamma phosphate of ATP to these hydroxyl groups.")
Q("enz", 2, "Isozymes are:",
  "different enzymes that catalyse the same reaction", ["inactive enzyme forms", "enzymes without a cofactor", "the same enzyme in different species only"],
  "Lactate dehydrogenase (LDH) has heart and muscle isozymes with different kinetics.")
Q("enz", 3, "Transition-state analogues are very potent inhibitors because:",
  "enzymes bind the transition state more tightly than the substrate", ["they are covalent", "they denature the enzyme", "they have no charge"],
  "Binding energy is used to stabilise the transition state.")
Q("enz", 2, "In feedback inhibition the inhibitor is usually:",
  "the end product of the pathway acting on an early step", ["the substrate of the last step", "an unrelated hormone", "a heavy metal"],
  "This keeps the cell from over-producing a metabolite.")

# ------------------------------------------------------------------ functional groups
Q("groups", 1, "Which functional group does the side chain of serine contain?",
  "hydroxyl (-OH)", ["thiol (-SH)", "amide", "carboxyl"], "Threonine and tyrosine also have hydroxyl groups; tyrosine's is on an aromatic ring (phenol).")
Q("groups", 1, "Cysteine contains a:",
  "thiol (-SH)", ["hydroxyl", "thioether", "amine"], "Methionine has a thioether (C-S-C), not a thiol.")
Q("groups", 1, "An aldehyde differs from a ketone because the aldehyde carbonyl carbon:",
  "is bonded to at least one hydrogen (at the end of a chain)", ["has no oxygen", "is bonded to two oxygens", "is part of a ring only"],
  "Aldehydes are R-CHO; ketones are R-CO-R'.")
Q("groups", 1, "The functional group -COOH is a:",
  "carboxylic acid", ["ester", "amide", "ketone"], "Its conjugate base is a carboxylate (-COO-).")
Q("groups", 1, "Asparagine and glutamine side chains contain which group?",
  "amide", ["amine", "ester", "ketone"], "A carbonyl attached to nitrogen: -CO-NH2.")
Q("groups", 2, "An ester (R-COO-R') is formed from:",
  "a carboxylic acid and an alcohol", ["two amines", "an aldehyde and an amine", "two alkenes"], "Fischer esterification removes water.")
Q("groups", 2, "Phosphorylation of a protein adds phosphate to a hydroxyl group, forming a:",
  "phosphate ester", ["phosphate amide", "sulfate ether", "disulfide"], "ATP is the phosphate donor.")
Q("groups", 2, "Which of these is the strongest acid (typical pKa)?",
  "carboxylic acid (~4-5)", ["phenol (~10)", "alcohol (~16)", "amine N-H (~35)"],
  "A lower pKa means a stronger acid; carboxylates are stabilised by resonance.")
Q("groups", 2, "Amines are basic because:",
  "the nitrogen has a lone pair that can accept a proton", ["they contain oxygen", "they are aromatic", "they have a carbonyl"], "R-NH2 + H+ gives R-NH3+.")
Q("groups", 2, "The side chain of tyrosine contains a:",
  "phenol (aromatic hydroxyl)", ["thiol", "indole", "guanidinium"], "Its pKa is about 10.")
Q("groups", 2, "Tryptophan contains which ring system?",
  "indole", ["imidazole", "phenol", "pyrrolidine"], "Histidine has the imidazole; proline has the pyrrolidine ring.")
Q("groups", 2, "Arginine's side chain ends in a:",
  "guanidinium group (strongly basic, pKa ~12.5)", ["amide", "carboxylate", "imidazole"], "It is positively charged at all physiological pH values.")
Q("groups", 3, "Which of these can only accept, and not donate, a hydrogen bond?",
  "the oxygen of a ketone C=O", ["an alcohol O-H", "an amide N-H", "an ammonium N-H"], "A ketone oxygen has lone pairs but no hydrogen attached.")
Q("groups", 3, "An imine (Schiff base) forms when:",
  "an aldehyde or ketone reacts with a primary amine", ["an alcohol reacts with an acid", "two thiols are oxidised", "an ester is hydrolysed"],
  "Retinal binds a lysine of opsin this way, and pyridoxal phosphate binds enzymes the same way.")
Q("groups", 2, "The suffix -one in a systematic name indicates a:",
  "ketone", ["alcohol", "aldehyde", "ester"], "Alcohols end in -ol, aldehydes in -al, carboxylic acids in -oic acid.")
Q("groups", 3, "A thioester such as acetyl-CoA is useful in metabolism because it:",
  "readily transfers its acyl group (high-energy bond)", ["is very stable to water", "has no carbonyl group", "is always charged"],
  "The C-S bond has poorer resonance stabilisation than an oxygen ester, so acyl transfer is favourable.")

# ------------------------------------------------------------------ stereochemistry
Q("stereo", 1, "A chiral (stereogenic) carbon has:",
  "four different substituents", ["two identical substituents", "a double bond", "three substituents only"], "Such a carbon gives two non-superimposable mirror-image forms.")
Q("stereo", 1, "Which standard amino acid is achiral?",
  "Glycine", ["Alanine", "Serine", "Proline"], "Its side chain is a hydrogen, so the alpha carbon has two identical hydrogens.")
Q("stereo", 1, "Amino acids in proteins are almost always in the:",
  "L configuration", ["D configuration", "racemic form", "meso form"], "Ribosomes use only L-amino acids.")
Q("stereo", 2, "Enantiomers have:",
  "the same physical properties except the direction in which they rotate polarised light", ["different melting points", "different boiling points", "identical optical rotation"],
  "They also react differently in chiral environments such as enzymes.")
Q("stereo", 2, "A racemic mixture:",
  "contains equal amounts of two enantiomers and shows no optical rotation", ["contains only one enantiomer", "is a pure meso compound", "rotates light strongly"],
  "The rotations cancel.")
Q("stereo", 2, "Most L-amino acids have the (S) configuration. Which common one is (R)?",
  "Cysteine", ["Serine", "Alanine", "Lysine"],
  "In cysteine the CH2SH group outranks COOH in the CIP rules (S > O), which flips the descriptor; the spatial arrangement is the same as in the others.")
Q("stereo", 3, "At the alpha carbon of L-serine the CIP priority order is:",
  "NH3+ > COOH > CH2OH > H", ["COOH > NH3+ > CH2OH > H", "CH2OH > COOH > NH3+ > H", "NH3+ > CH2OH > COOH > H"],
  "N has the highest atomic number; COOH (O,O,O) outranks CH2OH (O,H,H).")
Q("stereo", 3, "How many stereocentres does isoleucine have?",
  "2", ["1", "3", "0"], "The alpha carbon and the beta carbon; threonine also has two. L-Ile is (2S,3S) and L-Thr is (2S,3R).")
Q("stereo", 3, "Diastereomers are stereoisomers that:",
  "are not mirror images of each other", ["are mirror images", "have the same configuration at every centre", "differ only in conformation"],
  "L-threonine and L-allo-threonine are an example.")
Q("stereo", 3, "A molecule with n stereocentres can have at most how many stereoisomers?",
  "2^n", ["n^2", "2n", "n!"], "So isoleucine, with two stereocentres, has up to four.")
Q("stereo", 2, "D-amino acids are found naturally in:",
  "bacterial cell-wall peptidoglycan", ["human haemoglobin", "all ribosomal proteins", "DNA"], "D-Ala and D-Glu are part of the peptidoglycan peptide chains.")
Q("stereo", 2, "Optical rotation is measured with a:",
  "polarimeter", ["spectrophotometer", "mass spectrometer", "calorimeter"], "The specific rotation is a physical constant of a chiral compound.")
Q("stereo", 3, "A meso compound:",
  "has stereocentres but is achiral because of an internal mirror plane", ["has no stereocentres", "is always a racemic mixture", "rotates light strongly"], "Meso-tartaric acid is the classic example.")
Q("stereo", 1, "The D/L system is based on the configuration of:",
  "glyceraldehyde", ["glucose in water", "cholesterol", "benzene"], "L-amino acids correspond to L-glyceraldehyde.")

# ------------------------------------------------------------------ reaction mechanisms
Q("mech", 1, "An SN2 reaction proceeds:",
  "in one step with inversion of configuration", ["through a carbocation with racemisation", "only on tertiary carbons", "without a nucleophile"],
  "The nucleophile attacks from the back side as the leaving group leaves (Walden inversion).")
Q("mech", 1, "An SN1 reaction proceeds through:",
  "a carbocation intermediate, giving racemisation at a stereocentre", ["a single concerted step", "a carbanion", "a free radical chain"],
  "The rate depends only on the substrate concentration.")
Q("mech", 2, "SN2 is favoured by:",
  "methyl or primary substrates, strong nucleophiles and polar aprotic solvents", ["tertiary substrates", "weak nucleophiles in water", "bulky substrates"],
  "Steric hindrance slows backside attack.")
Q("mech", 2, "SN1 is favoured by:",
  "tertiary substrates and polar protic solvents", ["methyl substrates", "strong nucleophiles in acetone", "primary substrates"],
  "Tertiary carbocations are stable, and protic solvents stabilise the ions.")
Q("mech", 2, "E2 elimination requires:",
  "a strong base and an anti-periplanar H and leaving group", ["a carbocation intermediate", "a weak base", "a syn arrangement"],
  "It is a one-step concerted reaction.")
Q("mech", 2, "Zaitsev's rule says that elimination mainly gives:",
  "the more substituted (more stable) alkene", ["the least substituted alkene", "a mixture of equal amounts", "an alkyne"], "Bulky bases can favour the Hofmann product instead.")
Q("mech", 2, "Which carbocation is the most stable?",
  "tertiary", ["secondary", "primary", "methyl"], "Alkyl groups stabilise the positive charge by hyperconjugation and induction.")
Q("mech", 2, "Nucleophilic acyl substitution goes through:",
  "a tetrahedral intermediate", ["a carbocation", "a carbanion on carbon-1", "a radical"], "The nucleophile adds to C=O, then the leaving group is expelled.")
Q("mech", 3, "Which carboxylic acid derivative is the least reactive toward nucleophiles?",
  "amide", ["acyl chloride", "anhydride", "ester"], "Reactivity order: acyl chloride > anhydride > ester > amide. Amide resonance is strong, which is why peptide bonds are stable.")
Q("mech", 2, "Peptide bond formation is best described as:",
  "a condensation (nucleophilic acyl substitution) releasing water", ["an oxidation", "an addition of water", "a free-radical coupling"], "In cells the carboxyl is activated first (as an aminoacyl-tRNA ester).")
Q("mech", 2, "A Grignard reagent reacting with a ketone gives, after work-up, a:",
  "tertiary alcohol", ["primary alcohol", "carboxylic acid", "alkane"], "The carbon nucleophile adds to the carbonyl carbon.")
Q("mech", 2, "Sodium borohydride (NaBH4) normally reduces:",
  "aldehydes and ketones to alcohols", ["esters to alcohols", "alkenes to alkanes", "amides to amines"], "LiAlH4 is stronger and also reduces esters and amides.")
Q("mech", 3, "The aldol reaction forms:",
  "a beta-hydroxy carbonyl compound", ["an ester", "an ether", "an alkyne"], "An enolate adds to another carbonyl; dehydration gives an enone.")
Q("mech", 3, "In a serine protease the first chemical step is:",
  "the active-site Ser oxygen attacks the peptide carbonyl, forming a tetrahedral intermediate", ["water attacks the amine", "His is oxidised", "the peptide bond is homolytically cleaved"],
  "This gives an acyl-enzyme intermediate; water then hydrolyses it.")
Q("mech", 2, "Base-promoted ester hydrolysis (saponification) is irreversible because:",
  "the product carboxylic acid is deprotonated to a carboxylate", ["water is not a nucleophile", "esters are inert", "the alcohol is destroyed"], "The carboxylate no longer reacts with the alcohol.")
Q("mech", 3, "Imine formation is fastest at about:",
  "pH 4 to 5", ["pH 1", "pH 7.4 exactly", "pH 13"], "Too acidic and the amine is protonated and not nucleophilic; too basic and the carbonyl is not activated.")
Q("mech", 2, "Markovnikov addition of HBr to propene gives mainly:",
  "2-bromopropane", ["1-bromopropane", "propane", "allyl bromide"], "H adds to the carbon with more hydrogens, giving the more stable secondary carbocation.")

# ------------------------------------------------------------------ cell signalling
Q("signal", 1, "G-protein-coupled receptors span the membrane how many times?",
  "7", ["1", "4", "12"], "They are also called seven-transmembrane receptors.")
Q("signal", 2, "An activated GPCR acts as a guanine nucleotide exchange factor, which means it:",
  "promotes GDP release and GTP binding on the G-protein alpha subunit", ["hydrolyses GTP", "phosphorylates the G protein", "cleaves the receptor"], "GTP-bound G-alpha then dissociates from G-beta-gamma.")
Q("signal", 2, "Gs activates adenylyl cyclase, which makes:",
  "cAMP, which activates protein kinase A", ["cGMP, which activates PKG", "IP3, which releases calcium", "ATP"], "Gi inhibits adenylyl cyclase.")
Q("signal", 2, "The Gq pathway activates phospholipase C-beta, producing:",
  "IP3 and DAG", ["cAMP and ATP", "cGMP and GTP", "PIP3 and Akt"], "IP3 releases Ca2+ from the ER; DAG activates protein kinase C.")
Q("signal", 2, "Ligand binding to a receptor tyrosine kinase typically causes:",
  "dimerisation and autophosphorylation on tyrosines", ["receptor degradation", "opening of an ion channel", "release of cAMP"], "Phosphotyrosines recruit SH2-domain adaptor proteins.")
Q("signal", 2, "Ras is active when it is bound to:",
  "GTP", ["GDP", "ATP", "cAMP"], "Ras is a small GTPase that starts the Raf-MEK-ERK (MAPK) kinase cascade.")
Q("signal", 2, "In insulin signalling, the insulin receptor leads via IRS and PI3K to:",
  "PIP3 and activation of Akt", ["cAMP and PKA", "IP3 and calcium", "NF-kB only"], "Akt promotes glucose uptake (GLUT4 translocation) and growth.")
Q("signal", 1, "Steroid hormones typically signal by:",
  "binding intracellular (nuclear) receptors that regulate transcription", ["binding GPCRs on the surface", "opening ion channels", "being degraded outside the cell"], "Their lipid nature lets them cross the plasma membrane.")
Q("signal", 2, "Cholera toxin causes diarrhoea by:",
  "ADP-ribosylating G-alpha-s and keeping it active, so cAMP stays high", ["blocking adenylyl cyclase", "degrading cAMP", "inhibiting Ras"], "High cAMP in intestinal cells drives chloride and water secretion.")
Q("signal", 2, "Protein phosphatases:",
  "remove phosphate groups and reverse kinase signals", ["add phosphate groups", "make ATP", "cut peptide bonds"], "Kinase-phosphatase balance sets the phosphorylation level.")
Q("signal", 2, "Which protein binds Ca2+ and then regulates many enzymes and kinases?",
  "calmodulin", ["ubiquitin", "actin", "haemoglobin"], "Ca2+/calmodulin activates CaM kinases.")
Q("signal", 3, "In a bacterial two-component system, the sensor histidine kinase:",
  "autophosphorylates on His and passes the phosphate to an Asp on the response regulator", ["makes cAMP", "cleaves the response regulator", "pumps protons"], "The phosphorylated response regulator usually controls gene expression.")
Q("signal", 2, "Quorum sensing lets bacteria:",
  "detect population density through secreted signal molecules", ["detect light", "sense their own pH only", "make antibodies"], "Autoinducers accumulate as the population grows.")
Q("signal", 3, "GTPase-activating proteins (GAPs):",
  "speed up GTP hydrolysis and switch G proteins off", ["exchange GDP for GTP", "add phosphates to receptors", "degrade GTP outside cells"], "Guanine exchange factors (GEFs) switch them on.")
Q("signal", 2, "A second messenger is:",
  "a small intracellular molecule that relays and amplifies a signal", ["a hormone made by the pituitary", "a receptor on the surface", "a transcription factor"], "Examples: cAMP, cGMP, IP3, DAG and Ca2+.")
Q("signal", 3, "GPCR desensitisation involves:",
  "phosphorylation by GRKs and binding of beta-arrestin", ["more G-protein binding", "cleavage by caspases", "dimerisation only"], "Arrestin blocks further G-protein coupling and can trigger internalisation.")
Q("signal", 2, "Nitric oxide signals mainly by activating:",
  "soluble guanylyl cyclase, producing cGMP", ["adenylyl cyclase", "phospholipase C", "tyrosine kinases"], "NO diffuses across membranes and binds the haem of guanylyl cyclase.")
Q("signal", 3, "Why can a single activated receptor produce a large response?",
  "each step (receptor, G protein, enzyme) activates many molecules of the next, amplifying the signal", ["the receptor is never switched off", "ligands are consumed", "ions bypass the cascade"], "Amplification is a key feature of cascades.")


def _opts(rng, ok, bad):
    o = [ok] + list(bad)
    rng.shuffle(o)
    return o, o.index(ok)


def _static(i, rng):
    t, lv, q, ok, bad, why = _S[i]
    o, a = _opts(rng, ok, bad)
    return dict(id="s:%s:%d" % (t, i), topic=t, level=lv, q=q, options=o, answer=a, why=why)


# ------------------------------------------------------------------ generated from the amino-acid table
A = datos.AMINOACIDOS
CODES = datos.ORDEN


def _name(c):
    return A[c]["nombre"]


def _pick_other(rng, pool, ok, n=3):
    pool = [p for p in pool if p != ok]
    rng.shuffle(pool)
    return pool[:n]


GEN_KINDS = ("three", "one", "group", "pi", "side", "codon", "hydro", "ess", "size", "name3")


def _gen(kind, arg, rng):
    """Build a generated question. arg is a one-letter amino-acid code (or a group key)."""
    a = A[arg]
    q = None
    if kind == "three":
        q = ("Which amino acid has the three-letter code %s?" % a["tres"], _name(arg),
             [_name(c) for c in _pick_other(rng, CODES, arg)], "%s is %s (%s)." % (a["tres"], a["nombre"], arg), 1)
    elif kind == "one":
        ok = a["una"]
        q = ("What is the one-letter code of %s?" % a["nombre"], ok,
             _pick_other(rng, CODES, ok), "%s = %s = %s." % (a["nombre"], a["tres"], ok), 1)
    elif kind == "name3":
        q = ("What is the three-letter code of %s?" % a["nombre"], a["tres"],
             [A[c]["tres"] for c in _pick_other(rng, CODES, arg)], "%s is %s." % (a["nombre"], a["tres"]), 1)
    elif kind == "group":
        names = datos.GRUPOS
        ok = names[a["grupo"]]
        q = ("To which group does %s belong, by its side chain?" % a["nombre"], ok,
             [names[g] for g in _pick_other(rng, list(names), a["grupo"])],
             "%s is %s. %s" % (a["nombre"], ok.lower(), a["pista"]), 1)
    elif kind == "pi":
        pi = a["pi"]
        wrong = set()
        for d in (-3.0, -1.7, 1.5, 3.1, 4.0, -2.2):
            v = round(pi + d, 2)
            if 0.5 < v < 13 and abs(v - pi) > 0.9:
                wrong.add("%.2f" % v)
        wrong = sorted(wrong)
        rng.shuffle(wrong)
        pks = ", ".join("%.2f" % p for p in (a["pk1"], a["pk2"], a["pkr"]) if p is not None)
        q = ("What is the isoelectric point (pI) of %s?" % a["nombre"], "%.2f" % pi, wrong[:3],
             "pKa values: %s. The pI is the average of the two pKa values around the neutral form." % pks, 2)
    elif kind == "side":
        ch = datos.carga_cadena(arg, 7.4)
        word = "positive" if ch > 0.5 else "negative" if ch < -0.5 else "neutral (mostly uncharged)"
        q = ("At pH 7.4, the side chain of %s is mainly:" % a["nombre"], word,
             [w for w in ("positive", "negative", "neutral (mostly uncharged)") if w != word] + ["it has no side chain"],
             "Side-chain pKa: %s. Charge at pH 7.4 is about %+.2f." % (datos.PKA_IONIZABLES.get(arg, ("none",))[0], ch), 2)
    elif kind == "codon":
        cod = a["codones"][rng.randrange(len(a["codones"]))]
        q = ("Which amino acid is encoded by the codon %s?" % cod, _name(arg),
             [_name(c) for c in _pick_other(rng, CODES, arg)], "%s codes for %s (%s). It has %d codon(s)." % (cod, a["nombre"], a["tres"], len(a["codones"])), 2)
    elif kind == "hydro":
        pair = [arg, rng.choice([c for c in CODES if c != arg])]
        hi = max(pair, key=lambda c: A[c]["hidropatia"])
        q = ("Which is more hydrophobic on the Kyte-Doolittle scale: %s or %s?" % (_name(pair[0]), _name(pair[1])),
             _name(hi), [_name(c) for c in pair if c != hi] + ["they are equal", "cannot be compared"],
             "Hydropathy values: %s %.1f, %s %.1f. Higher means more hydrophobic." % (_name(pair[0]), A[pair[0]]["hidropatia"], _name(pair[1]), A[pair[1]]["hidropatia"]), 2)
    elif kind == "ess":
        ess = a["nutricion"].lower().startswith("essential")
        q = ("Is %s an essential amino acid for adults?" % a["nombre"], "yes" if ess else "no (the body can make it)",
             ["no (the body can make it)" if ess else "yes", "only in infants" if not ess else "only in plants", "only in the liver"],
             "%s is classed as: %s." % (a["nombre"], a["nutricion"].lower()), 2)
    elif kind == "size":
        pair = [arg, rng.choice([c for c in CODES if c != arg])]
        big = max(pair, key=lambda c: A[c]["masa"])
        q = ("Which free amino acid has the larger molar mass: %s or %s?" % (_name(pair[0]), _name(pair[1])), _name(big),
             [_name(c) for c in pair if c != big] + ["they are identical", "depends on pH"],
             "%s %.1f g/mol; %s %.1f g/mol." % (_name(pair[0]), A[pair[0]]["masa"], _name(pair[1]), A[pair[1]]["masa"]), 2)
    if not q:
        return None
    text, ok, bad, why, lv = q
    bad = [b for b in bad if b != ok]
    seen, uniq = set(), []
    for b in bad:
        if b not in seen:
            seen.add(b); uniq.append(b)
    while len(uniq) < 3:
        uniq.append("none of these")
    o, ans = _opts(rng, ok, uniq[:3])
    topic = "props" if kind in ("pi", "side") else "aa"
    return dict(id="g:%s:%s" % (kind, arg), topic=topic, level=lv, q=text, options=o, answer=ans, why=why)


def build(qid, seed=None):
    """Rebuild a question from its id (options are shuffled with a seed derived from the id)."""
    rng = random.Random(("%s|%s" % (qid, seed)) if seed is not None else qid)
    kind, _, rest = qid.partition(":")
    if kind == "s":
        _, _, idx = rest.partition(":")
        return _static(int(idx), rng)
    k2, _, arg = rest.partition(":")
    return _gen(k2, arg, rng)


def all_ids(topic=None):
    ids = []
    for i, s in enumerate(_S):
        if topic is None or s[0] == topic:
            ids.append("s:%s:%d" % (s[0], i))
    if topic in (None, "aa", "props"):
        for kind in GEN_KINDS:
            t = "props" if kind in ("pi", "side") else "aa"
            if topic not in (None, t):
                continue
            for c in CODES:
                if kind == "side" and c not in datos.PKA_IONIZABLES:
                    continue
                ids.append("g:%s:%s" % (kind, c))
    return ids


def pick(rng, topics, n, avoid=()):
    """n different question ids from the topics, roughly balanced across them."""
    pools = {t: [i for i in all_ids(t) if i not in avoid] for t in topics}
    for p in pools.values():
        rng.shuffle(p)
    out = []
    order = list(topics)
    while len(out) < n and any(pools.values()):
        for t in order:
            if pools[t] and len(out) < n:
                out.append(pools[t].pop())
        rng.shuffle(order)
    return out


COUNT_STATIC = len(_S)
