"""Class tools without a server: teachers make assignment codes, students send back result codes."""
import base64
import binascii
import json
import random
import zlib

import motor


def _pack(prefix, obj):
    raw = zlib.compress(json.dumps(obj, separators=(",", ":")).encode("utf-8"), 9)
    body = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    return "%s.%s.%04x" % (prefix, body, binascii.crc32(body.encode()) & 0xFFFF)


def _unpack(prefix, code):
    """Returns the object, or None if the code is damaged or of another kind."""
    try:
        code = "".join(code.split())
        p, body, chk = code.split(".")
        if p != prefix or "%04x" % (binascii.crc32(body.encode()) & 0xFFFF) != chk.lower():
            return None
        body += "=" * (-len(body) % 4)
        return json.loads(zlib.decompress(base64.urlsafe_b64decode(body)).decode("utf-8"))
    except (ValueError, zlib.error, binascii.Error):
        return None


def make_assignment(title, qids):
    return _pack("AMN1", {"id": "%06x" % random.randrange(1 << 24), "t": title[:40], "q": qids,
                          "d": motor.hoy().isoformat()})


def read_assignment(code):
    a = _unpack("AMN1", code)
    if a and isinstance(a.get("q"), list) and a["q"]:
        return a
    return None


def make_result(assign, name, items, secs):
    """items: [(qid, topic, ok)]"""
    per = {}
    for _, t, ok in items:
        v = per.setdefault(t, [0, 0])
        v[0] += 1
        v[1] += 1 if ok else 0
    return _pack("AMR1", {"id": assign["id"], "n": name[:24], "s": sum(1 for i in items if i[2]),
                          "of": len(items), "sec": int(secs), "per": per, "d": motor.hoy().isoformat()})


def read_result(code):
    r = _unpack("AMR1", code)
    return r if r and "n" in r and "s" in r else None


def table(results):
    """Text table and CSV from a list of result dicts."""
    rows = sorted(results, key=lambda r: (-r["s"], r["sec"]))
    lines = ["%-3s %-16s %7s %6s" % ("#", "Name", "Score", "Time")]
    csv = ["name,score,out_of,percent,seconds,date"]
    for i, r in enumerate(rows, 1):
        pct = round(100 * r["s"] / r["of"]) if r["of"] else 0
        lines.append("%-3d %-16s %3d/%-3d %5ds" % (i, r["n"][:16], r["s"], r["of"], r["sec"]))
        csv.append('"%s",%d,%d,%d,%d,%s' % (r["n"].replace('"', "'"), r["s"], r["of"], pct, r["sec"], r["d"]))
    if rows:
        avg = sum(r["s"] / r["of"] for r in rows if r["of"]) / len(rows)
        lines.append("")
        lines.append("Class average: %d%% (%d students)" % (round(100 * avg), len(rows)))
    return "\n".join(lines), "\n".join(csv)
