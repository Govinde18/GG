"""Study engine: saved progress, Leitner spaced repetition, streak with freeze, badges, exam stats."""
import datetime
import json
import os
import random
import time

PATH = os.path.join(os.path.expanduser("~"), ".amino_study.json")
INTERVALS = [0, 1, 3, 7, 16, 35]        # days per Leitner box
GOAL = 5                                  # answers that make a streak day
EXAM_N = 20
EXAM_SECONDS = 20 * 60


def hoy():
    try:
        off = int(os.environ.get("AMN_TZ_MIN", ""))
        return (datetime.datetime.utcnow() + datetime.timedelta(minutes=off)).date()
    except ValueError:
        return datetime.date.today()


def _d(s):
    return datetime.date.fromisoformat(s)


BADGES = [
    ("first", "First steps", "Answer your first question.", lambda s: _tot(s) >= 1),
    ("h50", "Warm-up", "Answer 50 questions.", lambda s: _tot(s) >= 50),
    ("h250", "Dedicated", "Answer 250 questions.", lambda s: _tot(s) >= 250),
    ("h1000", "Scholar", "Answer 1000 questions.", lambda s: _tot(s) >= 1000),
    ("st3", "3-day streak", "Study 3 days in a row.", lambda s: s["streak"]["best"] >= 3),
    ("st7", "Week warrior", "Study 7 days in a row.", lambda s: s["streak"]["best"] >= 7),
    ("st30", "Monthly master", "Study 30 days in a row.", lambda s: s["streak"]["best"] >= 30),
    ("daily", "Daily quizzer", "Finish a daily quiz.", lambda s: bool(s["daily"])),
    ("daily10", "Quiz habit", "Finish 10 daily quizzes.", lambda s: len(s["daily"]) >= 10),
    ("exam", "Exam taker", "Finish an exam.", lambda s: bool(s["exams"])),
    ("exam90", "Top marks", "Score 90% or more in an exam.", lambda s: any(e["pct"] >= 90 for e in s["exams"])),
    ("box5", "Long memory", "Get 10 cards to the top Leitner box.", lambda s: sum(1 for c in s["cards"].values() if c["box"] >= 5) >= 10),
    ("alltopics", "All-rounder", "Answer 10+ questions in every topic.", lambda s: len(s["topic"]) >= 8 and all(v[0] >= 10 for v in s["topic"].values())),
]
BADGE_INFO = {b[0]: (b[1], b[2]) for b in BADGES}


def _tot(s):
    return sum(v[0] for v in s["topic"].values())


def _new():
    return {"v": 1, "name": "", "cards": {}, "days": {}, "topic": {}, "daily": {}, "exams": [],
            "badges": [], "streak": {"count": 0, "best": 0, "freeze": 0, "last": ""},
            "last_topic": "", "classes": [], "summary": {}}


def load():
    try:
        with open(PATH, encoding="utf-8") as f:
            s = json.load(f)
        base = _new()
        base.update(s)
        return base
    except (OSError, ValueError):
        return _new()


def save(s):
    s["summary"] = summary(s)
    try:
        with open(PATH, "w", encoding="utf-8") as f:
            json.dump(s, f)
    except OSError:
        pass


def streak_now(s):
    """Streak as it should be shown today (drops to 0 if the chain is already broken)."""
    st = s["streak"]
    if not st["last"]:
        return 0
    gap = (hoy() - _d(st["last"])).days
    if gap <= 1 or (gap == 2 and st["freeze"] > 0):
        return st["count"]
    return 0


def due_ids(s):
    t = hoy().isoformat()
    ids = [q for q, c in s["cards"].items() if c["due"] <= t]
    ids.sort(key=lambda q: (s["cards"][q]["due"], s["cards"][q]["box"]))
    return ids


def today_count(s):
    return s["days"].get(hoy().isoformat(), {}).get("n", 0)


def _touch_streak(s):
    st, t = s["streak"], hoy()
    if st["last"] == t.isoformat():
        return None
    gap = (t - _d(st["last"])).days if st["last"] else None
    msg = None
    if gap == 1:
        st["count"] += 1
    elif gap == 2 and st["freeze"] > 0:
        st["freeze"] -= 1
        st["count"] += 1
        msg = "Streak freeze used - your streak survived!"
    else:
        st["count"] = 1
    st["last"] = t.isoformat()
    st["best"] = max(st["best"], st["count"])
    if st["count"] % 7 == 0 and st["freeze"] < 2:
        st["freeze"] += 1
        msg = "You earned a streak freeze!"
    return msg


def record(s, qid, topic, ok):
    """Register one answer. Returns a list of notices (new badge, streak news...)."""
    t = hoy().isoformat()
    notes = []
    day = s["days"].setdefault(t, {"n": 0, "ok": 0})
    day["n"] += 1
    day["ok"] += 1 if ok else 0
    tv = s["topic"].setdefault(topic, [0, 0])
    tv[0] += 1
    tv[1] += 1 if ok else 0
    s["last_topic"] = topic
    c = s["cards"].get(qid) or {"box": 0, "due": t, "seen": 0, "ok": 0}
    c["seen"] += 1
    c["ok"] += 1 if ok else 0
    c["box"] = min(5, c["box"] + 1) if ok else 0
    c["due"] = (hoy() + datetime.timedelta(days=INTERVALS[c["box"]])).isoformat()
    s["cards"][qid] = c
    if day["n"] == GOAL:
        m = _touch_streak(s)
        notes.append("Daily goal reached! Streak: %d day(s)." % s["streak"]["count"])
        if m:
            notes.append(m)
    notes += _check_badges(s)
    return notes


def _check_badges(s):
    out = []
    for bid, title, desc, test in BADGES:
        if bid not in s["badges"] and test(s):
            s["badges"].append(bid)
            out.append("Badge unlocked: %s" % title)
    return out


def finish_daily(s, score, total):
    t = hoy().isoformat()
    s["daily"][t] = {"score": score, "of": total}
    return _check_badges(s)


def daily_ids(topics_free_only=False):
    """Same 5 questions for everybody on a given day."""
    import banco
    rng = random.Random(int(hoy().strftime("%Y%m%d")) * 7 + 1)
    tp = [t for t in banco.ORDER if not topics_free_only or t in banco.FREE_TOPICS]
    return banco.pick(rng, tp, 5)


def finish_exam(s, items, secs, name="Exam"):
    """items: [(qid, topic, ok)]"""
    n = len(items)
    good = sum(1 for _, _, ok in items if ok)
    per = {}
    for _, t, ok in items:
        v = per.setdefault(t, [0, 0])
        v[0] += 1
        v[1] += 1 if ok else 0
    rec = {"date": hoy().isoformat(), "n": n, "ok": good, "pct": round(100 * good / n) if n else 0,
           "secs": int(secs), "per": per, "name": name}
    s["exams"] = (s["exams"] + [rec])[-12:]
    return rec, _check_badges(s)


def weak_topics(s, minimum=3):
    """Topics sorted by accuracy, lowest first (only topics with enough answers)."""
    out = [(v[1] / v[0], t, v[0]) for t, v in s["topic"].items() if v[0] >= minimum]
    out.sort()
    return [(t, round(100 * a), n) for a, t, n in out]


def summary(s):
    t = hoy()
    return {"streak": streak_now(s), "due": len(due_ids(s)), "last": s["last_topic"],
            "today": today_count(s), "goal": GOAL, "freeze": s["streak"]["freeze"],
            "date": t.isoformat(), "answered": _tot(s), "badges": len(s["badges"])}
