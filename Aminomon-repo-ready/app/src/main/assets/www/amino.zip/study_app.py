"""Aminomon Study: daily quiz, spaced review, topic practice, exams, progress, class tools."""
import curses
import json
import os
import random
import time

import banco
import clase
import dibujo as d
import motor

try:
    import js
except ImportError:           # desktop test
    js = None

PRO = os.environ.get("AMN_PRO", "1") != "0"     # billing is not wired: this only unlocks/locks content
ESC = d.ESC


def _letters():
    return "ABCD"


def _topic_ok(t):
    return PRO or t in banco.FREE_TOPICS


def header(win, title, right=""):
    h, w = win.getmaxyx()
    d.put(win, 0, 1, " STUDY ", d.c("titulo", curses.A_BOLD | curses.A_REVERSE))
    d.put(win, 0, 10, title[: w - 12 - len(right)], d.c("texto", curses.A_BOLD))
    if right:
        d.put(win, 0, w - len(right) - 1, right, d.c("tenue"))


def ask_question(win, q, head, right="", feedback=True, extra=None):
    """Show one question; returns (ok, chosen) or (None, None) if the player leaves with Esc."""
    h, w = win.getmaxyx()
    win.erase()
    d.reiniciar_regiones()
    header(win, head, right)
    y = 2
    for ln in d.envolver(q["q"], w - 4):
        d.put(win, y, 2, ln, d.c("texto", curses.A_BOLD))
        y += 1
    y += 1
    pos = []
    for i, o in enumerate(q["options"]):
        lines = d.envolver(o, w - 10)[:2]
        pos.append((y, len(lines)))
        d.put(win, y, 2, " %s " % "ABCD"[i], d.c("titulo", curses.A_BOLD | curses.A_REVERSE))
        for j, ln in enumerate(lines):
            d.put(win, y + j, 7, ln, d.c("texto"))
        d.region(y, 1, len(lines), w - 2, str(i + 1))
        y += len(lines) + 1
    d.put(win, h - 1, 1, "[1-4] answer   [Esc] leave", d.c("tenue"))
    d.boton(win, h - 1, w - 9, "Leave", ESC, "tenue")
    win.refresh()
    while True:
        k = d.tecla(win)
        if k == ESC:
            return None, None
        if isinstance(k, str) and k in "1234" and k:
            c = int(k) - 1
            break
        if isinstance(k, str) and k.lower() in "abcd" and len(k) == 1:
            c = "abcd".index(k.lower())
            break
    ok = c == q["answer"]
    _sound("correcto" if ok else "error")
    if not feedback:
        return ok, c
    for i, (py, n) in enumerate(pos):
        col = "bien" if i == q["answer"] else ("mal" if i == c else "oscuro")
        d.put(win, py, 2, " %s " % "ABCD"[i], d.c(col, curses.A_BOLD | curses.A_REVERSE))
        for j, ln in enumerate(d.envolver(q["options"][i], w - 10)[:2]):
            d.put(win, py + j, 7, ln, d.c(col))
    ey = y
    d.put(win, ey, 2, "Correct!" if ok else "Not quite.", d.c("bien" if ok else "mal", curses.A_BOLD))
    for ln in d.envolver(q["why"], w - 4)[: max(1, h - ey - 3)]:
        ey += 1
        d.put(win, ey, 2, ln, d.c("tenue"))
    d.reiniciar_regiones()
    d.pantalla_completa(win, "\n")
    d.put(win, h - 1, 1, " " * (w - 2))
    d.put(win, h - 1, 1, "[Enter] next", d.c("tenue"))
    d.boton(win, h - 1, w - 9, "Next", "\n", "titulo")
    win.refresh()
    d.tecla(win)
    return ok, c


def _sound(n):
    try:
        import sonido
        sonido.reproducir(n)
    except Exception:
        pass


def _run(win, s, qids, head, feedback=True, timer=None):
    """Ask questions in order. Returns [(qid, topic, ok)] and the seconds used."""
    out, t0 = [], time.monotonic()
    notes = []
    for i, qid in enumerate(qids):
        q = banco.build(qid)
        if not q:
            continue
        right = "%d/%d" % (i + 1, len(qids))
        if timer:
            left = max(0, timer - int(time.monotonic() - t0))
            right = "%d:%02d  %s" % (left // 60, left % 60, right)
            if left <= 0:
                break
        ok, _ = ask_question(win, q, head, right, feedback)
        if ok is None:
            break
        out.append((qid, q["topic"], ok))
        notes += motor.record(s, qid, q["topic"], ok)
        motor.save(s)
        motor_notes(win, notes)
        notes = []
    return out, time.monotonic() - t0


def motor_notes(win, notes):
    """One popup for everything that happened (goal reached, streak, badges)."""
    if notes:
        _sound("logro" if any("Badge" in n for n in notes) else "nivel")
        d.popup(win, "\n".join(notes), "Nice!", 54)
    return []


def card(out, title, streak, bars=None, note=""):
    if not js or not hasattr(js, "gvCard"):
        return
    good = sum(1 for o in out if o[2])
    js.gvCard(json.dumps({"title": title, "big": "%d/%d" % (good, len(out)),
                          "sub": "%d%% correct" % (round(100 * good / len(out)) if out else 0),
                          "bars": bars or [], "streak": streak, "note": note}))


def _bars(out):
    per = {}
    for _, t, ok in out:
        v = per.setdefault(t, [0, 0])
        v[0] += 1
        v[1] += 1 if ok else 0
    return [[banco.TOPICS[t][:22], round(100 * v[1] / v[0])] for t, v in per.items()][:7]


def result_screen(win, s, out, title, secs, share=True, extra_lines=()):
    h, w = win.getmaxyx()
    good = sum(1 for o in out if o[2])
    pct = round(100 * good / len(out)) if out else 0
    while True:
        win.erase()
        d.reiniciar_regiones()
        header(win, title)
        d.put(win, 2, 2, "Score: %d / %d  (%d%%)" % (good, len(out), pct), d.c("titulo", curses.A_BOLD))
        d.put(win, 3, 2, "Time: %d:%02d" % (secs // 60, secs % 60), d.c("tenue"))
        y = 5
        bars = _bars(out)
        for lab, p in bars:
            d.put(win, y, 2, lab.ljust(24), d.c("texto"))
            d.barra(win, y, 27, 30, p, 100, d.c("bien" if p >= 70 else "titulo" if p >= 40 else "mal"))
            d.put(win, y, 58, "%3d%%" % p, d.c("texto"))
            y += 1
        weak = [b for b in sorted(bars, key=lambda b: b[1]) if b[1] < 70][:2]
        if weak:
            d.put(win, y + 1, 2, "Review next: " + ", ".join(b[0] for b in weak), d.c("mal"))
        for ln in extra_lines:
            y += 1
            d.put(win, y + 1, 2, ln, d.c("tenue"))
        bt = [("Review mistakes", "m", "titulo", any(not o[2] for o in out))]
        if share:
            bt.append(("Share result", "s", "titulo"))
        bt.append(("Done", "\n", "tenue"))
        d.fila_botones(win, h - 3, 2, bt)
        win.refresh()
        k = d.tecla(win)
        if d.es(k, "m") and any(not o[2] for o in out):
            for qid, t, ok in [o for o in out if not o[2]]:
                q = banco.build(qid)
                ask_question(win, q, "Mistake review", "", True)
        elif d.es(k, "s") and share:
            card(out, title, motor.streak_now(s), bars)
        elif k in d.ENTER or k == ESC:
            return


def daily(win, s):
    t = motor.hoy().isoformat()
    ids = motor.daily_ids(not PRO)
    if t in s["daily"]:
        r = s["daily"][t]
        d.popup(win, "You already finished today's quiz: %d/%d. A new one arrives tomorrow. Practise a topic meanwhile!" % (r["score"], r["of"]), "Daily quiz", 56)
        return
    out, secs = _run(win, s, ids, "Daily quiz")
    if len(out) == len(ids):
        notes = motor.finish_daily(s, sum(1 for o in out if o[2]), len(out))
        motor.save(s)
        motor_notes(win, notes)
        result_screen(win, s, out, "Daily quiz", int(secs))


def review(win, s):
    ids = motor.due_ids(s)[:15]
    if not ids:
        d.popup(win, "Nothing to review right now. Cards you miss come back sooner; cards you know come back after 1, 3, 7, 16 and 35 days.", "Review queue", 58)
        return
    out, secs = _run(win, s, ids, "Review queue")
    if out:
        result_screen(win, s, out, "Review", int(secs), share=False)


def practice(win, s):
    names = []
    for t in banco.ORDER:
        n = len(banco.all_ids(t))
        v = s["topic"].get(t)
        acc = " %d%%" % round(100 * v[1] / v[0]) if v and v[0] else ""
        names.append("%-30s %3d q%s%s" % (banco.TOPICS[t], n, acc, "" if _topic_ok(t) else "  [Pro]"))
    i = d.menu(win, "Choose a topic", names + ["Mixed (all topics)"], ancho=62)
    if i is None:
        return
    if i < len(banco.ORDER):
        t = banco.ORDER[i]
        if not _topic_ok(t):
            d.popup(win, "This topic is part of Pro. Pro is not available yet in this build.", "Pro topic", 50)
            return
        topics = [t]
    else:
        topics = [t for t in banco.ORDER if _topic_ok(t)]
    ids = banco.pick(random.Random(), topics, 10)
    out, secs = _run(win, s, ids, "Practice")
    if out:
        result_screen(win, s, out, "Practice", int(secs))


def exam_ids(topics):
    return banco.pick(random.Random(), topics, motor.EXAM_N)


def exam(win, s, ids=None, title="Exam", name=None):
    if ids is None:
        ids = exam_ids([t for t in banco.ORDER if _topic_ok(t)])
    if not d.popup(win, "%d questions, %d minutes. No feedback until the end. Good luck!" % (len(ids), motor.EXAM_SECONDS // 60), title, 56):
        pass
    out, secs = _run(win, s, ids, title, feedback=False, timer=motor.EXAM_SECONDS)
    if not out:
        return None
    rec, notes = motor.finish_exam(s, out, secs, title)
    motor.save(s)
    motor_notes(win, notes)
    result_screen(win, s, out, title, int(secs))
    return out, secs


def progress(win, s):
    h, w = win.getmaxyx()
    st = s["streak"]
    page = 0
    while True:
        win.erase()
        d.reiniciar_regiones()
        header(win, "Progress")
        d.put(win, 2, 2, "Streak: %d day(s)   Best: %d   Freezes: %d" % (motor.streak_now(s), st["best"], st["freeze"]), d.c("titulo", curses.A_BOLD))
        d.put(win, 3, 2, "Answered: %d   Today: %d/%d" % (motor._tot(s), motor.today_count(s), motor.GOAL), d.c("tenue"))
        y = 5
        for t in banco.ORDER:
            v = s["topic"].get(t, [0, 0])
            p = round(100 * v[1] / v[0]) if v[0] else 0
            d.put(win, y, 2, banco.TOPICS[t][:26].ljust(26), d.c("texto"))
            d.barra(win, y, 29, 24, p, 100, d.c("bien" if p >= 70 else "titulo"))
            d.put(win, y, 55, "%3d%% (%d)" % (p, v[0]), d.c("tenue"))
            y += 1
        y += 1
        d.put(win, y, 2, "Badges %d/%d" % (len(s["badges"]), len(motor.BADGES)), d.c("titulo", curses.A_BOLD))
        y += 1
        for bid, title, desc, _ in motor.BADGES:
            if y >= h - 2:
                break
            got = bid in s["badges"]
            d.put(win, y, 2, ("* " if got else "- ") + title, d.c("bien" if got else "oscuro"))
            d.put(win, y, 22, desc[: w - 24], d.c("tenue" if got else "oscuro"))
            y += 1
        d.fila_botones(win, h - 1, 2, [("Back", "\n", "tenue")])
        win.refresh()
        k = d.tecla(win)
        if k in d.ENTER or k == ESC:
            return


def read_text(win, label, hint):
    """Ask for pasted text through the page's input box; returns the string or None."""
    if js and hasattr(js, "gvAsk"):
        js.gvAsk(label, hint)
    h, w = win.getmaxyx()
    buf = ""
    while True:
        win.erase()
        header(win, label)
        d.put(win, 3, 2, hint, d.c("tenue"))
        d.put(win, 5, 2, "Received %d characters." % len(buf), d.c("texto"))
        d.put(win, h - 1, 1, "[Enter] done  [Esc] cancel", d.c("tenue"))
        win.refresh()
        k = d.tecla(win, True)
        if k == ESC:
            return None
        if k in d.ENTER:
            return buf.strip()
        if k in (curses.KEY_BACKSPACE, 127, "\x7f", "\b"):
            buf = buf[:-1]
        elif isinstance(k, str) and len(k) == 1 and k.isprintable():
            buf += k


def show(title, text):
    if js and hasattr(js, "gvShow"):
        js.gvShow(title, text)


def class_tools(win, s):
    while True:
        i = d.menu(win, "Class tools", ["I am a student: join an assignment", "I am a teacher: create an assignment",
                                        "I am a teacher: collect results", "How it works"], ancho=52)
        if i is None:
            return
        if i == 3:
            d.popup(win, "No accounts, no server. The teacher makes an assignment code and shares it (chat, board). Students paste it, take the quiz, and send back a result code. The teacher pastes the result codes to get a table and CSV. Codes can be forged by a determined student, so use them for practice, not for grades that matter.", "How it works", 66)
        elif i == 0:
            code = read_text(win, "Paste assignment code", "Paste the code your teacher gave you.")
            a = clase.read_assignment(code or "")
            if not a:
                d.popup(win, "That code is not valid. Check that you copied all of it.", "Oops", 50)
                continue
            name = (read_text(win, "Your name", "Type your name, then press Enter.") or "").strip() or "Student"
            res = exam(win, s, a["q"], a["t"] or "Assignment")
            if res:
                out, secs = res
                rc = clase.make_result(a, name, out, secs)
                s["classes"] = (s["classes"] + [a["id"]])[-20:]
                motor.save(s)
                show("Send this result code to your teacher", rc)
        elif i == 1:
            tp = d.menu(win, "Assignment topic", [banco.TOPICS[t] for t in banco.ORDER] + ["Mixed"], ancho=40)
            if tp is None:
                continue
            topics = [banco.ORDER[tp]] if tp < len(banco.ORDER) else list(banco.ORDER)
            n = [5, 10, 15, 20][d.menu(win, "How many questions?", ["5", "10", "15", "20"], ancho=34) or 0]
            ids = banco.pick(random.Random(), topics, n)
            title = (banco.TOPICS[banco.ORDER[tp]] if tp < len(banco.ORDER) else "Mixed") + " " + motor.hoy().isoformat()
            show("Assignment code - share with your class", clase.make_assignment(title, ids))
        elif i == 2:
            results = {}
            while True:
                code = read_text(win, "Paste result code %d" % (len(results) + 1), "Paste one student result code. Press Enter with nothing pasted to finish.")
                if not code:
                    break
                r = clase.read_result(code)
                if not r:
                    d.popup(win, "That result code is not valid.", "Oops", 44)
                    continue
                results[(r["id"], r["n"])] = r
            if results:
                text, csv = clase.table(list(results.values()))
                show("Class results", text + "\n\n--- CSV ---\n" + csv)


def home(win, s):
    pos = 0
    while True:
        sm = motor.summary(s)
        opts = ["Daily quiz  (%s)" % ("done" if sm["date"] in s["daily"] else "5 questions"),
                "Review queue  (%d due)" % sm["due"],
                "Practice by topic",
                "Exam mode  (%d q, %d min)" % (motor.EXAM_N, motor.EXAM_SECONDS // 60),
                "Progress & badges",
                "Class tools",
                "Back to home"]
        win.erase()
        header(win, "Streak %d  |  today %d/%d" % (sm["streak"], sm["today"], sm["goal"]))
        pos = d.menu(win, "Aminomon Study", opts, ancho=48, inicial=pos, clic_fuera=False)
        if pos is None or pos == 6:
            return
        {0: daily, 1: review, 2: practice, 3: exam, 4: progress, 5: class_tools}[pos](win, s)
        motor.save(s)


def main(win):
    curses.curs_set(0)
    d.init_colores()
    win.keypad(True)
    d.iniciar_raton(True)
    home(win, motor.load())
