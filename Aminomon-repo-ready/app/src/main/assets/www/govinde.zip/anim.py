"""Animations: title, the cascade that plays after a pathway is deduced, drifting ligands."""
import curses
import random
import time

import dibujo as d
import sound

LOGO = [
    r"  ___  _____   _____ _  _ ___  ___  ",
    r" / __|/ _ \ \ / /_ _| \| |   \| __| ",
    r"| (_ | (_) \ V / | || .` | |) | _|  ",
    r" \___|\___/ \_/ |___|_|\_|___/|___/ ",
]


def key_waiting(win):
    win.nodelay(True)
    try:
        k = win.get_wch()
    except curses.error:
        k = None
    win.nodelay(False)
    return k is not None


def title_intro(win, frames=34):
    """Ligands rain down, bind receptors on a membrane and the logo appears. Any key skips."""
    alto, ancho = win.getmaxyx()
    rng = random.Random()
    mem_y = alto // 2 + 6
    parts = [[rng.randrange(ancho), rng.randrange(-alto, 0), rng.choice("•∙°")] for _ in range(26)]
    names = ["NP", "ARO", "POL", "POS", "agua", "titulo"]
    x0 = (ancho - len(LOGO[0])) // 2
    y0 = max(1, alto // 2 - 9)
    for f in range(frames):
        t0 = time.monotonic()
        win.erase()
        for p in parts:
            p[1] += 1
            if p[1] >= mem_y - 1:
                p[0], p[1] = rng.randrange(ancho), rng.randrange(-8, 0)
                sound.play("blip", rng.randrange(0, 300))
            if 0 <= p[1] < alto and 0 <= p[0] < ancho - 1:
                d.put(win, p[1], p[0], p[2], d.c(rng.choice(names)))
        recept = "Y" if f % 4 < 2 else "y"
        for x in range(0, ancho - 1, 6):
            d.put(win, mem_y, x, recept, d.c("POL", curses.A_BOLD))
        d.put(win, mem_y + 1, 0, "═" * (ancho - 1), d.c("agua"))
        reveal = int((f + 1) / frames * (len(LOGO[0]) + 6))
        for i, l in enumerate(LOGO):
            d.put(win, y0 + i, x0, l[:reveal], d.c(["NP", "ARO", "POL", "POS"][i], curses.A_BOLD))
        win.refresh()
        if key_waiting(win):
            return
        d.pausa(70, t0)


def cascade(win, p):
    """After a correct deduction: a phosphate hops down the chain, lighting up each event."""
    alto, ancho = win.getmaxyx()
    n = len(p["steps"])
    w = ancho - 12
    sound_on = True
    for i in range(n + 1):
        for sub in range(3 if i else 1):
            t0 = time.monotonic()
            win.erase()
            d.reiniciar_regiones()
            d.put(win, 0, 1, f"CASCADE  ·  {p['name']}", d.c("titulo", curses.A_BOLD))
            d.put(win, 1, 1, f"Signal: {p['trigger']}", d.c("agua"))
            y = 3
            for k in range(n):
                lit = k < i
                head = k == i - 1
                attr = d.c("bien", curses.A_BOLD) if head else d.c("texto") if lit else d.c("oscuro")
                mark = "(P)" if lit else "   "
                d.put(win, y, 2, f"{mark} {p['actors'][k]}", d.c("titulo", curses.A_BOLD) if lit else d.c("oscuro"))
                if lit:
                    d.put(win, y, 34, p["steps"][k][: max(10, ancho - 36)], attr)
                y += 1
                if k < n - 1:
                    travelling = (k == i - 1 and sub < 2) and i > 0
                    d.put(win, y, 4, "▼" if travelling and sub == 1 else "│",
                          d.c("titulo", curses.A_BOLD) if travelling else d.c("tenue"))
                    y += 1
            if i == n:
                d.put(win, y + 1, 2, "=> " + p["outcome"], d.c("bien", curses.A_BOLD))
            d.put(win, alto - 1, 1, "Press any key to skip", d.c("tenue"))
            win.refresh()
            if key_waiting(win):
                return
            d.pausa(150 if i < n else 700, t0)
        if 0 < i <= n:
            sound.play("blip", 40 * i)
    sound.play("good")


class Ligands:
    """Drifting signal molecules on extracellular-matrix tiles."""

    def __init__(self, world, count=90, seed=3):
        self.w = world
        self.rng = random.Random(seed)
        import world as W
        self.tiles = [(x, y) for y in range(W.H) for x in range(W.W) if world.g[y][x] == W.ECM]
        self.items = [list(self.rng.choice(self.tiles)) + [self.rng.choice("•∙°"), self.rng.choice(
            ["POS", "NEG", "POL", "titulo", "agua"])] for _ in range(count)]
        self.W = W

    def tick(self, near):
        px, py = near
        for it in self.items:
            if abs(it[0] - px) > 45 or abs(it[1] - py) > 30:
                continue
            dx, dy = self.rng.choice(((1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)))
            x, y = it[0] + dx, it[1] + dy
            if 0 <= x < self.W.W and 0 <= y < self.W.H and self.w.g[y][x] == self.W.ECM:
                it[0], it[1] = x, y

    def at(self):
        return {(it[0], it[1]): (it[2], it[3]) for it in self.items}
