"""Pathway Atlas: which cells run which pathways (names stay hidden until the cell is unlocked)."""
import cells
import dibujo as d
import pathways


def show(win, j):
    rows = []
    for p in pathways.ALL:
        home = p["cell"]
        known = home in j["cells"]
        name = p["name"] if known else "???"
        where = [cells.CELLS[home]["name"]] + [cells.CELLS[c]["name"] for c in cells.ALSO.get(p["id"], [])]
        places = ", ".join(where) if known else cells.CELLS[home]["kind"]
        rows.append(f"{name:<34} {places}")
    d.menu(win, "Pathway Atlas: where each pathway works", rows, ancho=min(110, win.getmaxyx()[1] - 2),
           ayuda="Not every cell has every pathway: unlock cells to reveal more.")
