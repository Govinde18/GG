"""Boss stressors: one per stage. Several stresses hit in a row and you answer each with the right pathway,
with a limited number of lives. Winning refills every organelle and pays well."""
import random

import cells
import dibujo as d
import logic
import pathways
import quiz
import save
import sound
import upgrades

BOSSES = [
    dict(id="boss_gut", stage=1, cell="ecoli", pos=(-6, -5), lives=5, name="The Gut Gauntlet",
         intro="You are flushed from the warm gut into the cold outside world. In a single hour, E. coli is hit "
               "by every stress at once. Answer each one with the pathway that handles it.",
         rounds=[("envz_ompr", "Salt crashes in as the medium turns to brine."),
                 ("sos_response", "Ultraviolet light slashes the chromosome."),
                 ("trp_operon", "Tryptophan runs out and protein synthesis stalls."),
                 ("lac_operon", "Glucose is gone and only lactose remains."),
                 ("chemotaxis", "A scent of food drifts past in the dark. Swim towards it!")],
         fact="E. coli copes with osmotic shock, DNA damage and famine with separate signalling and regulation systems."),
    dict(id="boss_night", stage=2, cell="cyano", pos=(-5, -3), lives=5, name="The Long Night",
         intro="The sun sets on a crowded pond. Microbes starve, shout to each other and race to keep their clocks. "
               "Survive the night.",
         rounds=[("light_reactions", "Dawn: light floods the thylakoids and must be turned into chemical energy."),
                 ("calvin_cycle", "ATP and NADPH are plentiful and CO2 is in the air: build sugar."),
                 ("kai_clock", "Night falls. The cell must keep a 24 hour beat without light."),
                 ("com_quorum", "A neighbouring Bacillus culture is dense. The pheromone is piling up."),
                 ("sporulation_phosphorelay", "The food has gone. Build a spore before it is too late.")],
         fact="Bacteria sense light, density and starvation with phosphorylation relays and clocks."),
    dict(id="boss_famine", stage=3, cell="yeast", pos=(0, -5), lives=5, name="The Great Famine",
         intro="The vat runs dry. Oxygen vanishes, amino acids vanish, proteins misfold. Yeast has a nucleus now: "
               "use it.",
         rounds=[("fermentation", "Oxygen is gone but sugar remains. NADH has to be recycled."),
                 ("gcn4_starvation", "Uncharged tRNAs pile up. The cell must rebuild its amino acid supply."),
                 ("autophagy", "TORC1 falls silent. Recycle your own organelles."),
                 ("upr", "Misfolded proteins clog the ER."),
                 ("pheromone_mapk", "Despite everything, a mating partner calls.")],
         fact="Yeast links starvation sensing, translation control, recycling and ER stress to survive."),
    dict(id="boss_rogue", stage=4, cell="fibroblast", pos=(6, 2), lives=4, name="The Rogue Cell",
         intro="A cell in the tissue has stopped listening to the rules: it grows without permission, resists "
               "death and ignores repair. Stop it, pathway by pathway.",
         rounds=[("gpcr_camp_pka", "Adrenaline floods the tissue and receptors fire."),
                 ("rtk_ras_mapk", "A growth factor shouts: divide, divide, divide."),
                 ("wnt_bcatenin", "A Wnt signal tells the cell to switch on its growth genes."),
                 ("p53_damage", "Double-strand breaks appear in the nucleus."),
                 ("intrinsic_apoptosis", "The damage cannot be repaired. Cytochrome c leaks out."),
                 ("ubiquitin_proteasome", "Clean up: tag the damaged proteins for destruction.")],
         fact="Cancer is often a story of growth pathways that stay on and checkpoints that fail."),
    dict(id="boss_storm", stage=5, cell="muscle", pos=(8, -3), lives=4, name="The Metabolic Storm",
         intro="A big meal, a sprint, a fright, a stimulated synapse: the whole body signals at once. Every "
               "specialist must do its job in time.",
         rounds=[("gsis", "Blood glucose spikes after a meal."),
                 ("insulin_glycogen", "Insulin reaches the liver."),
                 ("srebp_cholesterol", "The liver senses low sterol and must make more."),
                 ("synaptic_transmission", "A nerve impulse reaches a terminal."),
                 ("ltp", "The same synapse is stimulated strongly and repeatedly."),
                 ("ec_coupling", "A motor neuron fires onto the muscle fibre."),
                 ("glucagon_glycogenolysis", "The sprint is long. Blood sugar falls and glucagon rises.")],
         fact="Hormones and neurotransmitters coordinate the specialist cells into one body."),
]
BY_ID = {b["id"]: b for b in BOSSES}


def ready(j, b):
    """The boss only appears when you know every pathway it will test."""
    return (b["id"] not in j["bosses"] and cells.CELLS[b["cell"]] and b["cell"] in j["cells"]
            and all(pid in j["solved"] for pid, _ in b["rounds"]))


def fight(win, j, b):
    """Returns 'won', 'lost' or 'left'."""
    d.popup(win, b["intro"] + f"\n\n{len(b['rounds'])} stresses, {b['lives']} lives. Esc leaves the fight.",
            f"BOSS: {b['name']}", ancho=70, attr=d.c("mal"))
    lives, missed = b["lives"], []
    solved = [x for x in j["solved"] if x in pathways.PATH]
    sound.play("hazard")
    for i, (pid, text) in enumerate(b["rounds"], 1):
        p = pathways.PATH[pid]
        pool = [x for x, _ in b["rounds"] if x != pid] + [x for x in solved if x != pid]
        wrong = [pathways.PATH[x]["name"] for x in dict.fromkeys(pool)][:3]
        random.shuffle(wrong)
        ok = quiz.ask(win, f"{b['name']} · {i}/{len(b['rounds'])} · lives {'♥' * lives}", text +
                      "\n\nWhich pathway answers this?", p["name"], wrong, f"{p['name']}: {p['outcome']}.",
                      allow_exit=True)
        if ok is None:
            return "left"
        if ok:
            logic.weak_ok(j, pid)
            sound.play("good")
        else:
            lives -= 1
            missed.append(pid)
            logic.weak_add(j, pid, 2)
            sound.play("bad")
            if lives <= 0:
                d.popup(win, "The stress overwhelms you and you retreat. It will be here when you are ready. "
                             "Your mistakes are added to your review list (key R).", "Retreat", attr=d.c("mal"))
                return "lost"
    j["bosses"].append(b["id"])
    j["dex"]["bosses"].append(b["id"])
    logic.gain(j, {m: 3 for m in cells.MATERIALS})
    j["insight"] += 3
    for uid in j["upgrades"]:
        j["charges"][uid] = upgrades.UPGRADES[uid]["max"]
    save.count(j, "bosses")
    sound.play("win")
    d.popup(win, f"You survived {b['name']}!\n\n{b['fact']}\n\nReward: +3 of every material, +3 Insight, and "
                 "every organelle you own is fully recharged.", "Boss defeated", ancho=72, attr=d.c("bien"))
    return "won"
