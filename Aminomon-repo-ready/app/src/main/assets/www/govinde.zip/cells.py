"""Cells, stages, materials and the story. All content is data: add a cell or a
stage here and its pathways to a paths_*.py file and the game picks them up."""

MATERIALS = ["ATP", "Nucleotides", "Amino acids", "Sugar", "Lipids", "NADPH"]
SHORT = {"ATP": "ATP", "Nucleotides": "NT", "Amino acids": "AA", "Sugar": "Sug",
         "Lipids": "Lip", "NADPH": "NADPH"}

# material a pathway kind consumes when you run its experiment (stage 1 is free)
KIND_COST = {"signalling": "ATP", "energy": "ATP", "degradation": "ATP",
             "regulation": "Nucleotides", "synthesis": "Amino acids"}

STAGES = {
    1: dict(name="Stage 1: The Bacterium", domain="Prokaryote", pass_pct=60, lives=None, decoys=0,
            star_mistakes=3, title="Phage Apprentice",
            intro="Govinde is a tiny phage with a big secret. He has slipped into an E. coli cell. "
                  "Here every pathway is forgiving: wrong guesses never hurt, so just learn."),
    2: dict(name="Stage 2: Specialist Microbes", domain="Prokaryote", pass_pct=70, lives=None, decoys=1,
            star_mistakes=2, title="Microbe Whisperer",
            intro="More bacteria, new talents. Some of the pieces you are offered now do not belong, "
                  "and you will need materials you can only make in the cells you already know."),
    3: dict(name="Stage 3: The First Nucleus", domain="Eukaryote", pass_pct=75, lives=6, decoys=2,
            star_mistakes=2, title="Nuclear Navigator",
            intro="Yeast has a nucleus, an ER and a vacuole. Signals now travel between compartments, "
                  "and from here on a pathway can fall apart if you make too many mistakes."),
    4: dict(name="Stage 4: The Animal Cell", domain="Eukaryote", pass_pct=80, lives=4, decoys=2,
            star_mistakes=1, title="Signal Strategist",
            intro="Welcome to a multicellular animal. Receptors, second messengers, kinase cascades, "
                  "cell death: crosstalk is everywhere and mistakes are costly."),
    5: dict(name="Stage 5: Specialist Cells", domain="Eukaryote", pass_pct=85, lives=3, decoys=3,
            star_mistakes=1, title="Master of Messengers",
            intro="Liver, pancreas, neuron and muscle: the same toolkit, specialised. No room for "
                  "sloppy reading now."),
}
FINAL = dict(name="Govinde's Grand Ultimatum", pass_pct=85, title="Protocol Complete")

CELLS = {
    "ecoli": dict(name="E. coli", stage=1, kind="Bacterium (Gram-negative)",
                  blurb="A gut bacterium and the workhorse of molecular biology.",
                  makes=["ATP", "Nucleotides"], cost={},
                  order=["glycolysis", "lac_operon", "trp_operon", "chemotaxis", "envz_ompr", "sos_response"]),
    "bacillus": dict(name="Bacillus subtilis", stage=2, kind="Bacterium (Gram-positive)",
                     blurb="A soil bacterium that survives famine by making spores.",
                     makes=["Amino acids", "Lipids"], cost={"ATP": 3, "Nucleotides": 2},
                     order=["com_quorum", "sporulation_phosphorelay"]),
    "cyano": dict(name="Cyanobacterium", stage=2, kind="Photosynthetic bacterium",
                  blurb="Makes its own sugar from light and keeps a circadian clock.",
                  makes=["Sugar", "NADPH"], cost={"ATP": 3, "Amino acids": 2},
                  order=["light_reactions", "calvin_cycle", "kai_clock"]),
    "yeast": dict(name="Yeast", stage=3, kind="Single-celled eukaryote",
                  blurb="Your first nucleus, ER and vacuole: a model for every animal cell.",
                  makes=["ATP", "Amino acids"], cost={"Sugar": 3, "NADPH": 2, "Amino acids": 2},
                  order=["fermentation", "pheromone_mapk", "gcn4_starvation", "upr", "autophagy"]),
    "fibroblast": dict(name="Animal cell (fibroblast)", stage=4, kind="Animal cell",
                       blurb="A connective-tissue cell that listens to growth factors and hormones.",
                       makes=["Lipids", "Amino acids"], cost={"Sugar": 4, "Lipids": 3, "Nucleotides": 3},
                       order=["gpcr_camp_pka", "rtk_ras_mapk", "pi3k_akt", "gpcr_plc_ip3", "wnt_bcatenin",
                              "p53_damage", "intrinsic_apoptosis", "ubiquitin_proteasome"]),
    "hepatocyte": dict(name="Hepatocyte (liver)", stage=5, kind="Metabolic specialist",
                       blurb="Keeps blood sugar steady and makes cholesterol.",
                       makes=["Sugar", "Lipids"], cost={"Sugar": 4, "Amino acids": 4, "NADPH": 3},
                       order=["glucagon_glycogenolysis", "insulin_glycogen", "srebp_cholesterol"]),
    "beta_cell": dict(name="Pancreatic beta cell", stage=5, kind="Endocrine specialist",
                      blurb="Measures blood glucose and releases insulin.",
                      makes=["ATP", "Sugar"], cost={"Sugar": 4, "ATP": 4, "Lipids": 3},
                      order=["gsis"]),
    "neuron": dict(name="Neuron", stage=5, kind="Excitable specialist",
                   blurb="Passes signals across synapses and remembers.",
                   makes=["ATP", "Nucleotides"], cost={"ATP": 5, "Lipids": 4, "Amino acids": 4},
                   order=["synaptic_transmission", "ltp"]),
    "phage": dict(name="Govinde's Capsid", stage=5, kind="Bacteriophage lambda",
                  blurb="The phage's own secret: a genetic switch between sleeping and bursting.",
                  makes=["Nucleotides", "Amino acids"], cost={"Nucleotides": 4, "Amino acids": 4},
                  order=["lambda_switch"]),
    "muscle": dict(name="Skeletal muscle fibre", stage=5, kind="Contractile specialist",
                   blurb="Turns an electrical signal into force.",
                   makes=["ATP", "Sugar"], cost={"ATP": 5, "Amino acids": 4, "Sugar": 4},
                   order=["ec_coupling"]),
}
CELL_ORDER = [c for c in CELLS if c != "phage"] + ["phage"]

# pathways that also operate in other cells (shown in the Codex and the Atlas)
ALSO = {
    "glycolysis": ["bacillus", "cyano", "yeast", "fibroblast", "hepatocyte", "beta_cell", "neuron", "muscle"],
    "envz_ompr": ["bacillus", "cyano"],
    "chemotaxis": ["bacillus"],
    "sos_response": ["bacillus", "phage"],
    "pheromone_mapk": ["fibroblast"],
    "autophagy": ["fibroblast", "hepatocyte", "neuron", "muscle"],
    "gpcr_camp_pka": ["hepatocyte", "beta_cell", "neuron", "muscle"],
    "rtk_ras_mapk": ["hepatocyte", "beta_cell", "neuron", "muscle"],
    "pi3k_akt": ["hepatocyte", "beta_cell", "muscle"],
    "gpcr_plc_ip3": ["hepatocyte", "beta_cell", "neuron", "muscle"],
    "p53_damage": ["hepatocyte", "beta_cell", "muscle"],
    "intrinsic_apoptosis": ["hepatocyte", "beta_cell", "neuron", "muscle"],
    "ubiquitin_proteasome": ["yeast", "hepatocyte", "beta_cell", "neuron", "muscle"],
    "upr": ["fibroblast", "hepatocyte", "beta_cell"],
    "calvin_cycle": [],
}

GOVINDE = dict(
    name="Govinde",
    intro=[
        "Hello, little cell. I am Govinde, a bacteriophage, and yes, I am the one who just injected "
        "himself into you. Relax: I am a harmless phage. I do not break cells, I study them.",
        "Every cell is a city of signals. Something outside whispers, a receptor listens, a chain of "
        "molecules passes the message, and the cell changes what it does. These chains are called "
        "pathways. They can signal, build, break down or regulate.",
        "Your job is to DEDUCE each pathway: I will give you the trigger and the result, and you must "
        "assemble the events in between, in the right order. Read my Codex first, because I give "
        "hints for every page you read.",
        "We start in a bacterium and travel towards the complexity of eukaryotes. You can always go back "
        "to earlier cells to collect raw materials for later ones. At the end of each stage I will "
        "hold an Ultimatum, and only players who actually read my Codex will pass it.",
    ],
    stage_start={
        2: "Two new microbes! A soil bacterium and a photosynthesiser. Choose which to enter first.",
        3: "A nucleus! Signals now cross membranes and compartments. Time to sharpen up.",
        4: "A whole animal cell. Hormones, growth factors and the machinery of life and death.",
        5: "The specialists. Same molecules, different jobs. This is where it all comes together.",
    },
    ending=[
        "You have deduced every pathway and passed every test. But before you go, there is something I have "
        "been hiding from you...",
    ],
)
