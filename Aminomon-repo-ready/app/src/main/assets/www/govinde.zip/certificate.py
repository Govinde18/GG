"""A shareable certificate: shown on screen and saved as an HTML page and a text file."""
import html
import os
import webbrowser

import cells
import dibujo as d
import logic
import pathways
import quests
import sound
import upgrades

RANKS = [(1.0, "Grand Protocol Master"), (0.9, "Master of Messengers"), (0.75, "Signal Strategist"),
         (0.5, "Pathway Pilot"), (0.0, "Signal Seeker")]


def stats(j):
    n = len(pathways.ALL)
    stars = logic.total_stars(j)
    ratio = stars / (3 * n)
    rank = next(r for lim, r in RANKS if ratio >= lim - 1e-9)
    return dict(
        name=j.get("player") or "Anonymous cell", solved=len(j["solved"]), total=n, stars=stars,
        max_stars=3 * n, rank=rank, ults=len(j["ultimatums"]) + int(j["final"]), ults_total=len(cells.STAGES) + 1,
        quests=len(j["quests"]), quests_total=len(quests.QUESTS), upgrades=len(j["upgrades"]),
        upgrades_total=len(upgrades.UPGRADES), hazards=j["stats"].get("hazards", 0),
        seals=len(j["seals"]), ending=j.get("ending") or "undecided")


def share_text(s):
    return (f"I finished The Govinde Protocol: {s['solved']}/{s['total']} cell-signalling pathways deduced, "
            f"{s['stars']}/{s['max_stars']} stars, rank '{s['rank']}'. From bacteria to neurons, with a phage "
            f"as my guide. #CellSignalling #Biology #Govinde")


def text_card(s):
    w = 62
    rows = ["CERTIFICATE OF THE GOVINDE PROTOCOL", "", f"awarded to  {s['name']}", "",
            f"Rank: {s['rank']}", f"Pathways deduced: {s['solved']}/{s['total']}",
            f"Stars: {s['stars']}/{s['max_stars']}", f"Ultimatums passed: {s['ults']}/{s['ults_total']}",
            f"Crosstalk quests: {s['quests']}/{s['quests_total']}",
            f"Organelles found: {s['upgrades']}/{s['upgrades_total']}",
            f"Stressors answered: {s['hazards']}", f"Govinde's choice: {s['ending']}"]
    out = ["+" + "=" * (w - 2) + "+"]
    for r in rows:
        out.append("| " + r.center(w - 4) + " |")
    out.append("+" + "=" * (w - 2) + "+")
    return "\n".join(out)


def html_card(s):
    e = html.escape
    rows = "".join(f"<tr><td>{e(a)}</td><td>{e(str(b))}</td></tr>" for a, b in [
        ("Pathways deduced", f"{s['solved']} / {s['total']}"), ("Stars", f"{s['stars']} / {s['max_stars']}"),
        ("Ultimatums passed", f"{s['ults']} / {s['ults_total']}"),
        ("Crosstalk quests", f"{s['quests']} / {s['quests_total']}"),
        ("Organelles found", f"{s['upgrades']} / {s['upgrades_total']}"),
        ("Stressors answered", s["hazards"]), ("Govinde's choice", s["ending"])])
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>Govinde Protocol Certificate</title>
<style>body{{margin:0;background:#0f1722;display:flex;justify-content:center;padding:32px;font-family:Georgia,serif}}
.c{{width:760px;border:6px double #d9b45a;background:#16202e;color:#e8e2d0;padding:40px;text-align:center}}
h1{{letter-spacing:4px;color:#d9b45a;margin:0 0 6px}}.sub{{color:#8fb7c9;margin-bottom:28px}}
.n{{font-size:34px;margin:18px 0}}.r{{font-size:22px;color:#9bd1a0;margin-bottom:24px}}
table{{margin:0 auto;border-collapse:collapse}}td{{padding:6px 18px;border-bottom:1px solid #2c3a4d;text-align:left}}
td:last-child{{text-align:right;color:#d9b45a}}.f{{margin-top:26px;color:#8fb7c9;font-size:14px}}</style></head>
<body><div class="c"><h1>THE GOVINDE PROTOCOL</h1><div class="sub">Certificate of completion</div>
<div>awarded to</div><div class="n">{e(s['name'])}</div><div class="r">Rank: {e(s['rank'])}</div>
<table>{rows}</table><div class="f">{e(share_text(s))}</div></div></body></html>"""


def make(win, j):
    """Ask for a name, write the files, show the card."""
    if not j.get("player"):
        win.erase()
        name = d.pedir_texto(win, 4, 4, "Your name for the certificate: ", largo=24)
        j["player"] = (name or "").strip() or "Anonymous cell"
    s = stats(j)
    home = os.path.expanduser("~")
    paths = []
    for fn, body in (("GovindeCertificate.html", html_card(s)),
                     ("GovindeCertificate.txt", text_card(s) + "\n\n" + share_text(s) + "\n")):
        try:
            with open(os.path.join(home, fn), "w", encoding="utf-8") as f:
                f.write(body)
            paths.append(os.path.join(home, fn))
        except OSError:
            pass
    sound.play("win")
    msg = text_card(s) + "\n\n" + share_text(s)
    if paths:
        msg += "\n\nSaved to: " + ", ".join(paths)
    d.popup(win, msg, "Certificate", ancho=76, attr=d.c("titulo"))
    if paths and d.menu(win, "Open the certificate page in your browser?", ["Yes", "No"]) == 0:
        try:
            webbrowser.open("file://" + paths[0].replace("\\", "/"))
        except Exception:
            pass
