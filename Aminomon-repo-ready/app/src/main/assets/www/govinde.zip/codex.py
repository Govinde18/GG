"""Govinde's Codex: three pages per pathway. Every page read for the first time gives 1 Insight
(used for hints), and the Ultimatums only open to players who have read everything."""
import curses

import cells
import dibujo as d
import logic
import pathways
import save


def found_also(pid):
    also = cells.ALSO.get(pid, [])
    home = cells.CELLS[pathways.PATH[pid]["cell"]]["name"]
    if not also:
        return f"Found in: {home} only."
    return f"Found in: {home}, also " + ", ".join(cells.CELLS[c]["name"] for c in also) + "."


def read_pathway(win, j, pid, page=0):
    """Reader. Returns the number of Insight points earned."""
    p = pathways.PATH[pid]
    pages = p["pages"]
    earned = 0
    while True:
        alto, ancho = win.getmaxyx()
        win.erase()
        d.reiniciar_regiones()
        w = min(96, ancho - 6)
        x = (ancho - w) // 2
        cell = cells.CELLS[p["cell"]]
        d.put(win, 0, 1, f"CODEX  ·  {p['name']}  ·  {cell['name']}", d.c("titulo", curses.A_BOLD))
        d.put(win, 1, 0, "─" * ancho, d.c("tenue"))
        d.put(win, 3, x, f"Page {page + 1}/3 · {pages[page][0]}", d.c("agua", curses.A_BOLD))
        y = 5
        for line in d.envolver(pages[page][1], w):
            d.put(win, y, x, line, d.c("texto"))
            y += 1
        y += 1
        if page == 0:
            d.put(win, y, x, f"Trigger: {p['trigger']}", d.c("titulo"))
            d.put(win, y + 1, x, f"Result:  {p['outcome']}", d.c("titulo"))
        if page == 1:
            for line in d.envolver(found_also(pid), w):
                d.put(win, y, x, line, d.c("tenue"))
                y += 1
        if page == 2:
            for line in d.envolver("Govinde whispers: I will ask about the details of this pathway in my "
                                   "Ultimatum. Skimmers do not pass.", w):
                d.put(win, y, x, line, d.c("tenue"))
                y += 1
        done = set(j["read"].get(pid, []))
        d.put(win, alto - 3, x, "Pages read: " + " ".join("■" if i in done else "□" for i in range(3)),
              d.c("tenue"))
        botones = []
        if page > 0:
            botones.append(("◄ Previous", "p", "tenue"))
        botones.append(("Next ►" if page < 2 else "Done √", "\n", "bien"))
        botones.append(("Close [Esc]", d.ESC, "mal"))
        d.fila_botones(win, alto - 1, 1, botones)
        win.refresh()
        k = d.tecla(win)
        advance = k in d.ENTER or d.es(k, curses.KEY_RIGHT, "n", "d", " ")
        if advance:
            first = page not in j["read"].setdefault(pid, [])
            if first:
                j["read"][pid].append(page)
                j["insight"] += 1
                earned += 1
            if page == 2:
                return earned
            page += 1
        elif d.es(k, curses.KEY_LEFT, "p", "a") and page > 0:
            page -= 1
        elif k == d.ESC or d.es(k, "q"):
            return earned


def codex_menu(win, j, only_pid=None):
    sel = 0
    while True:
        items = []
        for cid in cells.CELL_ORDER:
            if not logic.cell_unlocked(j, cid):
                continue
            for pid in cells.CELLS[cid]["order"]:
                items.append(pid)
        if not items:
            return
        rows = []
        for pid in items:
            p = pathways.PATH[pid]
            n = logic.pages_read(j, pid)
            marks = "■" * n + "□" * (3 - n)
            rows.append(f"{marks}  {p['name']:<34} {cells.CELLS[p['cell']]['name']}")
        sel = d.menu(win, f"Govinde's Codex  ·  Insight {j['insight']}", rows, inicial=min(sel, len(rows) - 1),
                     ancho=min(86, win.getmaxyx()[1] - 2), ayuda="Read all 3 pages of a pathway to earn Insight and the read seal")
        if sel is None:
            return
        got = read_pathway(win, j, items[sel])
        if got:
            d.popup(win, f"+{got} Insight. You now have {j['insight']}. Insight buys hints in a deduction.",
                    "Insight", ancho=56, attr=d.c("bien"))
        save.write(j)
