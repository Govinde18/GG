"""Deducing a pathway: assemble its events in the right order from a scrambled pool."""
import curses
import random

import cells
import anim
import codex
import dibujo as d
import logic
import pathways
import quiz
import save
import sound
import upgrades

KEYS = "1234567890"


def _allowed(p, placed):
    """Indexes of the steps that may be placed next (a parallel group accepts any of its members)."""
    n = len(p["steps"])
    nxt = next(i for i in range(n) if i not in placed)
    for g in p["parallel"]:
        if nxt in g:
            return {i for i in g if i not in placed}
    return {nxt}


def _hint(p, placed):
    acts = [p["actors"][i] for i in sorted(_allowed(p, placed))]
    return "Hint: the next event involves " + " or ".join(acts) + "."


def _draw(win, j, p, st, pool, placed_cards, msg, lives, mistakes, msg_attr):
    alto, ancho = win.getmaxyx()
    win.erase()
    d.reiniciar_regiones()
    n = len(p["steps"])
    d.put(win, 0, 1, f"DEDUCE  ·  {p['name']}  ·  {cells.CELLS[p['cell']]['name']}", d.c("titulo", curses.A_BOLD))
    right = ("Lives: ∞" if lives is None else f"Lives: {'♥' * lives}{'·' * (st['lives'] - lives)}")
    right += f"   Mistakes: {mistakes}   Insight: {j['insight']}"
    d.put(win, 0, max(40, ancho - len(right) - 2), right, d.c("agua"))
    d.put(win, 1, 0, "─" * ancho, d.c("tenue"))
    d.put(win, 2, 1, f"Trigger: {p['trigger']}", d.c("texto", curses.A_BOLD))
    d.put(win, 3, 1, f"Result:  {p['outcome']}", d.c("texto", curses.A_BOLD))
    w = ancho - 8
    remaining = [(i, c) for i, c in enumerate(pool) if c not in placed_cards]
    pool_lines = [d.envolver(c["text"], w) for _, c in remaining]
    pool_rows = sum(len(x) for x in pool_lines)
    # slots: collapse older placed events if the screen is short
    fixed = 5 + 1 + 1 + 3          # header + slots title + pool title + message and buttons
    room = alto - fixed - pool_rows
    show = n if room >= n else max(1, room)
    d.put(win, 5, 1, f"Your pathway ({len(placed_cards)}/{n} events placed):", d.c("agua", curses.A_BOLD))
    y = 6
    hidden = 0
    if show < n:
        # keep the next empty slot and as many of the latest placed events as fit
        keep = max(0, show - 1)
        hidden = max(0, len(placed_cards) - keep)
    for s in range(n):
        if s < hidden:
            continue
        if s < len(placed_cards):
            text = f"{s + 1}. {placed_cards[s]['text']}"
            d.put(win, y, 2, text[: ancho - 4], d.c("bien"))
            y += 1
        elif show >= n or s == len(placed_cards):
            d.put(win, y, 2, f"{s + 1}. · · ·", d.c("oscuro"))
            y += 1
    if hidden:
        d.put(win, 6, 2, f"({hidden} earlier events placed)", d.c("tenue"))
    y += 0
    d.put(win, y, 1, "Pieces: pick the next event", d.c("agua", curses.A_BOLD))
    y += 1
    for (i, c), lines in zip(remaining, pool_lines):
        key = KEYS[i]
        d.region(y, 1, len(lines), ancho - 2, key)
        for k, l in enumerate(lines):
            d.put(win, y + k, 2, (f"{key}) " if k == 0 else "   ") + l, d.c("texto"))
        y += len(lines)
    if msg:
        for k, l in enumerate(d.envolver(msg, ancho - 4)[:2]):
            d.put(win, alto - 3 + k, 2, l, msg_attr)
    d.fila_botones(win, alto - 1, 1, [("Hint [H]", "h", "agua"), ("Codex [C]", "c", "POL"),
                                      ("Give up [Esc]", d.ESC, "mal")])
    win.refresh()


def _attempt(win, j, p, st):
    steps = p["steps"]
    pool = [dict(text=t, idx=i) for i, t in enumerate(steps)]
    pool += [dict(text=t, idx=None) for t in random.sample(p["decoys"], st["decoys"])]
    random.shuffle(pool)
    placed, placed_cards = set(), []
    lives = st["lives"]
    if lives is not None and upgrades.active(j, "chaperone"):
        lives += 1
        upgrades.use(j, "chaperone")
    free_hint = upgrades.active(j, "receptor")
    mistakes = hints = streak = 0
    msg, attr = "Pick the first event of the pathway.", d.c("tenue")
    while len(placed) < len(steps):
        _draw(win, j, p, st, pool, placed_cards, msg, lives, mistakes, attr)
        k = d.tecla(win)
        if isinstance(k, str) and k in KEYS and KEYS.index(k) < len(pool):
            card = pool[KEYS.index(k)]
            if card in placed_cards:
                continue
            if card["idx"] is not None and card["idx"] in _allowed(p, placed):
                placed.add(card["idx"])
                placed_cards.append(card)
                streak = 0
                sound.play("step", 30 * len(placed))
                msg, attr = "Correct!", d.c("bien", curses.A_BOLD)
            else:
                mistakes += 1
                streak += 1
                logic.weak_add(j, p["id"])
                sound.play("bad")
                if lives is not None:
                    lives -= 1
                msg = ("That event belongs to a different pathway." if card["idx"] is None
                       else "Right idea, wrong moment: that happens at a different point.")
                attr = d.c("mal", curses.A_BOLD)
                if st["lives"] is None and streak >= 2:
                    msg += " " + _hint(p, placed)
                if lives == 0:
                    d.popup(win, "The pathway fell apart: too many mistakes. Read the Codex and try again.",
                            "Failed", attr=d.c("mal"))
                    return "failed", mistakes, hints
        elif d.es(k, "h"):
            if st["lives"] is None and p["stage"] == 1:
                hints += 1
                msg, attr = _hint(p, placed), d.c("agua", curses.A_BOLD)
            elif free_hint:
                free_hint = False
                upgrades.use(j, "receptor")
                hints += 1
                msg, attr = _hint(p, placed) + " (free: extra receptor)", d.c("agua", curses.A_BOLD)
            elif j["insight"] >= 1:
                j["insight"] -= 1
                hints += 1
                msg, attr = _hint(p, placed) + " (-1 Insight)", d.c("agua", curses.A_BOLD)
            else:
                msg, attr = "No Insight left. Read Codex pages to earn more.", d.c("mal")
        elif d.es(k, "c"):
            codex.read_pathway(win, j, p["id"])
            save.write(j)
        elif k == d.ESC:
            if d.menu(win, "Leave this deduction?", ["Keep going", "Leave"]) == 1:
                return "left", mistakes, hints
    return "solved", mistakes, hints


def _chain(p):
    return "\n".join(f"{i + 1}. {s}" for i, s in enumerate(p["steps"]))


def deduce(win, j, pid, fw=None):
    """Returns 'solved', 'failed' or 'left'. fw is set when the player did the field work and the bench."""
    p = pathways.PATH[pid]
    st = cells.STAGES[p["stage"]]
    if pid in j["solved"]:
        d.popup(win, _chain(p), p["name"], ancho=min(100, win.getmaxyx()[1] - 2))
        return "left"
    cost = pathways.cost_of(pid)
    if pid not in j["paid"]:
        if not logic.can_afford(j, cost):
            need = logic.cost_text(logic.missing(j, cost))
            d.popup(win, f"This experiment needs {logic.cost_text(cost)}. You are missing {need}. "
                         "Harvest materials from the cells you already unlocked.", "Not enough materials",
                    attr=d.c("mal"))
            return "left"
        if cost and d.menu(win, f"Run this experiment? It costs {logic.cost_text(cost)}",
                           ["Yes, run it", "Not now"]) != 0:
            return "left"
        logic.pay(j, cost)
        j["paid"].append(pid)
        save.write(j)
    while True:
        result, mistakes, hints = _attempt(win, j, p, st)
        if result == "solved":
            break
        if result == "left":
            return "left"
        choice = d.menu(win, "What now?", ["Try again", "Read the Codex first", "Leave"])
        if choice == 1:
            codex.read_pathway(win, j, pid)
            save.write(j)
        elif choice != 0:
            return "failed"
    anim.cascade(win, p)
    d.popup(win, f"{p['trigger']}\n\n{_chain(p)}\n\n=> {p['outcome']}", f"Deduced: {p['name']}",
            ancho=min(104, win.getmaxyx()[1] - 2), attr=d.c("bien"))
    w = p["whatif"]
    mastery = quiz.ask(win, "Govinde's What-if", w["q"], w["a"], w["wrong"], w["why"], allow_exit=False)
    stars = 1 + (1 if mistakes <= st["star_mistakes"] else 0) + (1 if mastery else 0)
    if fw is None:
        stars = min(stars, 2)
    elif fw["mistakes"] > 2 * st["star_mistakes"] + 1:
        stars = min(stars, 2)
    first = pid not in j["solved"]
    j["solved"][pid] = dict(stars=max(stars, j["solved"].get(pid, {}).get("stars", 0)), mistakes=mistakes,
                            hints=hints)
    save.count(j, "deduced")
    if mistakes == 0:
        save.count(j, "flawless")
    if hints == 0:
        save.count(j, "no_hint")
    j["insight"] += 1 + (1 if stars == 3 else 0) + (1 if fw is not None else 0)
    logic.refill(j)
    save.write(j)
    d.popup(win, f"{'♦' * stars}{'◊' * (3 - stars)}  {p['name']} deduced!\n\n+{1 + (stars == 3)} Insight. "
                 "Your cells have recovered: harvesting is available again.", "Deduction complete",
            ancho=60, attr=d.c("bien"))
    return "solved"
