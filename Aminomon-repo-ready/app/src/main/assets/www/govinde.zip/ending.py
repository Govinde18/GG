"""The finale: Govinde is bacteriophage lambda and the player decides what he does."""
import cells
import certificate
import dibujo as d
import save
import sound

REVEAL = [
    "You did it. Every pathway, every cell. And now I owe you the truth I have been carrying since the "
    "first page: I am not a harmless phage. I am lambda, and I am built to make one decision.",
    "Inside a cell I can sleep, copied quietly with the genome, or I can burst out and make hundreds of "
    "copies of myself. That is the switch you just deduced: CI against Cro, steered by a signal. "
    "Nothing in me decides. A signal does.",
    "I wanted to understand cells, because every cell I could have burst was a city of messages like the "
    "ones you taught me. So I ask you, the cell I travelled in: what should I do?",
]
LYSOGENY = [
    "Then I will sleep. I integrate into your genome and become a prophage, copied each time you divide, "
    "silent as long as CI holds the operators.",
    "If you are ever badly hurt, RecA will sound the alarm and I will wake. Until then, I will keep "
    "reading your signals, quietly, as your oldest passenger.",
]
LYSIS = [
    "Then I will go. The switch flips, Cro takes OR3, holin and endolysin do their work, and the cell "
    "opens like a window.",
    "Hundreds of little phages will carry what you taught me to other cells. It is not cruelty. It is "
    "what a signal makes a phage do, and you were the best host I could have had.",
]


def play(win, j, replay=False):
    d.dialogo(win, REVEAL, "Govinde")
    r = d.menu(win, "What should Govinde do?",
               ["Let him sleep in the genome (lysogeny)", "Let him burst out and spread (lysis)"])
    choice = "lysis" if r == 1 else "lysogeny"
    sound.play("win")
    d.dialogo(win, LYSIS if choice == "lysis" else LYSOGENY, "Govinde")
    d.dialogo(win, ["The Govinde Protocol is complete. Thank you for playing. Press M to explore the whole "
                    "map again, or visit me in the Basement Membrane."], "Govinde")
    if not replay or not j.get("ending"):
        j["ending"] = choice
    save.write(j)
    if d.menu(win, "Make your certificate?", ["Yes, make it", "Later"]) == 0:
        certificate.make(win, j)
        save.write(j)
