"""Exploration: walk through the cells and the extracellular matrix, bump into pathway stations,
open membrane gates, talk to Govinde and read the world map."""
import curses
import random

import anim
import atlas
import bosses
import deduce
import fieldwork
import journal
import cells
import codex
import dibujo as d
import ending
import game as G
import harvest
import hazards
import lab
import logic
import pathways
import pops
import quests
import quiz
import save
import seals
import sound
import certificate
import ultimatum
import upgrades
import world as W

ECM_TEXT = {
    "ecm1": "The extracellular matrix: a mesh of sugars and proteins that fills the space between cells. "
            "Bacteria build a rough version of it as a biofilm. From here the path splits: Bacillus to the "
            "north, a cyanobacterium to the south.",
    "ecm2": "Two bacterial lineages meet. Ahead lies the nucleus: the border between prokaryotes and "
            "eukaryotes. The gate to yeast opens only for those who pass Govinde's Stage 2 Ultimatum.",
    "ecm3": "Eukaryotes in a tissue talk through a matrix of collagen and proteoglycans. Integrins in the "
            "cell membrane grab it and pass signals inwards. The way on leads down to an animal cell.",
    "ecm4": "A crossroads in the matrix of an animal tissue. The specialised cells branch off from here: "
            "liver, pancreas, nerve and muscle. They exchange hormones and neurotransmitters.",
    "ecm5": "The basement membrane, a sheet of laminin and collagen IV under tissue. This is the last "
            "chamber. Govinde waits here for the final exam.",
}
GLYPH = {
    W.WALL: ("oscuro", 0), W.FLOOR: ("tenue", 0), W.BAND: ("agua", 0), W.ECM: ("tenue", 0),
    "§": ("POS", 0), "÷": ("ARO", 0), "●": ("NEG", 0), "═": ("POL", 0), "☼": ("titulo", 0),
    "░": ("NP", 0), "▓": ("POL", 0), "║": ("NEG", 0), "╬": ("titulo", curses.A_BOLD),
    "≈": ("agua", 0), "≡": ("tenue", 0), "─": ("tenue", 0), "▪": ("titulo", 0), "°": ("ARO", 0),
}



TRAVEL_ORDER = ["ecoli", "ecm1", "bacillus", "cyano", "ecm2", "yeast", "ecm3", "fibroblast", "ecm4",
                "hepatocyte", "beta_cell", "neuron", "muscle", "ecm5", "phage"]
MINI_SX, MINI_SY = -(-W.W // 30), -(-W.H // 13)


class Explorer(G.Game):
    def __init__(self, win, j):
        super().__init__(win, j)
        self.w = W.World()
        p = j.get("pos") or list(W.START)
        self.pos = tuple(p) if self.w.walkable(*p) else W.START
        self.picked = set(j["picked"])
        self.seen = set(j["seen"])
        self.rng = random.Random()
        self.lig = anim.Ligands(self.w, count=170)
        self.ligs = {}
        self.haz = None
        self.haz_wait = 12
        self.tickn = 0
        self.walked = 0
        self.mini = True
        self.cam = (0, 0)
        self.last_cell = None
        sound.set_enabled(j.get("sound", True))
        self.blocks = {}
        for by in range(0, W.H, MINI_SY):
            for bx in range(0, W.W, MINI_SX):
                best = None
                for y in range(by, min(W.H, by + MINI_SY), 2):
                    for x in range(bx, min(W.W, bx + MINI_SX), 3):
                        r = self.w.region[y][x]
                        if r and (best is None or (r in W.GEO) > (best in W.GEO)):
                            best = r
                if best:
                    self.blocks[(bx // MINI_SX, by // MINI_SY)] = best
        self.fmap = {}
        self.rebuild_field()
        self.reveal()

    # --------------------------------------------------------------- state
    def reveal(self):
        px, py = self.pos
        for y in range(max(0, py - 4), min(W.H, py + 5)):
            for x in range(max(0, px - 4), min(W.W, px + 5)):
                r = self.w.region[y][x]
                if r:
                    self.seen.add(r)
                if (x, y) in self.w.gates:
                    self.seen.add("gate:" + self.w.gates[(x, y)]["id"])
        r = self.w.region_at(px, py)
        if r:
            self.seen.add(r)
        self.j["seen"] = sorted(self.seen)
        self.j["pos"] = list(self.pos)
        self.j["picked"] = sorted(self.picked)

    def rebuild_field(self):
        """Positions of the hearts for the active field work."""
        f = self.j.get("field")
        self.fmap = {}
        if not f:
            return
        for name, (x, y, kind, zone) in f["parts"].items():
            if name not in f["have"]:
                self.fmap[(x, y)] = (name, True)
        for name, (x, y) in f["decoys"].items():
            self.fmap[(x, y)] = (name, False)

    def station_color(self, pid):
        st = logic.path_state(self.j, pid)
        return {"solved": ("bien", curses.A_BOLD, "♦"), "ready": ("titulo", curses.A_BOLD, "Ω"),
                "sequence": ("tenue", 0, "○"), "nocell": ("oscuro", 0, "○")}[st]

    def gate_open(self, gd):
        cid = gd["cell"]
        if gd["mode"] == "out":
            return all(logic.solved(self.j, p) for p in cells.CELLS[cid]["order"])
        return logic.cell_unlocked(self.j, cid)

    def tile_attr(self, x, y, full=False):
        w, j = self.w, self.j
        pos = (x, y)
        r = w.region[y][x]
        if pos == self.pos:
            return "☺", d.c("agua", curses.A_BOLD)
        if self.haz and pos == (self.haz["x"], self.haz["y"]):
            return "▲", d.c("mal", curses.A_BOLD | (curses.A_REVERSE if self.tickn % 2 else 0))
        if pos in w.bosses and r in self.seen and bosses.ready(j, bosses.BY_ID[w.bosses[pos]]):
            return "Ж", d.c("mal", curses.A_BOLD | (curses.A_REVERSE if self.tickn % 2 else 0))
        if pos in self.fmap and r in self.seen:
            return "♥", d.c("POL", curses.A_BOLD)
        if pos in w.stations and r in self.seen:
            col, ex, ch = self.station_color(w.stations[pos])
            return ch, d.c(col, ex)
        if pos in w.npcs and r in self.seen:
            return "G", d.c("NEG", curses.A_BOLD)
        if pos in w.gates and "gate:" + w.gates[pos]["id"] in self.seen:
            ok = self.gate_open(w.gates[pos])
            return "╬", d.c("bien" if ok else "mal", curses.A_BOLD)
        if pos in w.quests and r in self.seen:
            done = w.quests[pos] in j["quests"]
            return ("√", d.c("tenue")) if done else ("?", d.c("titulo", curses.A_BOLD))
        if pos in w.chests and r in self.seen and upgrades.chest_visible(j, w.chests[pos]):
            return "♠", d.c("POS", curses.A_BOLD)
        if pos in w.pickups and r in self.seen and f"{w.pickups[pos][0]}:{w.pickups[pos][1]}" not in self.picked:
            return "¤", d.c("titulo", curses.A_BOLD)
        g = w.g[y][x]
        if g == " ":
            return " ", 0
        if r not in self.seen and g != W.WALL:
            if full:
                return g, d.c("oscuro")
            return " ", 0
        if g == W.ECM and pos in self.ligs:
            ch, col = self.ligs[pos]
            return ch, d.c(col, curses.A_BOLD)
        if g == W.BAND and abs(x - self.pos[0]) + abs(y - self.pos[1]) <= 5:
            return ("●", d.c("agua", curses.A_BOLD)) if (self.tickn + x) % 4 < 2 else ("○", d.c("agua"))
        col, ex = GLYPH.get(g, ("texto", 0))
        return g, d.c(col, ex)

    # ------------------------------------------------------------ drawing
    def next_goal(self):
        j = self.j
        f = j.get("field")
        if f:
            left = fieldwork.missing(f)
            if left:
                kind, zone = f["parts"][left[0]][2], f["parts"][left[0]][3]
                return (f"Field work ({pathways.PATH[f['pid']]['name']}) {len(f['have'])}/{len(f['parts'])}: "
                        f"find {left[0]} in the {zone}.")
            return f"Field work done: return to the {pathways.PATH[f['pid']]['name']} station (Omega)."
        for cid in cells.CELL_ORDER:
            if not logic.cell_unlocked(j, cid):
                continue
            for pid in cells.CELLS[cid]["order"]:
                if not logic.solved(j, pid):
                    return f"Goal: deduce {pathways.PATH[pid]['name']} in {cells.CELLS[cid]['name']}."
        for s in cells.STAGES:
            if s not in j["ultimatums"]:
                blk = logic.ultimatum_blockers(j, s)
                if not blk:
                    return f"Goal: find Govinde in the matrix and take the {cells.STAGES[s]['name']} Ultimatum."
                for cid in cells.CELL_ORDER:
                    if cells.CELLS[cid]["stage"] == s and not logic.cell_unlocked(j, cid):
                        return f"Goal: enter {cells.CELLS[cid]['name']} through its membrane gate."
                if logic.stage_unread(j, s):
                    return f"Goal: read the Codex pages of {cells.STAGES[s]['name']} (key C)."
                return "Goal: finish the remaining pathways of this stage."
        if not j["final"]:
            return "Goal: take the Grand Ultimatum with Govinde in the Basement Membrane."
        if not j.get("ending"):
            return "Goal: hear Govinde's secret in the Basement Membrane."
        return "All done. Explore, harvest, or solve the quests you missed."

    def draw_mini(self, alto, ancho):
        mw, mh = W.W // MINI_SX + 1, W.H // MINI_SY + 1
        x0, y0 = ancho - mw - 3, 2
        d.caja(self.win, y0, x0, mh + 2, mw + 2, "Map")
        d.region(y0, x0, mh + 2, mw + 2, "m")
        px, py = self.pos[0] // MINI_SX, self.pos[1] // MINI_SY
        for (bx, by), r in self.blocks.items():
            if r not in self.seen:
                continue
            if r in W.GEO:
                done = all(logic.solved(self.j, p) for p in cells.CELLS[r]["order"])
                ch, at = "█", d.c("bien" if done else "tenue")
            else:
                ch, at = "▒", d.c("oscuro")
            d.put(self.win, y0 + 1 + by, x0 + 1 + bx, ch, at)
        blink = "☺" if self.tickn % 2 else "☻"
        d.put(self.win, y0 + 1 + py, x0 + 1 + px, blink, d.c("agua", curses.A_BOLD))

    def draw(self):
        win, j, w = self.win, self.j, self.w
        alto, ancho = win.getmaxyx()
        win.erase()
        d.reiniciar_regiones()
        px, py = self.pos
        vh, vw = alto - 5, ancho
        cur = w.region_at(px, py)
        self.cell_mode = cur if cur in W.GEO else None
        if self.cell_mode:
            (cx, cy), (rx, ry) = W.GEO[cur]["c"], W.GEO[cur]["r"]
            lo_x, hi_x, lo_y, hi_y = cx - rx - 1, cx + rx + 2, cy - ry - 1, cy + ry + 2
            if hi_x - lo_x <= vw:
                ox = (lo_x + hi_x - vw) // 2
            else:
                ox = max(lo_x, min(hi_x - vw, px - vw // 2))
            if hi_y - lo_y <= vh:
                oy = (lo_y + hi_y - vh) // 2
            else:
                oy = max(lo_y, min(hi_y - vh, py - vh // 2))
        else:
            ox = max(0, min(W.W - vw, px - vw // 2))
            oy = max(0, min(W.H - vh, py - vh // 2))
        self.cam = (ox, oy)
        d.put(win, 0, 1, "THE GOVINDE PROTOCOL", d.c("titulo", curses.A_BOLD))
        place = w.place_name(px, py)
        d.put(win, 0, max(24, ancho - len(place) - 2), place, d.c("agua", curses.A_BOLD))
        hud = "  ".join(f"{upgrades.UPGRADES[u]['name']} {upgrades.charges(j, u)}{'' if upgrades.is_on(j, u) else ' off'}"
                        for u in j["upgrades"] if upgrades.charges(j, u) > 0)
        d.put(win, 0, 24, hud[: max(0, ancho - len(place) - 28)], d.c("POS"))
        mats = "  ".join(f"{cells.SHORT[m]} {j['mats'][m]}" for m in cells.MATERIALS)
        d.put(win, 1, 1, mats, d.c("texto"))
        extra = f"Insight {j['insight']}   ♦ {logic.total_stars(j)}   Solved {len(j['solved'])}/{len(pathways.ALL)}"
        d.put(win, 1, max(len(mats) + 4, ancho - len(extra) - 2), extra, d.c("POL"))
        self.ligs = self.lig.at()
        for sy in range(vh):
            y = oy + sy
            if y >= W.H:
                break
            run, runattr, start = "", None, 0
            for sx in range(vw - 1):
                x = ox + sx
                if x >= W.W:
                    break
                if x < 0 or y < 0 or (self.cell_mode and w.region[y][x] != self.cell_mode):
                    ch, at = " ", 0
                else:
                    ch, at = self.tile_attr(x, y)
                if at != runattr:
                    if run:
                        d.put(win, 2 + sy, start, run, runattr)
                    run, runattr, start = "", at, sx
                run += ch
            if run:
                d.put(win, 2 + sy, start, run, runattr)
        d.region(2, 0, vh, vw, lambda mx, my: ("walk", ox + mx, oy + my - 2))
        if self.mini and not self.cell_mode and ancho >= 100 and alto >= 30:
            self.draw_mini(alto, ancho)
        near = ""
        for n in list(w.neighbours(px, py)) + [(px, py)]:
            if n in w.stations:
                pid = w.stations[n]
                near = f"{pathways.PATH[pid]['name']} ({logic.path_state(j, pid)}) - walk into it to open it"
            elif n in w.npcs:
                near = "Govinde: walk into him to talk"
            elif n in w.gates:
                gd = w.gates[n]
                near = "Membrane gate (open)" if self.gate_open(gd) else "Membrane gate (closed) - walk into it"
            elif n in w.quests:
                near = "A crosstalk quest (?): walk into it to try it"
            elif n in self.fmap:
                nm, need = self.fmap[n]
                near = f"Heart: {nm}" + (" (on your list: walk onto it)" if need else " (not on your list)")
            elif n in w.bosses and bosses.ready(j, bosses.BY_ID[w.bosses[n]]):
                near = f"BOSS: {bosses.BY_ID[w.bosses[n]]['name']}. Walk into it when you are ready."
            elif self.haz and n == (self.haz["x"], self.haz["y"]):
                near = "A stressor! Answer it with the right pathway"
        line = self.msg or near or self.next_goal()
        d.put(win, alto - 3, 1, line[: ancho - 2], d.c("agua" if self.msg or near else "tenue"))
        btn = [("Map [M]", "m", "agua"), ("Travel [F]", "f", "agua"), ("Codex [C]", "c", "POL"),
               ("Harvest [H]", "h", "titulo"), ("Ultimatum [U]", "u", "mal"), ("Review [R]", "r", "bien"),
               ("Lab [L]", "l", "agua"), ("Organelles [O]", "o", "titulo"), ("Guide [E]", "e", "tenue"), ("Swim [V]", "v", "POS"), ("Journal [J]", "j", "agua"), ("Tasks [K]", "k", "POL"), ("Atlas [T]", "t", "tenue"),
               ("Seals [B]", "b", "tenue"), ("Help [?]", "?", "tenue"), ("Menu [Q]", "q", "tenue")]
        d.fila_botones(win, alto - 2, 1, btn, ancho - 2)
        win.refresh()

    # ------------------------------------------------------------ movement
    def step(self, dx, dy):
        w, j = self.w, self.j
        t = (self.pos[0] + dx, self.pos[1] + dy)
        if not w.walkable(*t):
            return "blocked"
        if self.haz and t == (self.haz["x"], self.haz["y"]):
            self.fight()
            return "bump"
        if t in w.bosses and bosses.ready(j, bosses.BY_ID[w.bosses[t]]):
            self.boss(bosses.BY_ID[w.bosses[t]])
            return "bump"
        if t in w.stations:
            self.bump_station(w.stations[t])
            return "bump"
        if t in w.npcs:
            self.talk(w.npcs[t])
            return "bump"
        if t in w.quests:
            self.quest(w.quests[t])
            return "bump"
        if t in w.gates and not self.pass_gate(w.gates[t]):
            return "bump"
        self.pos = t
        self.walked += 1
        if t in self.fmap:
            nm, need = self.fmap[t]
            if need:
                self.toast(fieldwork.collect(self.win, j, nm))
                self.rebuild_field()
                self.after()
            else:
                self.toast(f"That is {nm}: not needed for this pathway.")
        zname = w.zone[t[1]][t[0]]
        if zname in W.INFO and zname not in j["dex"]["zones"]:
            j["dex"]["zones"].append(zname)
            if not self.msg:
                self.toast(f"Journal: new entry, {zname}.")
        key = w.pickups.get(t)
        if key and f"{key[0]}:{key[1]}" not in self.picked:
            self.picked.add(f"{key[0]}:{key[1]}")
            mk = cells.CELLS[key[0]]["makes"]
            m = mk[key[1] % len(mk)]
            n = 2 if upgrades.active(j, "chloroplast") else 1
            if n == 2:
                upgrades.use(j, "chloroplast")
            logic.gain(j, {m: n})
            sound.play("pickup")
            self.toast(f"Picked up {n} {m}.")
            save.count(j, "pickups")
        chest = w.chests.get(t)
        if chest and upgrades.chest_visible(j, chest):
            u = upgrades.UPGRADES[chest]
            first = upgrades.collect(j, chest)
            sound.play("upgrade")
            head = f"You found a {u['name']}!" if first else f"Your {u['name']} is restored!"
            d.popup(self.win, f"{head}\n\n{u['text']}\n\nCharges: {u['max']} {u['unit']}.", "Organelle",
                    ancho=60, attr=d.c("bien"))
            self.after()
        if t in w.gates:
            sound.play("gate")
        r = w.region_at(*t)
        if r in W.PLAZAS and f"pl:{r}" not in j["told"]:
            self.reveal()
            j["told"].append(f"pl:{r}")
            d.popup(self.win, ECM_TEXT[r], w.names[r], ancho=66)
        self.reveal()
        return "moved"

    def pass_gate(self, gd):
        j, cid = self.j, gd["cell"]
        c = cells.CELLS[cid]
        if gd["mode"] == "out":
            if self.gate_open(gd):
                return True
            left = [pathways.PATH[p]["name"] for p in c["order"] if not logic.solved(j, p)]
            self.toast("The membrane is shut. Still to deduce here: " + ", ".join(left))
            return False
        if logic.cell_unlocked(j, cid):
            return True
        if not logic.stage_open(j, c["stage"]):
            self.toast(f"A membrane gate. Govinde must first pass you on {cells.STAGES[c['stage'] - 1]['name']} "
                       f"(his Ultimatum, in the matrix).")
            return False
        self.unlock_cell(cid)
        return logic.cell_unlocked(j, cid)

    def bump_station(self, pid):
        j = self.j
        cid = pathways.PATH[pid]["cell"]
        j["cell"] = cid
        self.sel = cells.CELLS[cid]["order"].index(pid)
        if logic.path_state(j, pid) == "sequence":
            self.toast("This pathway waits for the one before it. Deduce the previous station first.")
        self.open_path()

    # ------------------------------------------------------------ encounters
    def quest(self, qid):
        j = self.j
        q = quests.BY_ID[qid]
        if qid in j["quests"]:
            d.popup(self.win, f"{q['q']}\n\nAnswer: {q['a']}\n\n{q['why']}", f"Solved: {q['title']}", ancho=76)
            return
        miss = [pathways.PATH[p]["name"] for p in q["need"] if p not in j["solved"]]
        if miss:
            d.popup(self.win, "A crosstalk quest. Come back once you have deduced: " + ", ".join(miss) + ".",
                    q["title"], ancho=64)
            return
        r = quiz.ask(self.win, f"Crosstalk quest · {q['title']}", q["q"], q["a"], q["wrong"], q["why"],
                     allow_exit=True)
        if r:
            j["quests"].append(qid)
            j["insight"] += 2
            for p in q["need"]:
                logic.weak_ok(j, p)
            sound.play("win")
            d.popup(self.win, "+2 Insight", "Quest complete", ancho=34, attr=d.c("bien"))
        elif r is False:
            for p in q["need"]:
                logic.weak_add(j, p)
            sound.play("bad")
        self.after()

    def boss(self, b):
        res = bosses.fight(self.win, self.j, b)
        if res == "won":
            self.toast(f"{b['name']} defeated!")
        self.after()

    def open_path(self):
        j = self.j
        if not logic.cell_unlocked(j, self.cell):
            if self.cell_state(self.cell) == "available":
                self.unlock_cell(self.cell)
            return
        pid = self.order()[self.sel]
        state = logic.path_state(j, pid)
        f = fieldwork.mine(j, pid)
        opts, acts = [], []
        if state == "ready":
            if f:
                if fieldwork.complete(f):
                    if f.get("benched"):
                        opts.append("Arrange the pathway (final step)")
                        acts.append("arrange")
                    else:
                        opts.append("Carry out the pathway at the bench")
                        acts.append("bench")
                else:
                    opts.append(f"Field work: my tasks ({len(f['have'])}/{len(f['parts'])})")
                    acts.append("tasks")
                opts.append("Abandon this field work")
                acts.append("abandon")
            else:
                opts.append("Begin field work: collect its components")
                acts.append("begin")
            opts.append("Skip field work, just arrange it (max 2 stars)")
            acts.append("skip")
        elif state == "solved":
            opts.append("Review the deduced pathway")
            acts.append("skip")
        opts.append("Read its Codex pages")
        acts.append("codex")
        if state == "solved":
            opts.append("Harvest from it")
            acts.append("harvest")
        opts.append("Back")
        acts.append("back")
        r = d.menu(self.win, pathways.PATH[pid]["name"], opts)
        if r is None or acts[r] == "back":
            return
        a = acts[r]
        if a == "begin":
            cur = j.get("field")
            if cur and cur["pid"] != pid and d.menu(
                    self.win, f"Drop your field work for {pathways.PATH[cur['pid']]['name']}?",
                    ["Keep it", "Drop it and start this one"]) != 1:
                return
            if fieldwork.begin(self.win, j, self.w, pid):
                self.rebuild_field()
        elif a == "tasks":
            fieldwork.tasks(self.win, j)
        elif a == "abandon":
            j["field"] = None
            self.rebuild_field()
            self.toast("Field work abandoned. You can begin it again any time.")
        elif a == "bench":
            m = fieldwork.bench(self.win, j, pid)
            if m is not None:
                f["benched"], f["bench_mistakes"] = True, m
                self.arrange(pid, f)
        elif a == "arrange":
            self.arrange(pid, f)
        elif a == "skip":
            if f:
                j["field"] = None
                self.rebuild_field()
            self.run_deduce(pid)
        elif a == "codex":
            got = codex.read_pathway(self.win, j, pid)
            if got:
                self.toast(f"+{got} Insight from reading.")
            self.after()
        elif a == "harvest":
            harvest.harvest(self.win, j)
            self.after()

    def arrange(self, pid, f):
        result = deduce.deduce(self.win, self.j, pid, fw=dict(mistakes=f.get("bench_mistakes", 0)))
        if result == "solved":
            self.j["field"] = None
            save.count(self.j, "fieldwork")
            self.rebuild_field()
            if self.sel < len(self.order()) - 1:
                self.sel += 1
        self.after()

    def fight(self):
        h = self.haz
        res = hazards.encounter(self.win, self.j, h)
        self.haz = None
        self.haz_wait = 30 if res == "won" else 18
        if res == "won":
            self.toast("The stressor is answered. Well done!")
        elif res == "lost":
            self.toast("The stressor got through. Review that pathway (key R).")
        else:
            self.toast("You slipped away from the stressor.")
        self.after()

    def tick(self):
        """Called about every 150 ms while the player is idle."""
        self.tickn += 1
        self.lig.tick(self.pos)
        cid = self.w.region_at(*self.pos)
        if cid != self.last_cell:
            self.last_cell = cid
            self.haz = None
            self.haz_wait = max(self.haz_wait, 14)
        if cid in W.GEO:
            if self.haz is None:
                self.haz_wait -= 1
                if self.haz_wait <= 0:
                    self.haz = hazards.spawn(self.w, self.j, cid, self.pos, self.rng)
                    self.haz_wait = 20
            elif self.tickn % 2 == 0:
                hazards.move(self.haz, self.w, self.pos, self.rng)
                if abs(self.haz["x"] - self.pos[0]) + abs(self.haz["y"] - self.pos[1]) <= 1:
                    self.fight()
        else:
            self.haz = None

    def talk(self, stage):
        j, win = self.j, self.win
        st = cells.STAGES[stage]
        opts = [f"Take the {st['name']} Ultimatum", "What should I do next?", "Leave"]
        if stage == max(cells.STAGES):
            opts.insert(1, cells.FINAL["name"])
            if j["final"]:
                opts.insert(2, "Hear Govinde's secret again")
                opts.insert(3, "Make my certificate")
        r = d.menu(win, f"Govinde · {st['name']}", opts)
        if r is None:
            return
        o = opts[r]
        if o.startswith("Take"):
            if ultimatum.stage_ultimatum(win, j, stage):
                sound.play("win")
        elif o == cells.FINAL["name"]:
            if ultimatum.grand_ultimatum(win, j):
                sound.play("win")
                ending.play(win, j)
        elif o.startswith("Hear"):
            ending.play(win, j, replay=True)
        elif o.startswith("Make"):
            certificate.make(win, j)
        elif o.startswith("What"):
            d.popup(win, self.next_goal() + "\n\n" + st.get("intro", ""), "Govinde", ancho=70)
        self.after()

    def pop_quiz(self):
        self.walked = 0
        pops.pop_quiz(self.win, self.j)
        self.after()

    def walk(self, goal):
        path = self.w.path(self.pos, goal)
        win = self.win
        for t in path:
            dx, dy = t[0] - self.pos[0], t[1] - self.pos[1]
            r = self.step(dx, dy)
            if r != "moved":
                break
            self.tickn += 1
            if upgrades.active(self.j, "flagellum"):
                upgrades.use(self.j, "flagellum")
                if self.tickn % 2:
                    continue
            self.draw()
            curses.napms(18)
            if anim.key_waiting(win):
                break

    # --------------------------------------------------- travel / organelles
    def travel(self):
        j = self.j
        names, ids = [], []
        for tid in TRAVEL_ORDER:
            if tid in W.GEO:
                if not logic.cell_unlocked(j, tid):
                    continue
            elif tid not in self.seen:
                continue
            names.append(self.w.names[tid])
            ids.append(tid)
        r = d.menu(self.win, "Fast travel", names, ayuda="Cells you have unlocked and places you have seen")
        if r is None:
            return
        self.pos = self.w.spawn[ids[r]]
        self.haz = None
        self.reveal()
        sound.play("gate")
        self.toast(f"You are in {names[r]}.")

    def show_upgrades(self):
        """Organelle list. Enter switches an owned organelle on or off."""
        sel = 0
        while True:
            rows = []
            for uid, u in upgrades.UPGRADES.items():
                if upgrades.owned(self.j, uid):
                    left = upgrades.charges(self.j, uid)
                    state = "faded" if left == 0 else ("ON " if upgrades.is_on(self.j, uid) else "off")
                    rows.append(f"♠ {state:<5} {u['name']:<18} {left:>3}/{u['max']:<3} {u['unit']:<15} {u['text']}")
                else:
                    where = cells.CELLS[u["cell"]]["name"] if u["cell"] in self.j["cells"] else "a cell you have not entered"
                    rows.append(f"· ? ? ?   {'':<18} hidden somewhere in {where}")
            r = d.menu(self.win, f"Organelles {len(self.j['upgrades'])}/{len(upgrades.UPGRADES)}", rows,
                       ancho=min(118, self.win.getmaxyx()[1] - 2), inicial=sel,
                       ayuda="Enter switches one on or off. Faded organelles grow back in their cell.")
            if r is None:
                return
            sel = r
            uid = list(upgrades.UPGRADES)[r]
            if upgrades.owned(self.j, uid) and upgrades.charges(self.j, uid) > 0:
                upgrades.toggle(self.j, uid)
                sound.play("blip")

    def cell_guide(self):
        cid = self.w.region_at(*self.pos)
        if cid not in W.GEO:
            d.popup(self.win, "Step inside a cell to read its guide.", "Cell guide")
            return
        geo, seen, rows = W.GEO[cid], set(), []
        for glyph, name in geo["layers"]:
            if name not in seen:
                seen.add(name)
                rows.append(f"{glyph}  {name:<24} {W.INFO[name]}")
        for name, glyph, _ in geo["zones"]:
            if name not in seen:
                seen.add(name)
                rows.append(f"{glyph}  {name:<24} {W.INFO[name]}")
        d.menu(self.win, f"Guide: {cells.CELLS[cid]['name']}", rows, ancho=min(118, self.win.getmaxyx()[1] - 2),
               ayuda=cells.CELLS[cid]["blurb"][:90])

    def toggle_flagellum(self):
        j = self.j
        if not upgrades.owned(j, "flagellum"):
            self.toast("You have no flagellum yet. Look for one in E. coli.")
        elif upgrades.charges(j, "flagellum") == 0:
            self.toast("Your flagellum has faded. A new one has grown back in E. coli.")
        else:
            on = upgrades.toggle(j, "flagellum")
            sound.play("blip")
            self.toast(f"Flagellum {'ON: you swim twice as fast' if on else 'off'} "
                       f"({upgrades.charges(j, 'flagellum')} charges left).")

    def boost(self, mv):
        """A second step in the same direction while the flagellum is on."""
        w, j = self.w, self.j
        if not upgrades.active(j, "flagellum"):
            return
        t = (self.pos[0] + mv[0], self.pos[1] + mv[1])
        if (w.walkable(*t) and t not in w.stations and t not in w.npcs and t not in w.quests
                and t not in w.gates and not (self.haz and t == (self.haz["x"], self.haz["y"]))):
            if self.step(*mv) == "moved":
                upgrades.use(j, "flagellum")

    # ----------------------------------------------------------- world map
    def show_map(self):
        win, w = self.win, self.w
        alto, ancho = win.getmaxyx()
        sy = max(1, -(-W.H // (alto - 4)))
        sx = max(1, -(-W.W // (ancho - 1)))
        win.erase()
        d.reiniciar_regiones()
        d.pantalla_completa(win, "\n")
        d.put(win, 0, 1, "WORLD MAP", d.c("titulo", curses.A_BOLD))
        d.put(win, 0, 14, "☺ you   Ω ready   ♦ deduced   ○ waiting   G Govinde   ╬ gate   ? quest   ♠ organelle",
              d.c("tenue"))
        prio = {"☺": 9, "Ω": 8, "♦": 8, "○": 7, "G": 7, "╬": 6, "?": 6, "♠": 6, "▲": 9}
        for by in range(0, W.H, sy):
            for bx in range(0, W.W, sx):
                best = None
                for y in range(by, min(W.H, by + sy)):
                    for x in range(bx, min(W.W, bx + sx)):
                        ch, at = self.tile_attr(x, y, full=True)
                        if ch == " ":
                            continue
                        if ch in "¤●√":
                            ch, at = W.FLOOR, d.c("tenue")
                        if ch in "•∙°":
                            ch, at = W.ECM, d.c("tenue")
                        p = prio.get(ch, 5 if ch == W.WALL else 2 if ch == W.BAND else 1)
                        if best is None or p > best[0]:
                            best = (p, ch, at)
                if best:
                    d.put(win, 1 + by // sy, bx // sx, best[1], best[2])
        for cid, geo in W.GEO.items():
            (cx, cy), (rx, ry) = geo["c"], geo["r"]
            name = w.names[cid] if cid in self.seen else "? ? ?"
            col = "bien" if all(logic.solved(self.j, p) for p in cells.CELLS[cid]["order"]) else "titulo"
            d.put(win, max(1, (cy - ry) // sy), max(0, (cx - len(name) // 2) // sx), name,
                  d.c(col, curses.A_BOLD) if cid in self.seen else d.c("oscuro"))
        d.put(win, alto - 2, 1, "Click or press Enter to go back.", d.c("tenue"))
        win.refresh()
        while True:
            k = d.tecla(win)
            if k in d.ENTER or k == d.ESC or d.es(k, "m", "q"):
                return

    # ---------------------------------------------------------------- loop
    def read_key(self):
        """Wait up to 150 ms for a key; None means a tick passed."""
        win = self.win
        win.timeout(150)
        try:
            k = win.get_wch()
        except curses.error:
            k = None
        win.timeout(-1)
        if k is None:
            return None
        if k == curses.KEY_MOUSE:
            return d._clic()
        if k in d.MOVIMIENTO:
            d._descartar_repetidas(win, k)
        return k

    def main_menu(self):
        j, win = self.j, self.win
        opts = ["Keep playing", "Save", f"Sound: {'on' if j.get('sound', True) else 'off'}",
                "Show / hide mini-map", "Save and quit"]
        r = d.menu(win, "Menu", opts)
        if r == 1:
            save.write(j)
            self.toast("Game saved.")
        elif r == 2:
            j["sound"] = not j.get("sound", True)
            sound.set_enabled(j["sound"])
            self.toast("Sound " + ("on." if j["sound"] else "off."))
        elif r == 3:
            self.mini = not self.mini
        elif r == 4:
            save.write(j)
            return True
        return False

    def play(self):
        j, win = self.j, self.win
        if not j["intro"]:
            d.dialogo(win, cells.GOVINDE["intro"], "Govinde")
            d.popup(win, cells.STAGES[1]["intro"], cells.STAGES[1]["name"], ancho=66)
            d.popup(win, "You are inside E. coli. Walk with the arrow keys or WASD, or click where you want "
                    "to go. Walk into an Omega station to open its pathway. Solve all of a cell's pathways to "
                    "open its membrane gate. Stressors (red triangles) will chase you once you know enough "
                    "pathways. Press M for the world map and ? for help.", "Exploring", ancho=66)
            j["intro"] = True
            save.write(j)
        moves = {curses.KEY_UP: (0, -1), curses.KEY_DOWN: (0, 1), curses.KEY_LEFT: (-1, 0),
                 curses.KEY_RIGHT: (1, 0)}
        letters = {"w": (0, -1), "s": (0, 1), "a": (-1, 0), "d": (1, 0)}
        while True:
            if upgrades.FADED:
                self.msg = ", ".join(upgrades.FADED) + " faded! A new one has grown back in its cell."
                upgrades.FADED.clear()
                sound.play("bad")
            self.draw()
            k = self.read_key()
            if k is None:
                self.tick()
                continue
            self.msg = ""
            if isinstance(k, tuple) and k and k[0] == "walk":
                self.walk((k[1], k[2]))
                self.after()
                continue
            mv = moves.get(k) or (letters.get(k.lower()) if isinstance(k, str) else None)
            if mv:
                if self.step(*mv) == "moved":
                    self.boost(mv)
                if self.msg:
                    self.after()
                if self.walked >= 160 and len(j["solved"]) >= 3:
                    self.pop_quiz()
                continue
            if isinstance(k, str) and k == "m" or k == "m":
                self.show_map()
            elif d.es(k, "f"):
                self.travel()
            elif d.es(k, "c"):
                codex.codex_menu(win, j)
                self.after()
            elif d.es(k, "h"):
                harvest.harvest(win, j)
                self.after()
            elif d.es(k, "u"):
                self.ultimatum_menu()
            elif d.es(k, "r"):
                pops.review_round(win, j)
                self.after()
            elif d.es(k, "g"):
                if ultimatum.grand_ultimatum(win, j):
                    ending.play(win, j)
                self.after()
            elif d.es(k, "l"):
                lab.lab(win, j)
                self.after()
            elif d.es(k, "o"):
                self.show_upgrades()
            elif d.es(k, "v"):
                self.toggle_flagellum()
            elif d.es(k, "e"):
                self.cell_guide()
            elif d.es(k, "j"):
                journal.show(win, j)
            elif d.es(k, "k"):
                fieldwork.tasks(win, j)
            elif d.es(k, "t"):
                atlas.show(win, j)
            elif d.es(k, "b"):
                seals.show(win, j)
            elif d.es(k, "n"):
                self.mini = not self.mini
            elif d.es(k, "?", "/"):
                G.show_help(win)
            elif d.es(k, "q") or k == d.ESC:
                if self.main_menu():
                    return
