"""Field work. Collect each component of a pathway from where it lives in the cell, carry the pathway out
at the bench (choose which component acts next, and see what it does), then arrange the events from memory."""
import curses
import random

import cells
import deduce
import dibujo as d
import logic
import pathways
import save
import sound
import sources

_TILES = {}


def _special(world):
    return (set(world.stations) | set(world.quests) | set(world.chests) | set(world.npcs) | set(world.gates)
            | set(getattr(world, "bosses", {})) | set(world.pickups))


def zone_tiles(world, cid):
    """zone name -> walkable tiles of that zone inside the cell."""
    if cid not in _TILES:
        import world as W
        (cx, cy), (rx, ry) = W.GEO[cid]["c"], W.GEO[cid]["r"]
        special, out = _special(world), {}
        for y in range(cy - ry, cy + ry + 1):
            for x in range(cx - rx, cx + rx + 1):
                if world.region[y][x] == cid and world.walkable(x, y) and (x, y) not in special:
                    out.setdefault(world.zone[y][x], []).append((x, y))
        _TILES[cid] = out
    return _TILES[cid]


def _place(tiles, used, rng):
    for _ in range(60):
        t = rng.choice(tiles)
        if all(max(abs(t[0] - u[0]), abs(t[1] - u[1])) >= 3 for u in used):
            return t
    return rng.choice(tiles)


def begin(win, j, world, pid):
    """Pay for the experiment, scatter the components. Returns True if field work started."""
    p = pathways.PATH[pid]
    cost = pathways.cost_of(pid)
    if pid not in j["paid"]:
        if not logic.can_afford(j, cost):
            d.popup(win, f"This experiment needs {logic.cost_text(cost)}. You are missing "
                         f"{logic.cost_text(logic.missing(j, cost))}. Harvest or pick up materials first.",
                    "Not enough materials", attr=d.c("mal"))
            return False
        if cost and d.menu(win, f"Start this experiment? It costs {logic.cost_text(cost)}",
                           ["Yes, start", "Not now"]) != 0:
            return False
        logic.pay(j, cost)
        j["paid"].append(pid)
    rng, cid = random.Random(), p["cell"]
    tiles = zone_tiles(world, cid)
    allt = [t for ts in tiles.values() for t in ts]
    used, parts, decoys = [], {}, {}
    for name, kind, zone in sources.components(pid, p["actors"]):
        t = _place(tiles.get(zone) or allt, used, rng)
        used.append(t)
        parts[name] = [t[0], t[1], kind, zone]
    others = []
    for q in cells.CELLS[cid]["order"]:
        if q != pid:
            for name, kind, zone in sources.components(q, pathways.PATH[q]["actors"]):
                if name not in parts:
                    others.append((name, zone))
    rng.shuffle(others)
    picks = others[:4] + [(n, "Cytoplasm") for n in rng.sample(sources.FILLERS, 3)]
    for name, zone in picks:
        if name in parts or name in decoys:
            continue
        t = _place(tiles.get(zone) or allt, used, rng)
        used.append(t)
        decoys[name] = [t[0], t[1]]
    j["field"] = dict(pid=pid, parts=parts, decoys=decoys, have=[], benched=False)
    save.write(j)
    d.popup(win, f"Field work started: {p['name']}.\n\nCollect every component from the place where it is found "
                 "(walk onto its pink heart). Look-alikes lie around too: stand next to a heart to read its name. "
                 "Press K any time to see your task list.", "Field work", ancho=70)
    tasks(win, j)
    return True


def mine(j, pid):
    f = j.get("field")
    return f if f and f["pid"] == pid else None


def complete(f):
    return len(f["have"]) == len(f["parts"])


def missing(f):
    return [n for n in f["parts"] if n not in f["have"]]


def tasks(win, j):
    f = j.get("field")
    if not f:
        d.popup(win, "No field work right now. Walk into a ready Omega station and choose 'Begin field work'.",
                "Field work")
        return
    p = pathways.PATH[f["pid"]]
    lines = [f"{p['name']}  ·  trigger: {p['trigger']}", ""]
    for name, (x, y, kind, zone) in f["parts"].items():
        lines.append(("√ " if name in f["have"] else "○ ") + f"{name} ({kind}) - found in: {zone}")
    lines += ["", "Hearts that are not on this list are look-alikes. Come back to the station when you have them all."]
    d.popup(win, "\n".join(lines), "Field work tasks", ancho=min(100, win.getmaxyx()[1] - 2))


def collect(win, j, name):
    f = j["field"]
    f["have"].append(name)
    kind, zone = f["parts"][name][2], f["parts"][name][3]
    dex = j["dex"]["parts"]
    key = f"{f['pid']}:{name}"
    if key not in dex:
        dex.append(key)
    sound.play("pickup")
    left = len(f["parts"]) - len(f["have"])
    return f"Collected {name} ({kind}) from the {zone}. " + (f"{left} to go." if left else
                                                              "That's all of them: go back to the station.")


def _hint(p, placed):
    allowed = sorted(deduce._allowed(p, placed))
    bits = []
    for i in allowed:
        kind, zone = sources.SOURCES[p["id"]][i]
        bits.append(f"a {kind} from the {zone}")
    return "Hint: the next one is " + " or ".join(dict.fromkeys(bits)) + "."


def bench(win, j, pid):
    """Carry the pathway out. Returns the number of mistakes, or None if the player left."""
    p = pathways.PATH[pid]
    st = cells.STAGES[p["stage"]]
    n = len(p["steps"])
    names = list(dict.fromkeys(p["actors"]))
    random.shuffle(names)
    placed, log, mistakes, streak = set(), [], 0, 0
    msg, attr = "Choose the component that acts first.", d.c("tenue")
    while len(placed) < n:
        alto, ancho = win.getmaxyx()
        win.erase()
        d.reiniciar_regiones()
        d.put(win, 0, 1, f"BENCH  ·  {p['name']}  ·  {cells.CELLS[p['cell']]['name']}", d.c("titulo", curses.A_BOLD))
        d.put(win, 1, 0, "─" * ancho, d.c("tenue"))
        d.put(win, 2, 1, f"Trigger: {p['trigger']}", d.c("texto", curses.A_BOLD))
        d.put(win, 3, 1, f"Result:  {p['outcome']}", d.c("texto", curses.A_BOLD))
        y = 5
        d.put(win, y, 1, f"What has happened so far ({len(placed)}/{n}):", d.c("agua", curses.A_BOLD))
        y += 1
        room = max(2, alto - 12 - len(names))
        for actor, text in log[-room:]:
            for k, l in enumerate(d.envolver(f"(P) {actor}: {text}", ancho - 4)[:2]):
                d.put(win, y, 2, l, d.c("bien"))
                y += 1
        y += 1
        d.put(win, y, 1, "Which of your components acts next?", d.c("agua", curses.A_BOLD))
        y += 1
        for i, name in enumerate(names):
            kind, zone = next((sources.SOURCES[pid][k] for k, a in enumerate(p["actors"]) if a == name))
            d.region(y, 1, 1, ancho - 2, str(i + 1))
            d.put(win, y, 2, f"{i + 1}) {name}", d.c("texto"))
            d.put(win, y, 38, f"{kind}", d.c("tenue"))
            y += 1
        for k, l in enumerate(d.envolver(msg, ancho - 4)[:2]):
            d.put(win, alto - 3 + k, 2, l, attr)
        d.fila_botones(win, alto - 1, 1, [("Hint [H]", "h", "agua"), ("Leave [Esc]", d.ESC, "mal")])
        win.refresh()
        k = d.tecla(win)
        if isinstance(k, str) and k.isdigit() and 1 <= int(k) <= len(names):
            name = names[int(k) - 1]
            ok = [i for i in sorted(deduce._allowed(p, placed)) if p["actors"][i] == name]
            if ok:
                i = ok[0]
                placed.add(i)
                log.append((name, p["steps"][i]))
                streak = 0
                msg, attr = "Yes! " + p["steps"][i], d.c("bien", curses.A_BOLD)
                sound.play("step", 30 * len(placed))
            else:
                mistakes += 1
                streak += 1
                sound.play("bad")
                msg, attr = f"{name} does nothing at this point. Think about what has just happened.", d.c("mal")
                if st["lives"] is None and streak >= 2:
                    msg += " " + _hint(p, placed)
        elif d.es(k, "h"):
            if st["lives"] is None:
                msg, attr = _hint(p, placed), d.c("agua", curses.A_BOLD)
            elif j["insight"] >= 1:
                j["insight"] -= 1
                msg, attr = _hint(p, placed) + " (-1 Insight)", d.c("agua", curses.A_BOLD)
            else:
                msg, attr = "No Insight left. Read Codex pages to earn more.", d.c("mal")
        elif k == d.ESC:
            if d.menu(win, "Leave the bench? Your components are kept.", ["Keep going", "Leave"]) == 1:
                return None
    d.popup(win, f"You carried out {p['name']}!\n\n{p['outcome']}.\n\nNow prove you understood it: arrange the "
                 "events in order from memory.", "Bench complete", ancho=64, attr=d.c("bien"))
    sound.play("good")
    return mistakes
