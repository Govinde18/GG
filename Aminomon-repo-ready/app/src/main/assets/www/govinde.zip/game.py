"""The Govinde Protocol: a cell-signalling adventure in the terminal."""
import curses
import os
import sys

import atlas
import cells
import codex
import deduce
import dibujo as d
import harvest
import lab
import logic
import pathways
import save
import seals
import ultimatum

HELP = [
    ("The goal", "Walk through a bacterium and out into the world of cells. Travel from a bacterium to the specialised cells of an animal. Each cell runs signalling, "
     "regulation, synthesis and degradation pathways. You DEDUCE a pathway by putting its events in the right "
     "order. Govinde, a friendly phage, guides you."),
    ("Field work", "Walk into a ready Omega station and choose Begin field work. Components of the pathway (enzymes, "
     "receptors, substrates) are scattered as pink hearts in the places where they really live in the cell. "
     "Collect them all, return to the station, carry the pathway out at the bench (choose which component acts "
     "next) and finally arrange the events from memory. K shows your task list."),
    ("Deducing", "At the end, you arrange the events in the right order. You are told the trigger and the "
     "result. Pick the pieces in order. In early stages wrong picks are harmless; later you have limited lives, "
     "and some pieces are decoys that belong to other pathways. Hints cost Insight."),
    ("The Codex", "Each pathway has three Codex pages. Reading a page for the first time gives +1 Insight, "
     "which buys hints. Reading also matters for the Ultimatums: they only open when you have read every page "
     "of the stage, and their questions come from those pages."),
    ("Cells and materials", "Every cell makes two raw materials. Pathways and new cells cost materials, "
     "so go back to earlier cells and Harvest: run a pathway you know and answer a quick question. Runs recover "
     "whenever you deduce a new pathway or pass an Ultimatum."),
    ("Stages and Ultimatums", "Cells unlock stage by stage. Pass Govinde's Ultimatum for a stage to open "
     "the next one. The game gets harder as you go: fewer lives, more decoys, higher pass marks."),
    ("Exploring", "Walk with the arrow keys or WASD, or click a spot to walk there. Walk into an Omega station to open its "
     "pathway. Solve every pathway of a cell to open its exit membrane gate, then cross the extracellular matrix "
     "to the next cell. Gates into new cells cost materials and need Govinde's Ultimatum. Walking over a yellow ¤ picks up "
     "raw material. M shows the world map."),
    ("Bosses and the journal", "Each stage has a boss stressor, a red Zh that appears in its cell once you know the "
     "pathways it tests. Answer a chain of stresses with limited lives. Winning recharges every organelle and pays "
     "well. J opens your journal: structures, stressors, bosses, components and quests you have discovered."),
    ("Stressors", "Once you know a few pathways, red triangles roam the cell: UV light, starvation, a growth "
     "factor... Walk into one and pick the pathway that answers it. Right answers pay materials; wrong ones "
     "cost a little and the pathway comes back in your pop quizzes and Ultimatums. Esc slips away."),
    ("Quests and organelles", "A yellow ? is a crosstalk quest that needs two pathways you have deduced. A "
     "magenta spade hides an organelle that upgrades you: flagellum, ribosome, chloroplast, mitochondrion, "
     "chaperone, extra receptor, vesicle. Each has limited charges and can be switched on or off (O). When "
     "one fades, a new one grows back in its cell. Press V to swim fast with the flagellum, E for the cell guide."),
    ("Controls", "Arrows/WASD move, click to walk, M map, F fast travel, N mini-map, V swim, E cell guide, J journal, K tasks, C Codex, H harvest, "
     "U Ultimatums, R review round, L Crosstalk Lab, O organelles, T Atlas, B Seals, ? help, Q menu."),
]


def wait_for_size(win):
    while True:
        alto, ancho = win.getmaxyx()
        if alto >= 24 and ancho >= 80:
            return
        win.erase()
        d.put(win, 0, 0, f"Please enlarge the window to at least 80x24 (now {ancho}x{alto}).")
        win.refresh()
        d.tecla(win)


def show_help(win):
    for i, (title, text) in enumerate(HELP, 1):
        win.erase()
        d.popup(win, text, f"How to play {i}/{len(HELP)} · {title}", ancho=76)


class Game:
    def __init__(self, win, j):
        self.win, self.j = win, j
        self.sel = 0
        self.msg = ""
        if j["cell"] not in cells.CELLS:
            j["cell"] = "ecoli"

    # ------------------------------------------------------------ helpers
    @property
    def cell(self):
        return self.j["cell"]

    def order(self):
        return cells.CELLS[self.cell]["order"]

    def cell_state(self, cid):
        c = cells.CELLS[cid]
        if logic.cell_unlocked(self.j, cid):
            return "open"
        return "available" if logic.stage_open(self.j, c["stage"]) else "locked"

    # ------------------------------------------------------------ drawing
    def draw(self):
        w, j = self.win, self.j
        alto, ancho = w.getmaxyx()
        w.erase()
        d.reiniciar_regiones()
        cell = cells.CELLS[self.cell]
        st = cells.STAGES[cell["stage"]]
        d.put(w, 0, 1, "THE GOVINDE PROTOCOL", d.c("titulo", curses.A_BOLD))
        head = f"{cell['name']}  ·  {st['name']}"
        d.put(w, 0, max(24, ancho - len(head) - 2), head, d.c("agua", curses.A_BOLD))
        mats = "  ".join(f"{cells.SHORT[m]} {j['mats'][m]}" for m in cells.MATERIALS)
        d.put(w, 1, 1, mats, d.c("texto"))
        extra = f"Insight {j['insight']}   ♦ {logic.total_stars(j)}   Solved {len(j['solved'])}/{len(pathways.ALL)}"
        d.put(w, 1, max(len(mats) + 4, ancho - len(extra) - 2), extra, d.c("POL"))
        d.put(w, 2, 0, "─" * ancho, d.c("tenue"))
        # cells list
        y = 3
        last_stage = 0
        for cid in cells.CELL_ORDER:
            c = cells.CELLS[cid]
            if c["stage"] != last_stage:
                last_stage = c["stage"]
                d.put(w, y, 1, f"{cells.STAGES[last_stage]['domain'][:4]}. stage {last_stage}", d.c("oscuro"))
                y += 1
            stt = self.cell_state(cid)
            mark = {"open": "●", "available": "○", "locked": "×"}[stt]
            name = c["name"] if stt != "locked" else "? ? ?"
            attr = d.c("titulo", curses.A_BOLD) if cid == self.cell else d.c("texto" if stt == "open" else "tenue")
            if cid == self.cell:
                attr |= curses.A_REVERSE
            d.put(w, y, 1, f" {mark} {name:<26}"[:30], attr)
            d.region(y, 0, 1, 31, ("cell", cid))
            y += 1
        # pathway list
        x = 34
        pw = ancho - x - 1
        d.put(w, 3, x, f"PATHWAYS in {cell['name'] if self.cell_state(self.cell) != 'locked' else '? ? ?'}",
              d.c("agua", curses.A_BOLD))
        unlocked = logic.cell_unlocked(j, self.cell)
        for i, pid in enumerate(self.order()):
            p = pathways.PATH[pid]
            state = logic.path_state(j, pid)
            if state == "solved":
                stars = logic.stars(j, pid)
                left = "♦" * stars + "◊" * (3 - stars)
                color = "bien"
            elif state == "ready":
                left, color = " ► ", "titulo"
            elif state == "sequence":
                left, color = " ▫ ", "tenue"
            else:
                left, color = " ? ", "oscuro"
            name = p["name"] if unlocked else "? ? ?"
            row = f"{left}  {name:<40} {p['kind'] if unlocked else '':<12} read {logic.pages_read(j, pid)}/3" if unlocked \
                else f"{left}  {name}"
            attr = d.c(color, curses.A_BOLD if i == self.sel else 0)
            if i == self.sel:
                attr |= curses.A_REVERSE
            d.put(w, 4 + i, x, row[:pw].ljust(min(pw, 74)), attr)
            d.region(4 + i, x, 1, pw, ("path", i))
        # detail box
        top = 5 + len(self.order())
        top = max(top, 4 + 8)
        h = alto - top - 4
        if h >= 5:
            d.caja(w, top, x, h, pw, "Details")
            self.draw_detail(top + 1, x + 2, pw - 4, h - 2)
        # message and buttons
        if self.msg:
            d.put(w, alto - 3, 1, self.msg[: ancho - 2], d.c("agua"))
        btn = [("Deduce [D]", "d", "bien"), ("Codex [C]", "c", "POL"), ("Harvest [H]", "h", "titulo"),
               ("Ultimatum [U]", "u", "mal"), ("Lab [L]", "l", "agua"), ("Atlas [A]", "a", "tenue"),
               ("Seals [S]", "s", "tenue"), ("Help [?]", "?", "tenue"), ("Quit [Q]", "q", "tenue")]
        d.fila_botones(w, alto - 2, 1, btn, ancho - 2)
        w.refresh()

    def draw_detail(self, y, x, w, h):
        j, win = self.j, self.win
        cell = cells.CELLS[self.cell]
        lines = []
        stt = self.cell_state(self.cell)
        if stt != "open":
            cost = cell["cost"]
            lines.append((f"{cell['name']}: {cell['kind']}", "titulo"))
            lines.append((cell["blurb"], "texto"))
            lines.append((f"Makes: {', '.join(cell['makes'])}", "agua"))
            lines.append((f"Unlock cost: {logic.cost_text(cost)}", "texto"))
            if stt == "locked":
                prev = cells.STAGES[cell["stage"] - 1]["name"]
                lines.append((f"Locked: pass the Ultimatum of '{prev}' first.", "mal"))
            else:
                ok = logic.can_afford(j, cost)
                lines.append(("Press Enter or click to unlock this cell." if ok else
                              f"Missing: {logic.cost_text(logic.missing(j, cost))}. Harvest in earlier cells.",
                              "bien" if ok else "mal"))
        else:
            pid = self.order()[self.sel]
            p = pathways.PATH[pid]
            state = logic.path_state(j, pid)
            lines.append((f"{p['name']}  ·  {p['kind']}", "titulo"))
            if state == "sequence":
                prev = pathways.PATH[logic.previous_in_cell(pid)]["name"]
                lines.append((f"Deduce '{prev}' first to unlock this one.", "tenue"))
            else:
                lines.append((f"Trigger: {p['trigger']}", "texto"))
                lines.append((f"Result:  {p['outcome']}", "texto"))
            cost = pathways.cost_of(pid)
            if state == "ready" and pid not in j["paid"]:
                ok = logic.can_afford(j, cost)
                lines.append((f"Experiment cost: {logic.cost_text(cost)}" + ("" if ok else
                              f"  (missing {logic.cost_text(logic.missing(j, cost))})"),
                              "texto" if ok else "mal"))
            if state == "solved":
                lines.append((f"Deduced with {logic.stars(j, pid)} star(s). Enter to review, or Harvest it.", "bien"))
            elif state == "ready":
                lines.append(("Press Enter or Deduce to assemble it. Read the Codex for hints.", "bien"))
        for line, color in lines:
            for l in d.envolver(line, w):
                if h <= 0:
                    return
                d.put(win, y, x, l, d.c(color))
                y += 1
                h -= 1

    # ---------------------------------------------------------- actions
    def toast(self, text):
        self.msg = text

    def after(self):
        seals.check(self.win, self.j)
        save.write(self.j)

    def pick_cell(self, cid):
        """Select a cell. Clicking the already selected, still locked cell tries to unlock it."""
        if cid == self.cell and self.cell_state(cid) == "available":
            self.unlock_cell(cid)
            return
        self.j["cell"] = cid
        self.sel = 0
        if self.cell_state(cid) == "available":
            self.toast("Press Enter (or click the cell again) to unlock it.")

    def unlock_cell(self, cid):
        j = self.j
        c = cells.CELLS[cid]
        if not logic.can_afford(j, c["cost"]):
            self.toast(f"To unlock {c['name']} you need {logic.cost_text(c['cost'])}. "
                       f"Missing: {logic.cost_text(logic.missing(j, c['cost']))}.")
            return
        if d.menu(self.win, f"Unlock {c['name']}? It costs {logic.cost_text(c['cost'])}",
                  ["Yes, unlock it", "Not yet"]) != 0:
            return
        logic.pay(j, c["cost"])
        j["cells"].append(cid)
        first_in_stage = sum(1 for x in j["cells"] if cells.CELLS[x]["stage"] == c["stage"]) == 1
        d.popup(self.win, f"{c['name']} unlocked!\n\n{c['blurb']}\nIt makes: {', '.join(c['makes'])}.",
                "New cell", ancho=60, attr=d.c("bien"))
        if first_in_stage and c["stage"] > 1:
            d.popup(self.win, cells.STAGES[c["stage"]]["intro"], cells.STAGES[c["stage"]]["name"], ancho=66)
        self.after()

    def open_path(self):
        j = self.j
        if not logic.cell_unlocked(j, self.cell):
            if self.cell_state(self.cell) == "available":
                self.unlock_cell(self.cell)
            return
        pid = self.order()[self.sel]
        state = logic.path_state(j, pid)
        opts = []
        acts = []
        if state in ("ready", "solved"):
            opts.append("Deduce this pathway" if state == "ready" else "Review the deduced pathway")
            acts.append("deduce")
        opts.append("Read its Codex pages")
        acts.append("codex")
        if state == "solved":
            opts.append("Harvest from it")
            acts.append("harvest")
        opts.append("Back")
        acts.append("back")
        r = d.menu(self.win, pathways.PATH[pid]["name"], opts)
        if r is None or acts[r] == "back":
            return
        if acts[r] == "deduce":
            self.run_deduce(pid)
        elif acts[r] == "codex":
            got = codex.read_pathway(self.win, j, pid)
            if got:
                self.toast(f"+{got} Insight from reading.")
            self.after()
        elif acts[r] == "harvest":
            harvest.harvest(self.win, j)
            self.after()

    def run_deduce(self, pid):
        state = logic.path_state(self.j, pid)
        if state == "sequence":
            self.toast("Deduce the previous pathway of this cell first.")
            return
        if state == "nocell":
            self.toast("Unlock this cell first.")
            return
        result = deduce.deduce(self.win, self.j, pid)
        if result == "solved" and self.sel < len(self.order()) - 1:
            self.sel += 1
        self.after()

    def ultimatum_menu(self):
        j = self.j
        rows, ids = [], []
        for s, st in cells.STAGES.items():
            mark = "√" if s in j["ultimatums"] else " "
            block = logic.ultimatum_blockers(j, s)
            rows.append(f"{mark} {st['name']:<34} " + ("ready" if not block and s not in j["ultimatums"]
                                                          else "passed" if s in j["ultimatums"] else "not ready"))
            ids.append(s)
        rows.append(("√ " if j["final"] else "  ") + f"{cells.FINAL['name']}")
        sel = d.menu(self.win, "Govinde's Ultimatums", rows, ancho=70,
                     ayuda="Every pathway deduced and every Codex page read")
        if sel is None:
            return
        if sel == len(ids):
            ultimatum.grand_ultimatum(self.win, j)
        else:
            ultimatum.stage_ultimatum(self.win, j, ids[sel])
        self.after()

    # -------------------------------------------------------------- loop
    def play(self):
        j = self.j
        if not j["intro"]:
            d.dialogo(self.win, cells.GOVINDE["intro"], "Govinde")
            d.popup(self.win, cells.STAGES[1]["intro"], cells.STAGES[1]["name"], ancho=66)
            j["intro"] = True
            show_help(self.win)
            save.write(j)
        while True:
            self.draw()
            k = d.tecla(self.win)
            self.msg = ""
            n = len(self.order())
            if isinstance(k, tuple) and k:
                if k[0] == "cell":
                    self.pick_cell(k[1])
                elif k[0] == "path":
                    if self.sel == k[1]:
                        self.open_path()
                    self.sel = k[1]
                continue
            if d.es(k, curses.KEY_DOWN, "j", "s") and not d.es(k, "s"):
                self.sel = (self.sel + 1) % n
            elif k == curses.KEY_DOWN or d.es(k, "j"):
                self.sel = (self.sel + 1) % n
            elif k == curses.KEY_UP or d.es(k, "k", "w"):
                self.sel = (self.sel - 1) % n
            elif k == curses.KEY_RIGHT or k == "\t":
                i = cells.CELL_ORDER.index(self.cell)
                self.pick_cell(cells.CELL_ORDER[(i + 1) % len(cells.CELL_ORDER)])
            elif k == curses.KEY_LEFT:
                i = cells.CELL_ORDER.index(self.cell)
                self.pick_cell(cells.CELL_ORDER[(i - 1) % len(cells.CELL_ORDER)])
            elif k in d.ENTER:
                self.open_path()
            elif d.es(k, "d"):
                if logic.cell_unlocked(j, self.cell):
                    self.run_deduce(self.order()[self.sel])
                else:
                    self.open_path()
            elif d.es(k, "c"):
                codex.codex_menu(self.win, j)
                self.after()
            elif d.es(k, "h"):
                harvest.harvest(self.win, j)
                self.after()
            elif d.es(k, "u"):
                self.ultimatum_menu()
            elif d.es(k, "g"):
                ultimatum.grand_ultimatum(self.win, j)
                self.after()
            elif d.es(k, "l"):
                lab.lab(self.win, j)
                self.after()
            elif d.es(k, "a"):
                atlas.show(self.win, j)
            elif d.es(k, "s"):
                seals.show(self.win, j)
            elif d.es(k, "?", "/"):
                show_help(self.win)
            elif d.es(k, "q") or k == d.ESC:
                r = d.menu(self.win, "Menu", ["Keep playing", "Save", "Save and quit"])
                if r == 1:
                    save.write(j)
                    self.toast("Game saved.")
                elif r == 2:
                    save.write(j)
                    return


LOGO = [
    r"  ___  _____   _____ _  _ ___  ___  ",
    r" / __|/ _ \ \ / /_ _| \| |   \| __| ",
    r"| (_ | (_) \ V / | || .` | |) | _|  ",
    r" \___|\___/ \_/ |___|_|\_|___/|___| ",
]


def title(win):
    import anim
    anim.title_intro(win)
    has_save = save.load() is not None
    while True:
        alto, ancho = win.getmaxyx()
        win.erase()
        d.reiniciar_regiones()
        y0 = max(1, alto // 2 - 9)
        for i, l in enumerate(LOGO):
            d.put(win, y0 + i, (ancho - len(LOGO[0])) // 2, l, d.c(["NP", "ARO", "POL", "POS"][i], curses.A_BOLD))
        sub = "THE PROTOCOL  ·  a cell-signalling odyssey from bacteria to specialised cells"
        d.put(win, y0 + 5, (ancho - len(sub)) // 2, sub, d.c("tenue"))
        phage = "Govinde the phage will guide you."
        d.put(win, y0 + 7, (ancho - len(phage)) // 2, phage, d.c("agua"))
        options = (["Continue"] if has_save else []) + ["New game", "How to play", "Quit"]
        r = d.menu(win, None, options, y=y0 + 9, clic_fuera=False)
        if r is None:
            return "quit"
        name = options[r]
        if name == "How to play":
            show_help(win)
        elif name == "New game":
            if has_save and d.menu(win, "Start over? Your saved game will be replaced.",
                                   ["Keep my saved game", "Start a new game"]) != 1:
                continue
            return "new"
        else:
            return name.lower()


def main(win):
    curses.curs_set(0)
    d.init_colores()
    win.keypad(True)
    d.iniciar_raton(True)
    win.idcok(False)
    win.idlok(False)
    if hasattr(curses, "set_escdelay"):
        curses.set_escdelay(25)
    wait_for_size(win)
    choice = title(win)
    if choice == "quit":
        return
    j = save.load() if choice == "continue" else save.new()
    import sound
    sound.set_enabled(j.get("sound", True))
    import explore
    explore.Explorer(win, j).play()


if __name__ == "__main__":
    import locale
    locale.setlocale(locale.LC_ALL, "")
    try:
        curses.wrapper(main)
    except Exception:
        import traceback
        text = traceback.format_exc()
        try:
            with open(os.path.expanduser("~/govinde-error.txt"), "w", encoding="utf-8") as f:
                f.write(text)
        except OSError:
            pass
        print(text)
        input("The game closed because of an error (saved to ~/govinde-error.txt). Press Enter...")
        sys.exit(1)
