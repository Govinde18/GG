"""Harvesting raw materials from pathways you already deduced (so earlier cells stay useful)."""
import random

import cells
import dibujo as d
import logic
import pathways
import quiz
import save
import sound
import upgrades

PER_REFILL = 2


def per(j):
    return PER_REFILL + (1 if upgrades.active(j, "mitochondrion") else 0)


def _question(p):
    n, w = p["note"], p["whatif"]
    return random.choice([(n["q"], n["a"], n["wrong"], None), (w["q"], w["a"], w["wrong"], w["why"])])


def harvest(win, j):
    solved = [pid for cid in cells.CELL_ORDER for pid in cells.CELLS[cid]["order"] if pid in j["solved"]]
    if not solved:
        d.popup(win, "Deduce a pathway first. Running a pathway you understand lets you harvest the "
                     "materials its cell produces.", "Harvest")
        return
    rows = []
    for pid in solved:
        p = pathways.PATH[pid]
        cell = cells.CELLS[p["cell"]]
        makes = " + ".join(f"2 {cells.SHORT[m]}" for m in cell["makes"])
        rows.append(f"{p['name']:<32} {cell['name']:<24} {makes:<12} runs left: {logic.harvest_left(j, pid, per(j))}")
    sel = d.menu(win, "Harvest: run a pathway you know", rows, ancho=min(96, win.getmaxyx()[1] - 2),
                 ayuda="Answer a quick question: right = full yield, wrong = half. Runs recover when you deduce.")
    if sel is None:
        return
    pid = solved[sel]
    if logic.harvest_left(j, pid, per(j)) <= 0:
        d.popup(win, "This pathway needs time to recover. Deduce a new pathway or pass an Ultimatum.",
                "Harvest")
        return
    p = pathways.PATH[pid]
    cell = cells.CELLS[p["cell"]]
    q, a, wrong, why = _question(p)
    ok = quiz.ask(win, f"Harvest · {p['name']}", q, a, wrong, why, allow_exit=True)
    if ok is None:
        return
    j["used"][pid] = j["used"].get(pid, 0) + 1
    if j["used"][pid] > PER_REFILL:
        upgrades.use(j, "mitochondrion")
    bonus = 1 if (ok and upgrades.active(j, "ribosome")) else 0
    if bonus:
        upgrades.use(j, "ribosome")
    got = {m: 2 + bonus for m in cell["makes"]} if ok else {cell["makes"][0]: 1}
    if ok:
        logic.weak_ok(j, pid)
    else:
        logic.weak_add(j, pid)
    sound.play("pickup")
    logic.gain(j, got)
    save.count(j, "harvests")
    save.write(j)
    d.popup(win, "Harvested: " + ", ".join(f"+{n} {m}" for m, n in got.items()), "Harvest",
            ancho=50, attr=d.c("bien" if ok else "tenue"))
