"""Roaming stressors. Each is answered by a pathway you have already deduced."""
import random

import cells
import logic
import pathways
import quiz
import save
import sound
import stress
import upgrades
import world as W

BY_PATH = {s[0]: s for s in stress.STRESS}


def eligible(j, cid):
    """Stressors of this cell whose answer the player has deduced (and at least 3 pathways solved)."""
    if len(j["solved"]) < 3:
        return []
    return [BY_PATH[p] for p in cells.CELLS[cid]["order"] if p in j["solved"] and p in BY_PATH]


def spawn(w, j, cid, player, rng):
    opts = eligible(j, cid)
    if not opts:
        return None
    geo = W.GEO[cid]
    (cx, cy), (rx, ry) = geo["c"], geo["r"]
    tiles = [(x, y) for y in range(cy - ry + 2, cy + ry - 1) for x in range(cx - rx + 2, cx + rx - 1)
             if w.region[y][x] == cid and w.walkable(x, y) and (x, y) not in w.stations
             and (x, y) not in w.gates and abs(x - player[0]) + abs(y - player[1]) >= 8]
    near = [t for t in tiles if abs(t[0] - player[0]) + abs(t[1] - player[1]) <= 26]
    tiles = near or tiles
    if not tiles:
        return None
    x, y = rng.choice(tiles)
    return dict(x=x, y=y, s=rng.choice(opts), cell=cid)


def move(h, w, player, rng):
    """One step: toward the player about half of the time, otherwise random. Stays in its cell."""
    solid = set(w.stations) | set(w.npcs) | set(w.gates)
    cand = [(h["x"] + dx, h["y"] + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))]
    cand = [c for c in cand if w.walkable(*c) and w.region_at(*c) == h["cell"] and c not in solid]
    if not cand:
        return
    if rng.random() < 0.5:
        cand.sort(key=lambda c: abs(c[0] - player[0]) + abs(c[1] - player[1]))
        h["x"], h["y"] = cand[0]
    else:
        h["x"], h["y"] = rng.choice(cand)


def encounter(win, j, h):
    """Returns 'won', 'lost' or 'fled'."""
    pid, name, text = h["s"]
    p = pathways.PATH[pid]
    stage = p["stage"]
    pool = [x for x in j["solved"] if x != pid and x in pathways.PATH]
    pool.sort(key=lambda x: (pathways.PATH[x]["cell"] != p["cell"], random.random()))
    wrong = [pathways.PATH[x]["name"] for x in pool[:3]]
    sound.play("hazard")
    if name not in j["dex"]["stress"]:
        j["dex"]["stress"].append(name)
    ok = quiz.ask(win, f"STRESS: {name}", text + "\n\nWhich of your pathways answers this?",
                  p["name"], wrong, f"{p['name']}: {p['outcome']}.", allow_exit=True)
    if ok is None:
        return "fled"
    if ok:
        logic.weak_ok(j, pid)
        mult = 2 if upgrades.active(j, "vesicle") else 1
        if mult == 2:
            upgrades.use(j, "vesicle")
        mat = random.choice(cells.CELLS[p["cell"]]["makes"])
        logic.gain(j, {mat: 2 * mult})
        first = name not in j["told"]
        if first:
            j["told"].append(name)
            j["insight"] += mult
        save.count(j, "hazards")
        sound.play("good")
        return "won"
    logic.weak_add(j, pid, 2)
    sound.play("bad")
    if stage >= 2:
        have = [m for m in cells.MATERIALS if j["mats"].get(m, 0) > 0]
        if have:
            j["mats"][random.choice(have)] -= 1
    return "lost"
