"""English-only text helper used by the shared UI toolkit (dibujo.py)."""

_TEXTOS = {"grupo R: ": "R group: ", "[Enter] seguir": "[Enter] continue",
           "Borrar": "Delete", "Enviar": "Send"}


def tr(texto, **campos):
    texto = _TEXTOS.get(texto, texto)
    return texto.format(**campos) if campos else texto
