"""The journal / bestiary: structures, stressors, bosses, components and quests you have met."""
import cells
import dibujo as d
import pathways
import quests
import stress
import world as W
import bosses

BY_STRESS = {s[1]: s for s in stress.STRESS}


def _structures():
    names = {}
    for geo in W.GEO.values():
        for glyph, n in geo["layers"]:
            names.setdefault(n, glyph)
        for n, glyph, _ in geo["zones"]:
            names.setdefault(n, glyph)
    return names


def _menu(win, title, rows, details=None, ancho=None):
    """List with optional detail popups; Esc returns."""
    sel = 0
    while True:
        r = d.menu(win, title, rows, ancho=ancho or min(116, win.getmaxyx()[1] - 2), inicial=sel)
        if r is None:
            return
        sel = r
        if details and details[r]:
            d.popup(win, details[r], rows[r][:60], ancho=76)


def show(win, j):
    dex = j["dex"]
    struct = _structures()
    parts_total = sum(len(set(pathways.PATH[p]["actors"])) for p in pathways.PATH)
    while True:
        cats = [f"Structures      {len([n for n in struct if n in dex['zones']])}/{len(struct)}",
                f"Stressors       {len(dex['stress'])}/{len(stress.STRESS)}",
                f"Bosses          {len(dex['bosses'])}/{len(bosses.BOSSES)}",
                f"Components      {len(dex['parts'])}/{parts_total}",
                f"Quests          {len(j['quests'])}/{len(quests.QUESTS)}"]
        r = d.menu(win, "Govinde's Journal", cats, ancho=60, ayuda="Everything you discover is written here")
        if r is None:
            return
        if r == 0:
            rows, det = [], []
            for n, g in sorted(struct.items(), key=lambda kv: kv[0]):
                if n in dex["zones"]:
                    rows.append(f"{g}  {n:<26} {W.INFO[n]}")
                    det.append(f"{n}\n\n{W.INFO[n]}")
                else:
                    rows.append("?  ? ? ?")
                    det.append(None)
            _menu(win, "Structures you have walked through", rows, det)
        elif r == 1:
            rows, det = [], []
            for pid, name, text in stress.STRESS:
                if name in dex["stress"]:
                    p = pathways.PATH[pid]
                    rows.append(f"{name:<22} answered by {p['name']}")
                    det.append(f"{name}\n\n{text}\n\nAnswer: {p['name']}\n{p['outcome']}.")
                else:
                    rows.append("? ? ?")
                    det.append(None)
            _menu(win, "Stressors you have met", rows, det)
        elif r == 2:
            rows, det = [], []
            for b in bosses.BOSSES:
                if b["id"] in dex["bosses"]:
                    rows.append(f"{b['name']:<24} {b['fact']}")
                    det.append(f"{b['name']}\n\n{b['intro']}\n\n{b['fact']}")
                else:
                    rows.append(f"? ? ?   Stage {b['stage']} boss, waits in {cells.CELLS[b['cell']]['name']}")
                    det.append(None)
            _menu(win, "Bosses", rows, det)
        elif r == 3:
            rows, pids = [], []
            for cid in cells.CELL_ORDER:
                for pid in cells.CELLS[cid]["order"]:
                    got = [k for k in dex["parts"] if k.startswith(pid + ":")]
                    tot = len(set(pathways.PATH[pid]["actors"]))
                    rows.append(f"{pathways.PATH[pid]['name']:<38} {len(got)}/{tot}")
                    pids.append(pid)
            sel = 0
            while True:
                k = d.menu(win, "Components by pathway", rows, ancho=min(80, win.getmaxyx()[1] - 2), inicial=sel)
                if k is None:
                    break
                sel = k
                pid = pids[k]
                import sources
                p = pathways.PATH[pid]
                lines = []
                for name, kind, zone in sources.components(pid, p["actors"]):
                    if f"{pid}:{name}" in dex["parts"]:
                        lines.append(f"√ {name} ({kind}) - {zone}")
                    else:
                        lines.append("○ ? ? ?")
                d.popup(win, "\n".join(lines), p["name"], ancho=76)
        else:
            rows, det = [], []
            for q in quests.QUESTS:
                if q["id"] in j["quests"]:
                    rows.append(f"{q['title']:<24} {q['a']}")
                    det.append(f"{q['title']}\n\n{q['q']}\n\nAnswer: {q['a']}\n\n{q['why']}")
                else:
                    rows.append(f"? ? ?   a crosstalk quest in {cells.CELLS[q['cell']]['name']}")
                    det.append(None)
            _menu(win, "Crosstalk quests", rows, det)
