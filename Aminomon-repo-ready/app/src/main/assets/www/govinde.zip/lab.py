"""Govinde's Crosstalk Lab: questions that link two pathways you already deduced.
Each one solved for the first time gives Insight and a handful of materials."""
import random

import cells
import dibujo as d
import pathways
import quiz
import save

PAIRS = [
    ("glycolysis", "fermentation",
     "Fermentation regenerates which molecule so that glycolysis can keep running without oxygen?",
     "NAD+", ["ATP", "Pyruvate", "Glucose-6-phosphate"],
     "GAPDH needs NAD+ at every turn. Fermentation reduces pyruvate-derived products to give it back."),
    ("light_reactions", "calvin_cycle",
     "Which two products of the light reactions power the Calvin cycle?",
     "ATP and NADPH", ["NADH and FADH2", "Oxygen and glucose", "CO2 and water"],
     "The Calvin cycle spends ATP and NADPH to reduce 3-phosphoglycerate to sugar."),
    ("gpcr_camp_pka", "glucagon_glycogenolysis",
     "Which second messenger links the glucagon receptor to the activation of glycogen phosphorylase?",
     "cAMP", ["IP3", "Ca2+ released from the ER", "PIP3"],
     "Glucagon acts through Gs, adenylyl cyclase and cAMP, which activates PKA and then phosphorylase kinase."),
    ("rtk_ras_mapk", "pi3k_akt",
     "Which small GTPase can bind PI3K and so link the MAPK pathway to the Akt pathway?",
     "Ras", ["Gs", "Rab5", "Ran"],
     "Active Ras-GTP binds the catalytic subunit of PI3K, so growth factors can switch on both branches."),
    ("insulin_glycogen", "glucagon_glycogenolysis",
     "Which statement correctly contrasts insulin and glucagon in the liver?",
     "Insulin favours glycogen synthesis, glucagon favours glycogen breakdown",
     ["Both stimulate glycogen breakdown", "Insulin raises cAMP while glucagon lowers it",
      "Glucagon activates Akt while insulin activates PKA"],
     "The fed state (insulin) stores glucose as glycogen. The fasted state (glucagon) releases it."),
    ("p53_damage", "intrinsic_apoptosis",
     "When DNA damage cannot be repaired, p53 can switch on which pro-apoptotic genes?",
     "PUMA and BAX", ["Cyclin D and CDK4", "Mdm2 and Akt", "Ras and Raf"],
     "p53 induces PUMA and BAX, which push the cell into mitochondrial (intrinsic) apoptosis."),
    ("autophagy", "ubiquitin_proteasome",
     "Which system removes whole organelles and large aggregates, rather than single tagged proteins?",
     "Autophagy", ["The 26S proteasome", "Deubiquitinases", "The signal peptidase"],
     "The proteasome threads single unfolded proteins into its core. Autophagy engulfs bulk cargo."),
    ("synaptic_transmission", "ltp",
     "Which postsynaptic receptor is blocked by Mg2+ at the resting potential and is key for LTP?",
     "The NMDA receptor", ["The AMPA receptor", "The GABA-A receptor", "The nicotinic receptor"],
     "Glutamate plus depolarisation relieves the Mg2+ block so Ca2+ can enter and trigger LTP."),
    ("envz_ompr", "sporulation_phosphorelay",
     "What phospho-signalling chemistry do two-component systems and the Bacillus phosphorelay share?",
     "Phosphate moves from a histidine to an aspartate",
     ["Phosphate moves from tyrosine to serine", "Phosphate moves from GTP to a lipid",
      "Phosphate is added to cAMP"],
     "Histidine kinases autophosphorylate on His and pass the phosphate to an Asp on a response regulator."),
]


def lab(win, j):
    avail = [i for i, p in enumerate(PAIRS) if p[0] in j["solved"] and p[1] in j["solved"]]
    if not avail:
        d.popup(win, "The Crosstalk Lab opens when you have deduced both pathways of a pair. Keep deducing!",
                "Crosstalk Lab")
        return
    rows = []
    for i in avail:
        a, b = pathways.PATH[PAIRS[i][0]]["name"], pathways.PATH[PAIRS[i][1]]["name"]
        rows.append(("√ " if i in j["crosstalk"] else "  ") + f"{a}  <->  {b}")
    sel = d.menu(win, f"Crosstalk Lab ({len(j['crosstalk'])}/{len(PAIRS)})", rows,
                 ancho=min(90, win.getmaxyx()[1] - 2), ayuda="Answer to link two pathways. First time: +1 Insight and materials.")
    if sel is None:
        return
    i = avail[sel]
    _, _, q, a, wrong, why = PAIRS[i]
    ok = quiz.ask(win, "Crosstalk", q, a, wrong, why)
    if ok and i not in j["crosstalk"]:
        j["crosstalk"].append(i)
        j["insight"] += 1
        got = random.choice(cells.MATERIALS)
        j["mats"][got] += 2
        save.write(j)
        d.popup(win, f"Link made! +1 Insight and +2 {got}.", "Crosstalk Lab", ancho=50, attr=d.c("bien"))
