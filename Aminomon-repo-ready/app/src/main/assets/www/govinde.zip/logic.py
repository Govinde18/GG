"""Rules of the game, independent of the screen."""
import cells
import pathways

STAGE_MAX = max(cells.STAGES)


def cost_text(cost):
    return ", ".join(f"{n} {m}" for m, n in cost.items()) or "free"


def can_afford(j, cost):
    return all(j["mats"].get(m, 0) >= n for m, n in cost.items())


def missing(j, cost):
    return {m: n - j["mats"].get(m, 0) for m, n in cost.items() if j["mats"].get(m, 0) < n}


def pay(j, cost):
    for m, n in cost.items():
        j["mats"][m] -= n


def gain(j, bundle):
    for m, n in bundle.items():
        j["mats"][m] = j["mats"].get(m, 0) + n


def solved(j, pid):
    return pid in j["solved"]


def stars(j, pid):
    return j["solved"].get(pid, {}).get("stars", 0)


def cell_unlocked(j, cid):
    return cid in j["cells"]


def stage_open(j, stage):
    """A stage opens when the Ultimatum of the stage before it is passed."""
    return stage == 1 or (stage - 1) in j["ultimatums"]


def previous_in_cell(pid):
    order = cells.CELLS[pathways.PATH[pid]["cell"]]["order"]
    i = order.index(pid)
    return order[i - 1] if i else None


def path_state(j, pid):
    """'solved', 'ready', 'sequence' (needs the previous pathway) or 'nocell'."""
    p = pathways.PATH[pid]
    if not cell_unlocked(j, p["cell"]):
        return "nocell"
    if solved(j, pid):
        return "solved"
    prev = previous_in_cell(pid)
    if prev and not solved(j, prev):
        return "sequence"
    return "ready"


def pages_read(j, pid):
    return len(j["read"].get(pid, []))


def stage_solved(j, stage):
    return all(solved(j, p) for p in pathways.stage_paths(stage))


def stage_unread(j, stage):
    return [p for p in pathways.stage_paths(stage) if pages_read(j, p) < 3]


def ultimatum_blockers(j, stage):
    """List of reasons the Ultimatum is not available yet."""
    out = []
    if not stage_open(j, stage):
        out.append("The previous Ultimatum is not passed yet.")
    unsolved = [p for p in pathways.stage_paths(stage) if not solved(j, p)]
    if unsolved:
        out.append("Pathways still to deduce: " + ", ".join(pathways.PATH[p]["name"] for p in unsolved))
    unread = stage_unread(j, stage)
    if unread:
        out.append("Codex pages still unread in: " + ", ".join(pathways.PATH[p]["name"] for p in unread))
    return out


def final_blockers(j):
    out = []
    for s in cells.STAGES:
        if s not in j["ultimatums"]:
            out.append(f"{cells.STAGES[s]['name']}: Ultimatum not passed")
    return out


def refill(j):
    j["used"] = {}
    j["picked"] = []


def harvest_left(j, pid, per=2):
    return per - j["used"].get(pid, 0)


def total_stars(j):
    return sum(v.get("stars", 0) for v in j["solved"].values())


# ---- weak spots (spaced repetition): pathway id -> how much it needs review
def weak_add(j, pid, n=1):
    j["weak"][pid] = min(6, j["weak"].get(pid, 0) + n)


def weak_ok(j, pid):
    if pid in j["weak"]:
        j["weak"][pid] -= 1
        if j["weak"][pid] <= 0:
            del j["weak"][pid]


def weak_list(j):
    return sorted(j["weak"], key=lambda p: -j["weak"][p])
