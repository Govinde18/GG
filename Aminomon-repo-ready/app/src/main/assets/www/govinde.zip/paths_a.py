PATHWAYS = [
    dict(
        id="lac_operon", name="Lac operon induction", cell="ecoli", stage=1, kind="regulation",
        trigger="Lactose present and glucose scarce",
        outcome="High-level lacZYA transcription and lactose uptake and use",
        steps=[
            "β-Galactosidase, made at a basal level, isomerizes a little lactose into allolactose",
            "Allolactose binds the LacI repressor and changes its shape",
            "LacI lets go of the lac operator, unblocking the promoter",
            "cAMP-CRP, formed because glucose is low, binds the CRP site upstream of the lac promoter",
            "RNA polymerase transcribes lacZ, lacY and lacA as one polycistronic mRNA",
            "LacZ, LacY permease and LacA are translated, so the cell imports and splits more lactose",
        ],
        actors=["β-Galactosidase", "Allolactose / LacI", "LacI repressor", "cAMP-CRP",
                "RNA polymerase", "LacZ / LacY / LacA"],
        parallel=[[2, 3]],
        decoys=[
            "Lactose itself binds LacI and pulls it off the operator",
            "High glucose raises cAMP, so cAMP-CRP activates the lac promoter",
            "A terminator hairpin forms in the leader mRNA and stops transcription early",
        ],
        pages=[
            ("Overview", "The lac operon lets E. coli use lactose only when it is needed. It is a cluster of three genes, "
             "lacZ, lacY and lacA, transcribed together from one promoter. Two signals must agree: lactose must be present "
             "to release the repressor, and glucose must be scarce so that cAMP-CRP can boost transcription. "
             "Both inputs together give full expression."),
            ("Key players", "LacZ is β-galactosidase, which splits lactose and also makes a little allolactose. "
             "LacY is lactose permease, a membrane transporter, and LacA is a transacetylase. LacI is the repressor that "
             "binds the operator. The true inducer is allolactose, not lactose itself. CRP, the cAMP receptor protein, "
             "binds cAMP and then a site upstream of the promoter, helping RNA polymerase start."),
            ("Control and consequences", "With glucose present, cAMP is low and CRP stays inactive, so even "
             "released LacI gives only weak expression. When glucose runs out, cAMP rises and CRP is active. This is "
             "catabolite activation, and it produces diauxic growth: glucose is used first, then lactose. "
             "A gratuitous inducer such as IPTG also releases LacI but cannot be split by β-galactosidase."),
        ],
        note=dict(q="Which molecule is the true inducer that binds the LacI repressor?",
                  a="Allolactose", wrong=["Lactose", "Glucose", "cAMP"]),
        whatif=dict(q="A LacI mutant cannot bind allolactose but still binds the operator. What happens with lactose?",
                    a="The lac genes stay repressed even when lactose is present",
                    wrong=["The lac genes are expressed all the time", "Only lacZ is expressed",
                           "Expression depends only on glucose"],
                    why="LacI that cannot bind the inducer is never released from the operator, so the operon is locked off."),
    ),
    dict(
        id="trp_operon", name="Trp operon repression and attenuation", cell="ecoli", stage=1, kind="synthesis",
        trigger="Tryptophan is abundant in the cell",
        outcome="Trp biosynthesis genes switched off by two layers of control",
        steps=[
            "Tryptophan binds the TrpR aporepressor and converts it into an active repressor",
            "TrpR-Trp binds the trp operator and cuts transcription initiation about 70-fold",
            "RNA polymerase that still starts transcribes the leader, and a ribosome follows translating trpL",
            "The ribosome moves quickly through the two Trp codons because charged tRNA-Trp is plentiful",
            "Regions 3 and 4 of the leader mRNA pair to form the terminator hairpin",
            "RNA polymerase terminates before trpE, so the biosynthetic enzymes are not made",
        ],
        actors=["Tryptophan / TrpR", "TrpR-Trp", "RNA polymerase / ribosome", "Ribosome",
                "Leader mRNA", "RNA polymerase"],
        parallel=[],
        decoys=[
            "The ribosome stalls at the Trp codons, so regions 2 and 3 pair into an antiterminator",
            "cAMP-CRP binds upstream of the trp promoter and activates transcription",
            "Allolactose binds TrpR, which then leaves the trp operator",
        ],
        pages=[
            ("Overview", "The trp operon holds five genes, trpE, D, C, B and A, that build tryptophan from chorismate. "
             "Making Trp is costly, so E. coli switches these genes off when Trp is plentiful. Two layers act: "
             "repression by TrpR, which blocks most initiation, and attenuation, which stops transcription that "
             "does begin. Together they give a range of several hundred fold."),
            ("Key players", "TrpR is a repressor that only binds the operator when it carries tryptophan, its "
             "corepressor. Repression cuts initiation about 70-fold. The 162-nucleotide leader, trpL, encodes a "
             "14-residue leader peptide with two adjacent Trp codons. The leader mRNA has regions 1 to 4 that can form "
             "hairpins: pairing of 3 and 4 is the terminator, and pairing of 2 and 3 is an antiterminator."),
            ("Control and consequences", "Attenuation works because transcription and translation are coupled in "
             "bacteria. With high Trp, the ribosome translates the Trp codons quickly and covers region 2, "
             "so 3 and 4 pair and polymerase stops. With low Trp, the ribosome stalls at the Trp codons, 2 and 3 pair, "
             "and transcription continues. Attenuation adds roughly 8 to 10-fold control."),
        ],
        note=dict(q="How many Trp codons are in the trp leader peptide?",
                  a="Two", wrong=["One", "Three", "Five"]),
        whatif=dict(q="The terminator region 4 of the leader is deleted, and Trp is high. What changes?",
                    a="Transcription is higher than normal because attenuation is lost",
                    wrong=["Transcription is fully off", "TrpR no longer binds the operator",
                           "The ribosome cannot translate trpL"],
                    why="TrpR repression still works, but no terminator can form, so more polymerases read through into trpE."),
    ),
    dict(
        id="chemotaxis", name="Bacterial chemotaxis", cell="ecoli", stage=1, kind="signalling",
        trigger="Attractant concentration falls around the cell",
        outcome="Tumble to reorient, then adaptation restores the run",
        steps=[
            "The MCP receptor, coupled to CheA by CheW, becomes more active as attractant binding falls",
            "CheA autophosphorylates on a histidine using ATP",
            "CheA-P transfers its phosphoryl group to CheY, making CheY-P",
            "CheY-P binds the motor switch protein FliM, so flagella turn clockwise and the cell tumbles",
            "CheB, phosphorylated by CheA, demethylates the receptor and lowers CheA activity",
            "CheZ dephosphorylates CheY-P, and the motor returns to counterclockwise rotation and a run",
        ],
        actors=["MCP / CheW", "CheA", "CheY", "CheY-P / FliM", "CheB", "CheZ"],
        parallel=[],
        decoys=[
            "Attractant binding to the MCP increases CheA autophosphorylation and raises CheY-P",
            "CheY-P binds FliM and drives counterclockwise rotation, bundling flagella into a run",
            "The MCP receptor dimerizes and autophosphorylates its own tyrosine residues",
        ],
        pages=[
            ("Overview", "E. coli cannot sense direction, so it senses change over time. It swims in straight runs, "
             "when its flagella rotate counterclockwise and form a bundle. Clockwise rotation breaks up the bundle and "
             "the cell tumbles, picking a new random direction. When attractant is increasing, tumbles are "
             "suppressed and runs lengthen, giving a biased random walk."),
            ("Key players", "Methyl-accepting chemotaxis proteins (MCPs) such as Tar and Tsr span the inner membrane "
             "and bind attractants. CheW couples them to the histidine kinase CheA. CheA phosphorylates CheY, the response "
             "regulator that binds the motor switch FliM, and CheB, a methylesterase. CheR is a methyltransferase and "
             "CheZ is the CheY-P phosphatase."),
            ("Control and consequences", "Rising attractant lowers CheA activity, so less CheY-P forms and runs continue. "
             "Falling attractant raises CheA activity and causes tumbling. Adaptation resets the receptor: CheR "
             "adds methyl groups to glutamate residues, raising kinase activity, and CheB-P removes them. This "
             "methylation memory lets the cell sense changes over a thousand-fold range of concentration."),
        ],
        note=dict(q="Which protein dephosphorylates CheY-P to end a tumble?",
                  a="CheZ", wrong=["CheR", "CheB", "CheW"]),
        whatif=dict(q="What happens in a cell lacking the CheY-P phosphatase CheZ?",
                    a="Tumbling is excessive and net swimming is poor",
                    wrong=["The cell runs without ever tumbling", "The cell cannot make CheY-P",
                           "Receptors can no longer be methylated"],
                    why="Without CheZ, CheY-P is cleared slowly, so the motor stays clockwise and the cell tumbles too often."),
    ),
    dict(
        id="envz_ompr", name="EnvZ/OmpR osmoregulation", cell="ecoli", stage=1, kind="signalling",
        trigger="Medium osmolarity rises",
        outcome="OmpC porin favoured over OmpF in the outer membrane",
        steps=[
            "High osmolarity shifts the inner-membrane kinase EnvZ toward its kinase state",
            "EnvZ autophosphorylates a conserved histidine using ATP",
            "EnvZ-P transfers its phosphoryl group to an aspartate on the response regulator OmpR",
            "OmpR-P binds the promoter regions of the ompC and ompF genes",
            "At high OmpR-P, ompC transcription is switched on and ompF is repressed",
            "More OmpC, the narrower porin, is inserted into the outer membrane in place of OmpF",
        ],
        actors=["EnvZ", "EnvZ", "OmpR", "OmpR-P", "OmpR-P / promoters", "OmpC / OmpF"],
        parallel=[],
        decoys=[
            "Low OmpR-P activates ompF transcription, favouring the wider OmpF porin",
            "CheA passes its phosphoryl group to OmpR, linking chemotaxis to porin control",
            "Low osmolarity favours EnvZ phosphatase activity, which strips phosphate from OmpR-P",
        ],
        pages=[
            ("Overview", "E. coli lives in very different environments, from dilute water to the gut. Its outer membrane "
             "porins OmpF and OmpC let small molecules diffuse in. OmpF forms a wider channel and OmpC a narrower one. "
             "The EnvZ/OmpR two-component system tunes the ratio of the two porins to match the osmolarity "
             "of the medium."),
            ("Key players", "EnvZ is an inner-membrane histidine kinase that is also an OmpR phosphatase. OmpR is "
             "the cytoplasmic response regulator and a DNA-binding transcription factor. Phosphorylation "
             "occurs on a histidine of EnvZ and then an aspartate of OmpR. The two target genes, ompF and ompC, have "
             "OmpR binding sites with different affinities."),
            ("Control and consequences", "At low osmolarity, OmpR-P is low and activates ompF, so the wider OmpF "
             "dominates. At high osmolarity, OmpR-P is high and activates ompC while repressing ompF, so OmpC, the "
             "smaller-pore porin, dominates. This restricts entry of toxic compounds such as bile salts in the gut. "
             "The same histidine-aspartate relay design appears across bacteria."),
        ],
        note=dict(q="Which porin, with the smaller channel, dominates at high osmolarity?",
                  a="OmpC", wrong=["OmpF", "LamB", "OmpA"]),
        whatif=dict(q="An OmpR mutant mimics permanent phosphorylation. What porin pattern appears in dilute medium?",
                    a="High OmpC and low OmpF despite low osmolarity",
                    wrong=["High OmpF and low OmpC", "Neither porin is made", "Both porins are made equally"],
                    why="A permanently active OmpR acts like high OmpR-P, so ompC is on and ompF is off regardless of osmolarity."),
    ),
    dict(
        id="sos_response", name="SOS response", cell="ecoli", stage=1, kind="signalling",
        trigger="DNA damage such as UV lesions stalls replication",
        outcome="SOS genes induced for repair, damage bypass and delayed division",
        steps=[
            "Stalled replication forks leave stretches of single-stranded DNA",
            "RecA binds the single-stranded DNA with ATP, forming a nucleoprotein filament",
            "The RecA filament stimulates LexA to cleave itself, acting as a coprotease",
            "Cleaved LexA can no longer bind the SOS boxes, so repression of the SOS genes is lifted",
            "SOS genes such as recA, uvrA, uvrB, umuDC and sulA are transcribed",
            "Repair and bypass proteins act on the damage while SulA delays cell division",
        ],
        actors=["Single-stranded DNA", "RecA", "RecA filament / LexA", "LexA fragments",
                "SOS genes", "UvrABC / Pol V / SulA"],
        parallel=[],
        decoys=[
            "RecA cleaves LexA directly with its own protease active site",
            "Photolyase uses blue light to split pyrimidine dimers in the DNA",
            "A sensor kinase phosphorylates LexA, which then leaves the SOS boxes",
        ],
        pages=[
            ("Overview", "The SOS response is a global emergency program of E. coli. When DNA damage blocks "
             "replication, about 40 genes are switched on together. They encode excision repair, recombination "
             "repair, error-prone translesion synthesis and a block on cell division. The response is coordinated by "
             "a repressor, LexA, and a damage sensor, RecA."),
            ("Key players", "LexA is the repressor that binds operator sites called SOS boxes. RecA, "
             "a recombinase, forms a filament on single-stranded DNA. The filament does not cut LexA itself. "
             "It stimulates LexA to cleave itself, a self-cleavage reaction, so RecA acts as a coprotease. "
             "Induced genes include uvrA and uvrB for nucleotide excision repair, umuDC, which encodes the "
             "error-prone Pol V, and sulA."),
            ("Control and consequences", "SulA binds FtsZ and blocks septum formation, giving the cell time to "
             "repair. Because lexA and recA are themselves SOS genes, the system amplifies fast. Once damage is "
             "repaired, the RecA filament disappears, newly made LexA accumulates and shuts the response off. "
             "Pol V bypass is mutagenic, so SOS also raises mutation rates."),
        ],
        note=dict(q="How does the RecA filament cause LexA to be inactivated?",
                  a="It stimulates LexA to cleave itself, acting as a coprotease",
                  wrong=["It cleaves LexA with its own protease site", "It phosphorylates LexA",
                         "It binds LexA and blocks its dimerization"]),
        whatif=dict(q="A LexA mutant cannot self-cleave. How do these cells respond to UV light?",
                    a="They cannot induce the SOS genes and are very UV sensitive",
                    wrong=["They induce SOS genes constantly", "They become UV resistant",
                           "They induce SOS genes but cannot divide"],
                    why="Uncleavable LexA stays bound to the SOS boxes even with active RecA, so repair genes are never induced."),
    ),
]
