PATHWAYS = [
    dict(
        id="sporulation_phosphorelay", name="Sporulation phosphorelay", cell="bacillus", stage=2, kind="signalling",
        trigger="Starvation and high cell density in Bacillus subtilis",
        outcome="Spo0A-P switches on the genes that start endospore formation",
        steps=[
            "KinA autophosphorylates on a histidine using ATP when starvation signals reach the cell",
            "KinA passes its phosphate to an aspartate on the response regulator Spo0F",
            "Spo0B, a phosphotransferase, takes the phosphate from Spo0F-P onto one of its histidines",
            "Spo0B transfers the phosphate to an aspartate on Spo0A, making Spo0A-P",
            "Spo0A-P binds 0A boxes in DNA and activates early sporulation genes such as spoIIA and spoIIG",
        ],
        actors=["KinA", "Spo0F", "Spo0B", "Spo0A", "Spo0A-P"],
        parallel=[],
        decoys=[
            "ComP autophosphorylates and passes its phosphate to ComA when ComX accumulates",
            "CheA phosphorylates CheY, which binds the flagellar motor and causes tumbling",
            "Spo0E phosphatase removes phosphate from Spo0A-P to keep the cell vegetative",
        ],
        pages=[
            ("Overview", "When Bacillus subtilis runs short of nutrients it can build a tough, dormant endospore. "
             "The decision is made by a phosphorelay, an extended two-component system. A sensor kinase "
             "phosphorylates itself, and the phosphate is handed through two intermediate proteins to the master "
             "regulator Spo0A. Extra steps in the chain give the cell more places to integrate signals before "
             "committing to sporulation."),
            ("Key players", "Five kinases, of which KinA is the best studied, feed phosphate into the relay. "
             "KinA passes it to Spo0F, a response regulator with no DNA-binding domain. Spo0B is the "
             "phosphotransferase that moves the phosphate from Spo0F to Spo0A. Phosphorylated Spo0A (Spo0A-P) "
             "binds 0A boxes, turns off the repressor AbrB and activates genes whose products include sigma F "
             "and sigma E, starting the sigma factor cascade."),
            ("Control and consequences", "Phosphatases such as Spo0E and the Rap family remove phosphate and "
             "keep sporulation in check. Only a high level of Spo0A-P commits the cell, which then divides "
             "asymmetrically into a forespore and a mother cell. Mutants lacking spo0A, spo0B or spo0F "
             "cannot sporulate, and the resulting endospores resist heat, drying and radiation for years."),
        ],
        note=dict(q="Which protein is the phosphotransferase between Spo0F and Spo0A?",
                  a="Spo0B", wrong=["KinA", "AbrB", "Spo0E"]),
        whatif=dict(q="What happens to a spo0B deletion mutant starved of nutrients?",
                    a="It cannot sporulate because phosphate never reaches Spo0A",
                    wrong=["It sporulates faster since Spo0F-P builds up", "It sporulates normally through Spo0F alone",
                           "It cannot sense starvation because KinA is lost"],
                    why="Spo0B is the only link between Spo0F-P and Spo0A. Without it the relay is broken, Spo0A stays unphosphorylated and sporulation genes stay off."),
    ),
    dict(
        id="com_quorum", name="ComX quorum sensing and competence", cell="bacillus", stage=2, kind="signalling",
        trigger="High density of Bacillus cells; ComX pheromone accumulates",
        outcome="ComK is freed and activates competence genes for DNA uptake",
        steps=[
            "ComQ processes and modifies the ComX precursor, and the ComX pheromone is exported and accumulates",
            "ComX at high concentration binds the membrane sensor kinase ComP",
            "ComP autophosphorylates on a histidine",
            "ComP transfers its phosphate to the response regulator ComA",
            "ComA-P activates the srfA operon, which contains the small comS gene",
            "ComS binds MecA, so ComK escapes degradation by the ClpCP protease",
            "ComK activates its own gene and the late competence genes for DNA binding and uptake",
        ],
        actors=["ComQ / ComX", "ComX / ComP", "ComP", "ComA", "ComA-P / srfA", "ComS / MecA", "ComK"],
        parallel=[],
        decoys=[
            "LuxI makes an acyl-homoserine lactone that diffuses in and binds the LuxR transcription factor",
            "Spo0B passes a phosphate from Spo0F to Spo0A, starting the sporulation program",
            "RecA binds single-stranded DNA and triggers the SOS response, which turns on ComK",
        ],
        pages=[
            ("Overview", "Competent Bacillus subtilis cells can take up DNA from their surroundings. "
             "Competence is controlled by quorum sensing: each cell releases a small peptide pheromone, ComX, "
             "and responds only when the pheromone reaches a high concentration, which signals a dense "
             "population. The signal passes through a two-component system, ComP and ComA, and ends in "
             "the master competence regulator ComK."),
            ("Key players", "The comX gene encodes a precursor that ComQ processes and modifies before export. "
             "ComP is the membrane sensor kinase that binds mature ComX, and ComA is its response regulator. "
             "ComA-P drives the srfA operon, which also carries the small comS gene. ComS binds the adaptor "
             "MecA, so ComK is no longer sent to the ClpCP protease. Free ComK then activates its own promoter."),
            ("Control and consequences", "ComK positive autoregulation makes competence a switch rather than a "
             "dial, and only a fraction of cells in a culture turn it on. Competence is not induced by DNA "
             "damage in this species. Competent cells bind DNA and transport single strands inward, and "
             "recombination can then add new genes. ComS is therefore the small protein that releases ComK "
             "from MecA."),
        ],
        note=dict(q="Which small protein releases ComK from MecA-directed degradation?",
                  a="ComS", wrong=["ComX", "ComQ", "Spo0F"]),
        whatif=dict(q="What happens in a comP null mutant exposed to plenty of ComX?",
                    a="No competence, because the cells cannot detect the pheromone",
                    wrong=["Competence is normal because ComA senses ComX directly", "Competence is higher because ComX builds up",
                           "Competence is normal because ComK is made constantly"],
                    why="ComP is the receptor for ComX. Without it ComA is never phosphorylated, comS is not induced and ComK is degraded."),
    ),
    dict(
        id="kai_clock", name="KaiABC circadian clock", cell="cyano", stage=2, kind="regulation",
        trigger="Light-dark cycle sets KaiC phase; runs on a 24 h cycle",
        outcome="A 24 h rhythm of KaiC phosphorylation that times gene output",
        steps=[
            "KaiA binds the tails of KaiC and stimulates its autokinase activity",
            "KaiC phosphorylates itself, first at Thr432 and then at Ser431, over many hours",
            "SasA binds KaiC, autophosphorylates and passes its phosphate to the regulator RpaA",
            "KaiB binds KaiC phosphorylated at Ser431 and sequesters KaiA",
            "Without KaiA stimulation, KaiC autophosphatase activity dephosphorylates KaiC",
            "KaiC returns to its unphosphorylated state and releases KaiB, ready for the next cycle",
        ],
        actors=["KaiA", "KaiC", "SasA / RpaA", "KaiB", "KaiC phosphatase", "KaiC"],
        parallel=[[2, 3]],
        decoys=[
            "KaiC protein represses transcription of its own gene, and this feedback alone sets the 24 h period",
            "PER and TIM accumulate, enter the nucleus and inhibit CLOCK-BMAL1 activity",
            "KaiB phosphorylates KaiC on serine and threonine residues to drive the cycle forward",
        ],
        pages=[
            ("Overview", "Cyanobacteria such as Synechococcus elongatus keep time with a circadian clock "
             "built from just three proteins, KaiA, KaiB and KaiC. Mixed with ATP in a test tube, they "
             "produce a cycle of KaiC phosphorylation that lasts about 24 hours and stays steady over a range "
             "of temperatures. The rhythm does not need transcription or translation, although it normally "
             "controls gene expression."),
            ("Key players", "KaiC is an ATPase with both kinase and phosphatase activity. KaiA stimulates the "
             "kinase, and KaiC is phosphorylated at Thr432 and then Ser431. KaiB binds KaiC when it is "
             "phosphorylated at Ser431 and traps KaiA, which lets dephosphorylation take over. The output "
             "kinase SasA passes phosphate to the regulator RpaA, while the phosphatase CikA, which also "
             "binds the KaiB-KaiC complex, helps remove it."),
            ("Control and consequences", "Phosphorylated RpaA controls many promoters and so a large share of "
             "the genome is expressed in a daily pattern. Light and the redox state of the cell reset the "
             "phase through input pathways that include CikA. Strains with kaiC mutations have shorter or "
             "longer periods, and a kaiA null strain cannot keep a rhythm because KaiC stays mostly unphosphorylated."),
        ],
        note=dict(q="Which Kai protein stimulates the KaiC kinase activity?",
                  a="KaiA", wrong=["KaiB", "SasA", "CikA"]),
        whatif=dict(q="What happens to KaiC phosphorylation in a kaiA null strain?",
                    a="KaiC stays mostly unphosphorylated and the rhythm is lost",
                    wrong=["KaiC stays fully phosphorylated and the rhythm is lost", "The rhythm continues with a longer period",
                           "KaiB takes over the kinase role and the rhythm continues"],
                    why="KaiA is needed to stimulate the KaiC autokinase. Without it, the autophosphatase wins and the cycle cannot start."),
    ),
    dict(
        id="light_reactions", name="Light reactions of photosynthesis", cell="cyano", stage=2, kind="energy",
        trigger="Light hits photosystem II in the thylakoid membrane",
        outcome="O2, NADPH and ATP from light, water, NADP+ and ADP",
        steps=[
            "Photosystem II absorbs light and P680 loses an electron; water splitting refills it and releases O2",
            "The electron reaches plastoquinone, which takes up 2 H+ from the cytoplasmic side as plastoquinol",
            "Cytochrome b6f oxidizes plastoquinol, releases H+ into the lumen and passes electrons on",
            "Plastocyanin carries the electron to photosystem I, where light excites P700",
            "Excited P700 passes its electron to ferredoxin, which is reduced",
            "Ferredoxin-NADP+ reductase uses reduced ferredoxin to make NADPH from NADP+",
            "H+ built up in the lumen flow back through ATP synthase, driving ATP synthesis",
        ],
        actors=["Photosystem II", "Plastoquinone", "Cytochrome b6f", "Plastocyanin", "Photosystem I",
                "Ferredoxin-NADP+ reductase", "ATP synthase"],
        parallel=[[5, 6]],
        decoys=[
            "Complex I oxidizes NADH and pumps protons across the inner mitochondrial membrane",
            "RuBisCO adds CO2 to ribulose-1,5-bisphosphate to start carbon fixation",
            "Cytochrome c oxidase passes electrons to O2 to form water",
        ],
        pages=[
            ("Overview", "The light reactions convert light into chemical energy. In cyanobacteria they take "
             "place in thylakoid membranes inside the cell. Light drives electrons from water through a chain "
             "of carriers to NADP+, making NADPH, while protons pumped into the thylakoid lumen build a "
             "gradient that powers ATP synthesis. Oxygen is released as a by-product of splitting water."),
            ("Key players", "Photosystem II uses the chlorophyll P680 and a manganese cluster that oxidizes "
             "water. Plastoquinone is a mobile quinone that carries electrons and protons to cytochrome b6f. "
             "Plastocyanin, a small copper protein, carries electrons to photosystem I, though some "
             "cyanobacteria use cytochrome c6 instead. Photosystem I contains P700 and reduces ferredoxin. "
             "Ferredoxin-NADP+ reductase makes NADPH, and ATP synthase makes ATP."),
            ("Control and consequences", "The ATP and NADPH formed go to the Calvin cycle. Herbicides such as DCMU "
             "block plastoquinone binding in photosystem II and stop linear electron flow. Cyclic flow around "
             "photosystem I can add ATP without NADPH when the cell needs more ATP. Cyanobacterial "
             "photosynthesis put the first large amount of O2 into Earth's atmosphere."),
        ],
        note=dict(q="Which carrier moves electrons from cytochrome b6f to photosystem I?",
                  a="Plastocyanin", wrong=["Plastoquinone", "Ferredoxin", "Cytochrome c oxidase"]),
        whatif=dict(q="DCMU blocks plastoquinone binding in photosystem II. What stops?",
                    a="Linear electron flow, O2 release and NADPH formation stop",
                    wrong=["Only ATP synthesis stops while NADPH continues", "Only the Calvin cycle stops while the light reactions continue",
                           "Nothing stops because photosystem I works alone"],
                    why="Without electrons moving from photosystem II to plastoquinone, photosystem I cannot be resupplied by linear flow, so O2 and NADPH formation stop."),
    ),
    dict(
        id="calvin_cycle", name="Calvin cycle", cell="cyano", stage=2, kind="synthesis",
        trigger="CO2, ATP and NADPH available from the light reactions",
        outcome="Triose phosphate for sugars while RuBP is regenerated",
        steps=[
            "RuBisCO adds CO2 to ribulose-1,5-bisphosphate, forming an unstable six-carbon intermediate",
            "The intermediate splits into two molecules of 3-phosphoglycerate (3-PGA)",
            "Phosphoglycerate kinase uses ATP to turn 3-PGA into 1,3-bisphosphoglycerate",
            "GAP dehydrogenase uses NADPH to reduce it to glyceraldehyde-3-phosphate (G3P)",
            "Aldolase, transketolase and other enzymes rearrange most G3P into ribulose-5-phosphate",
            "Phosphoribulokinase uses ATP to phosphorylate ribulose-5-phosphate, regenerating RuBP",
        ],
        actors=["RuBisCO", "RuBisCO", "Phosphoglycerate kinase", "GAP dehydrogenase", "Transketolase / aldolase",
                "Phosphoribulokinase"],
        parallel=[],
        decoys=[
            "RuBisCO adds O2 to ribulose-1,5-bisphosphate, giving 2-phosphoglycolate in photorespiration",
            "Glucose-6-phosphate dehydrogenase oxidizes glucose-6-phosphate to make NADPH",
            "Pyruvate dehydrogenase converts pyruvate to acetyl-CoA and CO2",
        ],
        pages=[
            ("Overview", "The Calvin cycle fixes CO2 into organic molecules. In cyanobacteria it runs in "
             "the cytoplasm, and RuBisCO is packed in protein shells called carboxysomes that concentrate CO2. "
             "The cycle has three stages: carboxylation, reduction and regeneration. Fixing one CO2 costs "
             "3 ATP and 2 NADPH, so three turns are needed to make one net triose phosphate."),
            ("Key players", "RuBisCO is the most abundant enzyme on Earth and joins CO2 to ribulose-1,5-bisphosphate "
             "(RuBP). The unstable product splits into two 3-phosphoglycerate molecules. Phosphoglycerate kinase "
             "and GAP dehydrogenase use ATP and NADPH to reduce 3-PGA to glyceraldehyde-3-phosphate. "
             "Transketolase, aldolase and others rearrange sugars, and phosphoribulokinase makes the RuBP "
             "that restarts the cycle."),
            ("Control and consequences", "The cycle depends on the light reactions, since it needs their ATP and "
             "NADPH. Without light, 3-PGA builds up because it cannot be reduced. RuBisCO is slow and also "
             "accepts O2, which wastes energy through photorespiration, so carboxysomes raise the local CO2 "
             "level. G3P leaves the cycle to make glucose, starch-like glycogen and other molecules."),
        ],
        note=dict(q="How many ATP and NADPH are needed to fix each CO2?",
                  a="3 ATP and 2 NADPH", wrong=["2 ATP and 3 NADPH", "1 ATP and 1 NADPH", "6 ATP and 6 NADPH"]),
        whatif=dict(q="What builds up in cells moved into darkness while CO2 is available?",
                    a="3-PGA, because there is no ATP and NADPH to reduce it",
                    wrong=["RuBP, because RuBisCO is made more active", "G3P, because reduction speeds up",
                           "CO2, because RuBisCO stops binding it first"],
                    why="RuBisCO keeps making 3-PGA for a while, but the reduction steps need ATP and NADPH from the light reactions, so 3-PGA accumulates."),
    ),
    dict(
        id="pheromone_mapk", name="Yeast mating pheromone MAPK pathway", cell="yeast", stage=3, kind="signalling",
        trigger="Alpha-factor from a MATalpha cell reaches a MATa cell",
        outcome="Mating genes switch on and the cell arrests in G1",
        steps=[
            "Alpha-factor binds Ste2, a G protein-coupled receptor on the MATa cell",
            "Ste2 triggers Gpa1 to swap GDP for GTP, freeing the Ste4-Ste18 dimer",
            "Free Ste4-Ste18 recruits the Ste5 scaffold to the plasma membrane",
            "Ste20 kinase phosphorylates and activates Ste11, which is held on Ste5",
            "Ste11 phosphorylates and activates Ste7, the MAPK kinase",
            "Ste7 phosphorylates Fus3 on a threonine and a tyrosine, activating it",
            "Fus3 phosphorylates Ste12 and Far1, turning on mating genes and halting the cell in G1",
        ],
        actors=["Ste2", "Gpa1 / Ste4-Ste18", "Ste5", "Ste20 / Ste11", "Ste11 / Ste7", "Ste7 / Fus3", "Fus3"],
        parallel=[],
        decoys=[
            "Pbs2 phosphorylates Hog1 when the cell is exposed to high osmolarity",
            "Gs alpha activates adenylyl cyclase and cAMP switches on protein kinase A",
            "Ras-GTP activates Raf, which phosphorylates MEK and then ERK",
        ],
        pages=[
            ("Overview", "Haploid yeast come in two mating types. MATalpha cells secrete alpha-factor, a short "
             "peptide, and MATa cells detect it with a receptor and prepare to fuse. The signal passes along a "
             "MAP kinase cascade to the nucleus. The response includes new gene expression, arrest of the "
             "cell cycle in G1 and growth of a mating projection, the shmoo, toward the partner."),
            ("Key players", "Ste2 is a G protein-coupled receptor. In the G protein, Gpa1 is the alpha subunit, "
             "and Ste4-Ste18 is the beta-gamma dimer that carries the signal. Ste5 is a scaffold holding "
             "Ste11, Ste7 and Fus3 together. Ste20 starts the cascade, in which Ste11 phosphorylates Ste7 and "
             "Ste7 phosphorylates Fus3. Fus3 acts on the transcription factor Ste12 and on Far1."),
            ("Control and consequences", "Far1 inhibits the Cln-Cdc28 cyclin-dependent kinase, which is why the cell "
             "stops in G1 and does not start a new round of division while mating. The scaffold keeps the "
             "kinases close so that the wrong inputs are not mixed up, since the osmotic stress pathway shares "
             "Ste20 and Ste11. Cells lacking Ste5 cannot mate. Sst2 helps turn the signal off."),
        ],
        note=dict(q="Which protein is the scaffold that holds Ste11, Ste7 and Fus3?",
                  a="Ste5", wrong=["Ste12", "Far1", "Ste20"]),
        whatif=dict(q="What happens in a far1 deletion mutant exposed to alpha-factor?",
                    a="Fus3 and mating genes are activated but the cell fails to arrest in G1",
                    wrong=["The cell arrests in G1 but mating genes stay off", "The cell cannot detect alpha-factor",
                           "Fus3 is never activated, so nothing happens"],
                    why="Far1 is the link to the cell cycle. Upstream signalling and Ste12 still work, but without Far1 the Cln-Cdc28 kinase stays active."),
    ),
    dict(
        id="fermentation", name="Alcoholic fermentation", cell="yeast", stage=3, kind="energy",
        trigger="Glucose present and little or no oxygen",
        outcome="Ethanol and CO2, with NAD+ regenerated so glycolysis can go on",
        steps=[
            "Glycolysis turns glucose into pyruvate and reduces NAD+ to NADH, leaving little NAD+",
            "Pyruvate decarboxylase removes CO2 from pyruvate, forming acetaldehyde",
            "Alcohol dehydrogenase reduces acetaldehyde to ethanol, oxidizing NADH to NAD+",
            "GAPDH reuses the regenerated NAD+, so glycolysis can keep producing ATP",
            "Ethanol and CO2 leave the cell",
        ],
        actors=["Glycolysis", "Pyruvate decarboxylase", "Alcohol dehydrogenase", "GAPDH", "Ethanol / CO2"],
        parallel=[[3, 4]],
        decoys=[
            "Lactate dehydrogenase reduces pyruvate to lactate, oxidizing NADH to NAD+",
            "Pyruvate dehydrogenase converts pyruvate to acetyl-CoA, making NADH and CO2",
            "Alcohol dehydrogenase oxidizes ethanol to acetaldehyde, making NADH, as in the liver",
        ],
        pages=[
            ("Overview", "When oxygen is scarce, yeast such as Saccharomyces cerevisiae still need to regenerate "
             "NAD+ so that glycolysis can keep running. Alcoholic fermentation does this in two steps that "
             "convert pyruvate into ethanol and CO2. Per glucose the net gain is 2 ATP, all from glycolysis, "
             "along with 2 ethanol and 2 CO2. Fermentation itself makes no ATP."),
            ("Key players", "Pyruvate decarboxylase needs the cofactor thiamine pyrophosphate (TPP) and turns "
             "pyruvate into acetaldehyde, releasing CO2. Alcohol dehydrogenase uses NADH to reduce "
             "acetaldehyde to ethanol, which regenerates NAD+. GAPDH, the glycolytic enzyme that needs NAD+, "
             "then keeps glycolysis going. Animals lack pyruvate decarboxylase and make lactate instead."),
            ("Control and consequences", "Without alcohol dehydrogenase, yeast in the absence of oxygen would "
             "run out of NAD+ and glycolysis would stall. Yeast also ferment at high glucose even with oxygen, "
             "a response called the Crabtree effect. The CO2 makes bread rise and beer fizzy, and the ethanol "
             "accumulates until it becomes toxic to the yeast itself."),
        ],
        note=dict(q="Which cofactor does pyruvate decarboxylase need?",
                  a="Thiamine pyrophosphate (TPP)", wrong=["Biotin", "NADPH", "Coenzyme A"]),
        whatif=dict(q="An anaerobic yeast lacks alcohol dehydrogenase. What happens to glycolysis?",
                    a="It stalls because NAD+ is used up",
                    wrong=["It speeds up because NADH accumulates", "It continues normally using lactate",
                           "It continues, since pyruvate decarboxylase makes NAD+"],
                    why="Fermentation is the only anaerobic route for oxidizing NADH. Without it, GAPDH has no NAD+ and glycolysis, the sole ATP source, halts."),
    ),
]
