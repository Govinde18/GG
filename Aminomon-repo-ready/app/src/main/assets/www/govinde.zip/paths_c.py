PATHWAYS = [
    dict(
        id="gcn4_starvation", name="GCN4 amino-acid starvation response", cell="yeast", stage=3, kind="signalling",
        trigger="Amino-acid starvation in yeast",
        outcome="Amino acid biosynthesis genes switched on by Gcn4",
        steps=[
            "Amino-acid starvation leaves tRNAs uncharged, and uncharged tRNA accumulates in the cell",
            "Uncharged tRNA binds the HisRS-like domain of Gcn2 and activates its kinase",
            "Gcn2 phosphorylates the α subunit of eIF2 on serine 51",
            "Phosphorylated eIF2 blocks eIF2B, so less ternary complex forms and global translation falls",
            "Scanning ribosomes bypass the inhibitory uORFs and initiate translation at the GCN4 start codon",
            "Gcn4 activates transcription of amino acid biosynthesis genes",
        ],
        actors=["Uncharged tRNA", "Gcn2", "Gcn2 / eIF2α", "eIF2 / eIF2B", "Ribosome / GCN4 mRNA", "Gcn4"],
        parallel=[],
        decoys=[
            "TORC1 phosphorylates 4E-BP1, releasing eIF4E to restore cap-dependent translation",
            "Phosphatase PP1 dephosphorylates eIF2α, restoring ternary complex formation",
            "Ire1 cuts HAC1 mRNA so that Hac1 can activate chaperone genes",
        ],
        pages=[
            ("Overview", "When yeast run short of amino acids, they switch on a program called general amino acid "
             "control. Starvation makes tRNAs accumulate without their amino acid attached. This signal is sensed "
             "by the kinase Gcn2, which slows most protein synthesis to save resources while it boosts one "
             "transcription factor, Gcn4. Gcn4 then turns on the genes that make amino acids."),
            ("Key players", "Gcn2 is the only eIF2α kinase in yeast. Its HisRS-like domain binds uncharged tRNA. "
             "Gcn2 phosphorylates eIF2α on serine 51, and this form of eIF2 inhibits its exchange factor eIF2B. "
             "Less eIF2-GTP-Met-tRNA ternary complex means fewer initiations. The GCN4 mRNA carries four short "
             "upstream open reading frames, called uORFs, that normally keep its translation low."),
            ("Control and consequences", "With scarce ternary complex, ribosomes that have translated the first "
             "uORF take longer to reload and scan past the inhibitory uORFs, so they start at the GCN4 coding "
             "sequence instead. This is why a general drop in translation raises Gcn4 protein. Gcn4 regulates "
             "hundreds of genes. Yeast lacking Gcn2 cannot induce this response and grow poorly when starved "
             "for amino acids."),
        ],
        note=dict(q="Which kinase phosphorylates eIF2α in the yeast starvation response?",
                  a="Gcn2", wrong=["PKR", "PERK", "Ire1"]),
        whatif=dict(q="What happens to GCN4 translation in a yeast strain lacking Gcn2 under starvation?",
                    a="It stays low, because eIF2α is never phosphorylated",
                    wrong=["It rises more strongly than normal", "It is unchanged by starvation because uORFs are lost",
                           "It rises because uncharged tRNA acts directly on Gcn4"],
                    why="Without Gcn2 there is no eIF2α phosphorylation, so ternary complex stays high and ribosomes stop at the inhibitory uORFs."),
    ),
    dict(
        id="upr", name="Yeast unfolded protein response", cell="yeast", stage=3, kind="signalling",
        trigger="Misfolded proteins build up in the ER",
        outcome="Hac1 turns on chaperone and ER expansion genes",
        steps=[
            "Misfolded proteins accumulate in the ER lumen and draw BiP away from Ire1",
            "Ire1 molecules cluster in the ER membrane and trans-autophosphorylate their kinase domains",
            "Ire1 RNase cuts HAC1 mRNA to remove an intron",
            "tRNA ligase joins the two HAC1 mRNA exons",
            "Spliced HAC1 mRNA is translated efficiently, making the Hac1 protein",
            "Hac1 enters the nucleus and activates genes for chaperones and ER expansion",
        ],
        actors=["BiP / Ire1", "Ire1", "Ire1 RNase", "tRNA ligase", "HAC1 mRNA", "Hac1"],
        parallel=[],
        decoys=[
            "The spliceosome removes the HAC1 intron in the nucleus before export",
            "PERK phosphorylates eIF2α to slow translation of ER-bound proteins",
            "ATF6 is cleaved in the Golgi and its fragment enters the nucleus",
        ],
        pages=[
            ("Overview", "The ER folds secreted and membrane proteins. If folding capacity is overwhelmed, "
             "misfolded proteins accumulate, and the cell mounts the unfolded protein response, or UPR. In yeast "
             "it is a single pathway built around the ER membrane sensor Ire1. The response makes more "
             "chaperones and enlarges the ER so that folding capacity matches demand."),
            ("Key players", "Ire1 is a transmembrane protein with a luminal sensing domain and a cytosolic kinase "
             "plus RNase region. The chaperone BiP, called Kar2 in yeast, binds Ire1 when the ER is calm. HAC1 "
             "mRNA contains an intron that blocks efficient translation. Ire1 RNase cuts out this intron, and "
             "tRNA ligase joins the exons. Hac1 is a bZIP transcription factor."),
            ("Control and consequences", "Unusually, this splicing does not use the spliceosome. Only stressed "
             "cells make Hac1, so the response is tightly tied to demand. Hac1 targets include BiP, protein "
             "disulfide isomerase and ER-associated degradation genes. Cells missing Ire1 or Hac1 are very sensitive to ER stress such as "
             "tunicamycin."),
        ],
        note=dict(q="Which enzyme joins the HAC1 mRNA exons after Ire1 removes the intron?",
                  a="tRNA ligase", wrong=["Spliceosome", "Poly(A) polymerase", "DNA ligase"]),
        whatif=dict(q="What is the effect of an Ire1 mutant lacking RNase activity during ER stress?",
                    a="HAC1 is not spliced, so Hac1 is not made and UPR genes stay off",
                    wrong=["HAC1 is spliced by the spliceosome instead", "Hac1 is made but cannot enter the nucleus",
                           "BiP stays bound to Ire1 and misfolded proteins disappear"],
                    why="Ire1 RNase is the enzyme that removes the HAC1 intron, so without it the stressed cell cannot make Hac1."),
    ),
    dict(
        id="autophagy", name="Starvation-induced autophagy", cell="yeast", stage=3, kind="degradation",
        trigger="Nitrogen or amino acid starvation",
        outcome="Cargo degraded in the vacuole and amino acids recycled",
        steps=[
            "Starvation inhibits TORC1 kinase activity",
            "Atg13 becomes dephosphorylated",
            "Dephosphorylated Atg13 assembles the Atg1 kinase complex, which becomes active",
            "Atg9 vesicles are recruited and a phagophore starts to form",
            "Atg8 is attached to phosphatidylethanolamine (PE) and the phagophore membrane expands",
            "The phagophore closes around cargo, forming a double-membraned autophagosome",
            "The autophagosome fuses with the vacuole and hydrolases degrade cargo, recycling amino acids",
        ],
        actors=["TORC1", "Atg13", "Atg1 complex", "Atg9 / phagophore", "Atg8-PE", "Autophagosome", "Vacuolar hydrolases"],
        parallel=[],
        decoys=[
            "TORC1 phosphorylates Atg13 heavily, which keeps the Atg1 complex inactive",
            "Ubiquitin chains tag the cargo and the proteasome unfolds it for degradation",
            "Atg8 is attached to a lysine side chain of the cargo protein like ubiquitin",
        ],
        pages=[
            ("Overview", "Autophagy means self-eating. In starved yeast, a cup-shaped membrane called the "
             "phagophore wraps part of the cytoplasm, closes into a double-membraned autophagosome and delivers it "
             "to the vacuole, the yeast equivalent of the lysosome. Cargo is broken down and the building "
             "blocks, especially amino acids, are released for reuse. Yeast genetics first identified the ATG genes."),
            ("Key players", "TORC1 is the nutrient sensor that suppresses autophagy by phosphorylating Atg13 in "
             "rich conditions. Atg13 partners with the kinase Atg1. Atg9 vesicles supply membrane. Atg8 is a "
             "ubiquitin-like protein that is conjugated to the lipid phosphatidylethanolamine (PE) by Atg7, Atg3 and "
             "the Atg12-Atg5-Atg16 complex. Vacuolar hydrolases such as proteinase A digest the delivered contents."),
            ("Control and consequences", "Starvation or the drug rapamycin inhibits TORC1 and triggers the "
             "pathway. Atg8-PE helps expand the membrane and recruits cargo. After fusion, the inner single-membrane "
             "vesicle is broken down in the vacuole. Autophagy helps cells survive starvation, and "
             "yeast lacking ATG genes die quickly when nitrogen is removed. In humans, impaired autophagy is "
             "linked to neurodegeneration."),
        ],
        note=dict(q="To which lipid is Atg8 conjugated during phagophore expansion?",
                  a="Phosphatidylethanolamine (PE)", wrong=["Phosphatidylserine", "Phosphatidylinositol", "Cholesterol"]),
        whatif=dict(q="What does rapamycin do to autophagy in yeast growing in rich medium?",
                    a="It induces autophagy by inhibiting TORC1",
                    wrong=["It blocks autophagy by activating TORC1", "It has no effect because nutrients are present",
                           "It blocks fusion of autophagosomes with the vacuole"],
                    why="Rapamycin inhibits TORC1, so Atg13 is dephosphorylated and the Atg1 complex switches on even without starvation."),
    ),
    dict(
        id="rtk_ras_mapk", name="RTK-Ras-MAPK pathway", cell="fibroblast", stage=4, kind="signalling",
        trigger="Growth factor such as EGF binds its receptor",
        outcome="ERK activates transcription factors that drive proliferation",
        steps=[
            "EGF binds the extracellular domain of its receptor tyrosine kinase, which dimerizes",
            "The receptor kinase domains phosphorylate tyrosines on each other's tails",
            "Grb2 binds the phosphotyrosines through its SH2 domain and brings in SOS",
            "SOS stimulates Ras to release GDP and bind GTP",
            "Ras-GTP recruits and activates the kinase Raf",
            "Raf phosphorylates MEK, and MEK phosphorylates ERK",
            "ERK enters the nucleus and phosphorylates transcription factors that induce Fos and Myc",
        ],
        actors=["EGF receptor", "Receptor kinase", "Grb2 / SOS", "SOS / Ras", "Raf", "MEK / ERK", "ERK"],
        parallel=[],
        decoys=[
            "Phospholipase C-γ cleaves PIP2 into IP3 and diacylglycerol",
            "PI3K phosphorylates PIP2 to make PIP3 at the plasma membrane",
            "JAK kinases phosphorylate STAT proteins, which dimerize and enter the nucleus",
        ],
        pages=[
            ("Overview", "Fibroblasts divide when growth factors such as EGF arrive. The signal crosses the "
             "membrane through a receptor tyrosine kinase and is relayed by the small GTPase Ras to a chain of "
             "three kinases, the MAP kinase cascade. At the end, ERK switches on genes that move the cell into "
             "the cell cycle."),
            ("Key players", "Ligand binding makes receptors dimerize and phosphorylate each other on tyrosines. "
             "The adaptor Grb2 binds those phosphotyrosines with its SH2 domain and carries SOS, a Ras "
             "exchange factor. SOS lets Ras swap GDP for GTP. Ras-GTP activates Raf, which phosphorylates MEK, "
             "which phosphorylates ERK on a threonine and a tyrosine."),
            ("Control and consequences", "Ras switches itself off by hydrolyzing GTP, helped by GTPase-activating "
             "proteins. Oncogenic Ras mutations such as G12V impair this hydrolysis, leaving Ras active without "
             "a signal. Roughly a quarter of human tumors carry Ras mutations, and BRAF mutations drive many "
             "melanomas. In the nucleus ERK phosphorylates transcription factors, and it also stabilizes "
             "Fos and Myc."),
        ],
        note=dict(q="Which adaptor protein binds receptor phosphotyrosines and carries SOS?",
                  a="Grb2", wrong=["Shc-1 only", "Cbl", "Raf"]),
        whatif=dict(q="What is the effect of a Ras mutant that cannot hydrolyze GTP, such as G12V?",
                    a="Ras stays active and drives ERK signalling without growth factor",
                    wrong=["Ras stays inactive even with growth factor", "Ras signals only while EGF is present",
                           "Ras cannot bind Raf but still binds SOS"],
                    why="Hydrolysis of GTP is the timer that turns Ras off, so an impaired GTPase leaves Ras locked in its active GTP-bound state."),
    ),
    dict(
        id="pi3k_akt", name="PI3K-Akt pathway", cell="fibroblast", stage=4, kind="signalling",
        trigger="Insulin or growth factor activates a receptor",
        outcome="Active Akt promotes growth and survival",
        steps=[
            "The activated receptor or IRS protein recruits PI3K through phosphotyrosine binding",
            "PI3K phosphorylates PIP2 on the 3 position to make PIP3",
            "PIP3 recruits PDK1 and Akt to the plasma membrane through their PH domains",
            "PDK1 phosphorylates Akt on threonine 308",
            "mTORC2 phosphorylates Akt on serine 473",
            "Active Akt phosphorylates TSC2, relieving the brake on mTORC1",
            "Active Akt phosphorylates FoxO and BAD, blocking their gene and apoptosis functions",
        ],
        actors=["Receptor / IRS", "PI3K", "PIP3 / PH domains", "PDK1", "mTORC2", "Akt / TSC", "Akt / FoxO / BAD"],
        parallel=[[3, 4], [5, 6]],
        decoys=[
            "PTEN converts PIP2 into PIP3, which amplifies Akt signalling",
            "Phospholipase C cleaves PIP2 into IP3 and DAG, which then activates PKC",
            "Grb2 and SOS load Ras with GTP, which activates Raf",
        ],
        pages=[
            ("Overview", "The PI3K-Akt pathway tells a cell that growth signals and nutrients are available. "
             "Receptors for insulin and growth factors recruit phosphoinositide 3-kinase, which creates a "
             "lipid signal in the plasma membrane. That lipid pulls the kinase Akt to the membrane, where it "
             "is activated and promotes growth, metabolism and survival."),
            ("Key players", "PI3K converts PIP2 to PIP3. PIP3 binds the PH domains of PDK1 and Akt. PDK1 "
             "phosphorylates Akt on threonine 308 and mTORC2 phosphorylates serine 473, and both are needed for "
             "full activity. Active Akt phosphorylates TSC2, which lets Rheb activate mTORC1. It also "
             "phosphorylates FoxO transcription factors and the pro-apoptotic protein BAD."),
            ("Control and consequences", "The lipid phosphatase PTEN removes the 3 phosphate from PIP3 and so "
             "switches the pathway off. PTEN is one of the most commonly lost tumor suppressors, and "
             "PIK3CA, which encodes the catalytic subunit of PI3K, is often activated by mutation in cancers. "
             "Both changes keep Akt on. Akt-dependent phosphorylation excludes FoxO from the nucleus and so "
             "supports survival."),
        ],
        note=dict(q="Which lipid phosphatase reverses PIP3 and switches off Akt signalling?",
                  a="PTEN", wrong=["SHP2", "PP2A", "Calcineurin"]),
        whatif=dict(q="What is the effect of losing PTEN in a fibroblast?",
                    a="PIP3 and Akt activity stay high, favouring growth and survival",
                    wrong=["PIP3 falls and Akt becomes inactive", "PI3K can no longer make PIP3",
                           "mTORC2 cannot phosphorylate Akt on serine 473"],
                    why="PTEN dephosphorylates PIP3 to PIP2. Without it, PIP3 persists, so Akt stays at the membrane and active."),
    ),
    dict(
        id="gpcr_camp_pka", name="GPCR-cAMP-PKA pathway", cell="fibroblast", stage=4, kind="signalling",
        trigger="Ligand binds a Gs-coupled receptor",
        outcome="PKA phosphorylates targets, including CREB",
        steps=[
            "A ligand such as epinephrine binds a Gs-coupled receptor, changing its shape",
            "The receptor acts as an exchange factor, so Gα_s releases GDP and binds GTP",
            "Gα_s-GTP separates from Gβγ and binds adenylyl cyclase",
            "Adenylyl cyclase converts ATP into cAMP",
            "Four cAMP bind the PKA regulatory subunits, releasing two active catalytic subunits",
            "PKA catalytic subunits phosphorylate target proteins, including CREB on serine 133",
            "Phosphodiesterase hydrolyzes cAMP to 5'-AMP, ending the signal",
        ],
        actors=["Gs-coupled GPCR", "Gα_s", "Gα_s / adenylyl cyclase", "Adenylyl cyclase", "PKA", "PKA / CREB", "Phosphodiesterase"],
        parallel=[],
        decoys=[
            "Gα_q activates phospholipase C-β, producing IP3 and diacylglycerol",
            "Gα_i inhibits adenylyl cyclase, lowering the level of cAMP",
            "Guanylyl cyclase produces cGMP in response to nitric oxide",
        ],
        pages=[
            ("Overview", "G protein-coupled receptors span the membrane seven times. When a ligand such as "
             "epinephrine or glucagon binds a Gs-coupled receptor, the signal passes to a heterotrimeric "
             "G protein and then to the enzyme adenylyl cyclase. It makes the second messenger cAMP, which "
             "activates protein kinase A and changes metabolism and gene expression."),
            ("Key players", "The receptor acts as a guanine nucleotide exchange factor for Gα_s, which swaps GDP "
             "for GTP. Gα_s-GTP activates adenylyl cyclase, which makes cAMP from ATP. Inactive PKA is a "
             "tetramer of two regulatory and two catalytic subunits. Four cAMP bind the regulatory subunits "
             "and release two active catalytic subunits. In the nucleus, PKA phosphorylates CREB on serine 133."),
            ("Control and consequences", "The signal ends in two ways. Gα_s hydrolyzes its own GTP and "
             "returns to its inactive state, and phosphodiesterases break cAMP down into 5'-AMP. Caffeine "
             "inhibits these enzymes and raises cAMP. Cholera toxin modifies Gα_s so it cannot hydrolyze GTP, "
             "which keeps adenylyl cyclase on and causes the massive fluid loss of cholera."),
        ],
        note=dict(q="How many cAMP molecules bind PKA to release its catalytic subunits?",
                  a="Four, releasing two catalytic subunits", wrong=["Two, releasing one catalytic subunit", "One per catalytic subunit", "Six, releasing three subunits"]),
        whatif=dict(q="What does cholera toxin do to cAMP levels in intestinal cells?",
                    a="It raises cAMP by locking Gα_s in its GTP-bound state",
                    wrong=["It lowers cAMP by activating phosphodiesterase", "It lowers cAMP by activating Gα_i",
                           "It raises cAMP by blocking the PKA regulatory subunit"],
                    why="Cholera toxin ADP-ribosylates Gα_s so it cannot hydrolyze GTP. Adenylyl cyclase stays active and cAMP stays high."),
    ),
]
