PATHWAYS = [
    dict(
        id="gpcr_plc_ip3", name="Gq-GPCR to PLC, IP3 and PKC", cell="fibroblast", stage=4, kind="signalling",
        trigger="Agonist binds a Gq-coupled GPCR",
        outcome="Cytosolic Ca2+ rise and protein kinase C activation",
        steps=[
            "Agonist-bound GPCR makes Gαq swap GDP for GTP",
            "Gαq-GTP leaves Gβγ and binds phospholipase C-β at the plasma membrane",
            "Phospholipase C-β cleaves PIP2 into soluble IP3 and membrane-bound DAG",
            "IP3 diffuses through the cytosol and binds the IP3 receptor on the endoplasmic reticulum",
            "IP3 receptor channel opens and Ca2+ flows out of the ER into the cytosol",
            "Ca2+ and DAG together activate protein kinase C at the membrane",
        ],
        actors=["GPCR / Gαq", "Gαq-GTP", "Phospholipase C-β", "IP3", "IP3 receptor", "Protein kinase C"],
        parallel=[],
        decoys=[
            "Adenylyl cyclase converts ATP into cAMP, which activates protein kinase A",
            "Phosphoinositide 3-kinase phosphorylates PIP2 to make PIP3 at the membrane",
            "Ca2+ binds calmodulin, which switches on calmodulin-dependent kinases directly from the receptor",
        ],
        pages=[
            ("Overview", "Many hormones and neurotransmitters, such as histamine, bradykinin and acetylcholine on "
             "muscarinic M3 receptors, act through Gq-coupled receptors. Receptor activation leads to the "
             "cleavage of a membrane lipid, PIP2, into two second messengers. One raises cytosolic Ca2+ and the "
             "other helps activate protein kinase C, so a single signal at the surface is turned into two "
             "intracellular signals."),
            ("Key players", "The receptor acts as a guanine nucleotide exchange factor on the G protein Gαq, "
             "which then carries GTP. Gαq-GTP activates phospholipase C-β. This enzyme cuts PIP2 into IP3, "
             "which is water soluble, and diacylglycerol (DAG), which stays in the membrane. IP3 opens the IP3 "
             "receptor, a Ca2+ channel in the endoplasmic reticulum. Ca2+ and DAG together activate protein "
             "kinase C."),
            ("Control and consequences", "Gαq has intrinsic GTPase activity, so the signal ends when GTP is "
             "hydrolysed to GDP. IP3 is rapidly dephosphorylated and Ca2+ is pumped back into the ER by SERCA "
             "or out of the cell. Classic protein kinase C isoforms need both Ca2+ and DAG, and phorbol esters "
             "mimic DAG, which is why they act as tumour promoters. Protein kinase C then phosphorylates many "
             "target proteins."),
        ],
        note=dict(q="Which two second messengers does phospholipase C-β make from PIP2?",
                  a="IP3 and diacylglycerol (DAG)", wrong=["cAMP and cGMP", "PIP3 and DAG", "IP3 and Ca2+"]),
        whatif=dict(q="What happens if the IP3 receptor is blocked but DAG is still made?",
                    a="No ER Ca2+ release, so classic protein kinase C stays poorly active",
                    wrong=["Ca2+ is released anyway, so protein kinase C is fully active",
                           "PIP2 is no longer cleaved by phospholipase C-β",
                           "Gαq can no longer bind GTP"],
                    why="Classic protein kinase C needs both Ca2+ and DAG. DAG alone is not enough, and the cleavage of PIP2 upstream is unaffected."),
    ),
    dict(
        id="wnt_bcatenin", name="Wnt / β-catenin signalling", cell="fibroblast", stage=4, kind="signalling",
        trigger="Wnt ligand binds Frizzled and LRP5/6",
        outcome="β-catenin activates TCF/LEF target genes",
        steps=[
            "Wnt binds Frizzled and the co-receptor LRP5/6 on the cell surface",
            "Dishevelled is recruited to the activated Frizzled receptor",
            "The Axin, APC, GSK3 and CK1 destruction complex is inactivated and stops phosphorylating β-catenin",
            "β-catenin escapes degradation and accumulates in the cytoplasm",
            "β-catenin enters the nucleus",
            "β-catenin binds TCF/LEF transcription factors and recruits coactivators",
            "Wnt target genes such as c-Myc and cyclin D1 are transcribed",
        ],
        actors=["Wnt / Frizzled / LRP5/6", "Dishevelled", "Destruction complex", "β-catenin", "β-catenin",
                "TCF/LEF", "Target genes"],
        parallel=[],
        decoys=[
            "GSK3 and CK1 phosphorylate β-catenin, marking it for ubiquitination and proteasomal destruction",
            "Smad2/3 are phosphorylated by a TGF-β receptor and bind Smad4 before entering the nucleus",
            "IκB is degraded, freeing NF-κB to move into the nucleus",
        ],
        pages=[
            ("Overview", "Wnt proteins are secreted signals that control cell fate, proliferation and tissue "
             "repair. In the canonical pathway the key question is whether the cytoplasmic protein β-catenin "
             "survives. Without Wnt it is constantly made and destroyed, so its level stays low. With Wnt it is "
             "stabilized, builds up, and carries the message into the nucleus."),
            ("Key players", "Wnt binds the receptor Frizzled and the co-receptor LRP5/6. Dishevelled is "
             "recruited to Frizzled. The destruction complex contains the scaffold Axin, the tumour suppressor "
             "APC, and the kinases GSK3 and CK1. Without Wnt, these kinases phosphorylate β-catenin, so it is "
             "ubiquitinated and degraded. In the nucleus β-catenin binds TCF/LEF to switch on target genes."),
            ("Control and consequences", "Because β-catenin turns over quickly, the pathway can respond fast "
             "once the destruction complex is switched off. Mutations in APC are the classic cause of familial "
             "adenomatous polyposis and are found in most colorectal cancers, while some tumours carry "
             "mutations in the phosphorylation sites of β-catenin itself. Both keep β-catenin stable and the "
             "target genes, including c-Myc and cyclin D1, switched on."),
        ],
        note=dict(q="Which tumour suppressor in the destruction complex is mutated in most colorectal cancers?",
                  a="APC", wrong=["Axin", "GSK3", "Dishevelled"]),
        whatif=dict(q="What happens if APC is mutated so the destruction complex cannot work?",
                    a="β-catenin accumulates and target genes stay on without Wnt",
                    wrong=["β-catenin is degraded faster, so target genes switch off",
                           "TCF/LEF can no longer enter the nucleus",
                           "Wnt can no longer bind Frizzled"],
                    why="Without a working destruction complex β-catenin is no longer phosphorylated and degraded, so it reaches the nucleus whether or not Wnt is present."),
    ),
    dict(
        id="p53_damage", name="p53 DNA damage response", cell="fibroblast", stage=4, kind="signalling",
        trigger="DNA double-strand break",
        outcome="p21-mediated G1 arrest, with time for repair or apoptosis",
        steps=[
            "ATM kinase is activated at a DNA double-strand break",
            "ATM phosphorylates Chk2 and p53",
            "Phosphorylated p53 loses Mdm2 binding and escapes ubiquitin-mediated degradation",
            "Stabilized p53 accumulates in the nucleus and acts as a transcription factor",
            "p53 activates transcription of the CDKN1A gene, which encodes p21",
            "p21 inhibits cyclin-CDK complexes, so the cell arrests in G1",
        ],
        actors=["ATM", "ATM / Chk2", "p53 / Mdm2", "p53", "p53 / p21 gene", "p21"],
        parallel=[],
        decoys=[
            "Mdm2 ubiquitinates p53, sending it to the proteasome to keep its level low",
            "Cyclin D-CDK4 phosphorylates Rb, releasing E2F to drive entry into S phase",
            "ATR kinase is recruited to long stretches of single-stranded DNA at stalled forks",
        ],
        pages=[
            ("Overview", "A DNA double-strand break is one of the most dangerous forms of damage. The cell "
             "responds by stopping the cell cycle so that repair can happen before DNA is copied or divided. "
             "The central protein is p53, a transcription factor often called the guardian of the genome. "
             "Normally p53 is kept at very low levels, and damage signals raise it quickly."),
            ("Key players", "The kinase ATM senses double-strand breaks and phosphorylates Chk2 and p53. In an "
             "undamaged cell, the ubiquitin ligase Mdm2 binds p53 and marks it for degradation. Phosphorylation "
             "of p53 weakens Mdm2 binding, so p53 is stabilized. It then activates target genes, including "
             "p21, which inhibits cyclin-CDK complexes and holds the cell in G1."),
            ("Control and consequences", "p53 also turns on Mdm2, forming a negative feedback loop that "
             "switches the response off once damage is repaired. If damage is severe, p53 can instead push "
             "the cell towards apoptosis. p53 is mutated in about half of all human cancers, and inherited "
             "mutations cause Li-Fraumeni syndrome. Cells without functional p53 keep dividing with damaged DNA."),
        ],
        note=dict(q="Which protein binds p53 in undamaged cells and marks it for degradation?",
                  a="Mdm2", wrong=["p21", "Chk2", "ATM"]),
        whatif=dict(q="What happens to a cell with a DNA break if p21 is knocked out?",
                    a="p53 rises, but the G1 arrest is weak, so the cell keeps cycling",
                    wrong=["p53 cannot be stabilized after ATM phosphorylation",
                           "Mdm2 binds p53 more tightly, so p53 is degraded",
                           "The cell arrests permanently in G1"],
                    why="p21 is the link from p53 to CDK inhibition. Without it, p53 can still be stabilized, but the CDKs stay active and the G1 arrest is lost."),
    ),
    dict(
        id="intrinsic_apoptosis", name="Intrinsic apoptosis", cell="fibroblast", stage=4, kind="degradation",
        trigger="Severe cell stress such as DNA damage",
        outcome="Caspase cascade dismantles the cell",
        steps=[
            "BH3-only proteins such as Bim, Puma and Noxa are activated by cell stress",
            "BH3-only proteins activate BAX and BAK, overcoming inhibition by Bcl-2 family members",
            "BAX and BAK oligomerize and permeabilize the mitochondrial outer membrane",
            "Cytochrome c is released from the intermembrane space into the cytosol",
            "Cytochrome c binds Apaf-1, which assembles the apoptosome and activates caspase-9",
            "Caspase-9 cleaves and activates the executioner caspase-3",
            "Caspase-3 cleaves many cellular proteins, dismantling the cell",
        ],
        actors=["BH3-only proteins", "BAX / BAK", "BAX / BAK pores", "Cytochrome c", "Apaf-1 / caspase-9",
                "Caspase-9 / caspase-3", "Caspase-3"],
        parallel=[],
        decoys=[
            "Caspase-8 is activated at a death receptor after FasL binds Fas",
            "Bcl-2 binds BAX and BAK and blocks pore formation, promoting cell survival",
            "Necrosis swells the cell until the plasma membrane ruptures and spills its contents",
        ],
        pages=[
            ("Overview", "Apoptosis is programmed cell death. It removes cells that are damaged, infected or no "
             "longer needed, and it shapes tissues during development. In the intrinsic pathway the decision "
             "is made at the mitochondria. Once the point of no return is passed, a chain of proteases called "
             "caspases dismantles the cell in an orderly way, without leaking its contents."),
            ("Key players", "BH3-only proteins such as Bim, Puma and Noxa sense stress. They activate BAX and "
             "BAK, which form pores that cause mitochondrial outer membrane permeabilization. Cytochrome c "
             "then escapes and binds Apaf-1, which builds the apoptosome and activates the initiator caspase-9. "
             "Caspase-9 cleaves caspase-3, the executioner caspase that cuts hundreds of cell proteins."),
            ("Control and consequences", "Anti-apoptotic proteins such as Bcl-2 and Bcl-xL restrain BAX and "
             "BAK, so the balance between family members sets the threshold for death. Too much Bcl-2, as in "
             "follicular lymphoma where the gene is translocated, lets damaged cells survive. Too much "
             "apoptosis contributes to neurodegeneration. Dying cells are tidily engulfed by phagocytes, which "
             "prevents inflammation."),
        ],
        note=dict(q="Which executioner caspase does caspase-9 activate?",
                  a="Caspase-3", wrong=["Caspase-8", "Caspase-1", "Caspase-12"]),
        whatif=dict(q="What happens if BAX and BAK are both deleted and a cell is stressed?",
                    a="No cytochrome c release, so the intrinsic pathway fails to start",
                    wrong=["Cytochrome c is released, but caspase-9 cannot cut caspase-3",
                           "Caspase-3 is activated directly by BH3-only proteins",
                           "Apaf-1 assembles an apoptosome without cytochrome c"],
                    why="BAX and BAK form the pores in the outer mitochondrial membrane. Without them cytochrome c stays inside, and the apoptosome never forms."),
    ),
    dict(
        id="ubiquitin_proteasome", name="Ubiquitin-proteasome system", cell="fibroblast", stage=4,
        kind="degradation",
        trigger="A protein is damaged or marked for turnover",
        outcome="Substrate cut into short peptides, ubiquitin recycled",
        steps=[
            "E1 uses ATP to activate ubiquitin, forming a thioester bond with ubiquitin",
            "E1 passes the activated ubiquitin to an E2 conjugating enzyme",
            "E3 ligase selects the substrate and brings it to the ubiquitin-loaded E2",
            "Repeated rounds attach a chain of ubiquitin linked through lysine 48 (K48) to the substrate",
            "The 26S proteasome recognizes the K48-linked polyubiquitin chain",
            "The substrate is unfolded by ATPases and cleaved to short peptides in the 20S core",
            "Deubiquitinases disassemble the released chains, recycling free ubiquitin",
        ],
        actors=["E1 enzyme", "E2 enzyme", "E3 ligase", "Polyubiquitin (K48)", "26S proteasome",
                "20S core", "Deubiquitinases"],
        parallel=[],
        decoys=[
            "Lysosomal hydrolases digest the substrate at acidic pH inside an autolysosome",
            "Caspase-3 cleaves the substrate at aspartate residues during apoptosis",
            "A single ubiquitin on the substrate is enough to target it to the proteasome",
        ],
        pages=[
            ("Overview", "Cells constantly destroy proteins that are misfolded, damaged or no longer needed, and "
             "they also remove regulators such as cyclins and p53 at the right moment. The main route in the "
             "cytosol and nucleus is the ubiquitin-proteasome system. A small protein tag, ubiquitin, is "
             "attached to the target, and a large protease complex then destroys it."),
            ("Key players", "Tagging is done by three enzymes. E1 activates ubiquitin using ATP, E2 carries it, "
             "and E3 ligase chooses the substrate, so E3s give the system its specificity. A chain of ubiquitin "
             "linked through lysine 48 (K48) is the signal for degradation. The 26S proteasome has a 20S core "
             "that cleaves proteins and 19S regulatory caps that recognize the chain and unfold the substrate."),
            ("Control and consequences", "Proteasome ATPases unfold the substrate and feed it into the 20S "
             "core, where it is cut into short peptides. Deubiquitinases remove the chains so ubiquitin is "
             "reused rather than destroyed. The system controls the cell cycle, and the proteasome inhibitor "
             "bortezomib is used to treat multiple myeloma. Faulty clearance of misfolded proteins is "
             "linked to neurodegenerative disease."),
        ],
        note=dict(q="Which enzyme class selects the substrate in the ubiquitin system?",
                  a="E3 ligase", wrong=["E1 activating enzyme", "E2 conjugating enzyme", "Deubiquitinase"]),
        whatif=dict(q="What happens if the proteasome is blocked with an inhibitor such as bortezomib?",
                    a="Polyubiquitinated proteins accumulate in the cell",
                    wrong=["Proteins lose their ubiquitin tags, so E1 stops working",
                           "Substrates are degraded faster by lysosomes only",
                           "E3 ligases can no longer select their substrates"],
                    why="Tagging continues upstream, but the tagged proteins cannot be destroyed, so they build up. This is toxic to cells that make a lot of protein."),
    ),
    dict(
        id="ec_coupling", name="Skeletal muscle EC coupling", cell="muscle", stage=5, kind="signalling",
        trigger="Motor neuron releases acetylcholine",
        outcome="Ca2+ release from the SR triggers cross-bridge cycling",
        steps=[
            "Motor neuron releases ACh, which binds nicotinic receptors on the motor end plate",
            "Nicotinic receptor channels open, and Na+ entry produces an end-plate potential",
            "An action potential spreads along the sarcolemma and into the T-tubules",
            "DHPR, a voltage-sensing L-type Ca2+ channel in the T-tubule, changes shape",
            "DHPR is coupled to RyR1, which opens and releases Ca2+ from the sarcoplasmic reticulum",
            "Ca2+ binds troponin C, which shifts tropomyosin and exposes myosin-binding sites on actin",
            "Myosin heads bind actin and cycle through ATP-driven power strokes, shortening the sarcomere",
        ],
        actors=["Acetylcholine", "Nicotinic receptor", "Action potential", "DHPR", "RyR1", "Troponin C",
                "Myosin"],
        parallel=[],
        decoys=[
            "Extracellular Ca2+ entering through DHPR triggers further Ca2+ release through RyR2",
            "Ca2+ binds calmodulin, which activates myosin light chain kinase to phosphorylate myosin",
            "SERCA pumps Ca2+ into the sarcoplasmic reticulum, starting the contraction",
        ],
        pages=[
            ("Overview", "Excitation-contraction coupling links an electrical signal at the muscle surface to "
             "mechanical shortening inside the fibre. A motor neuron releases acetylcholine at the "
             "neuromuscular junction. This produces an action potential that travels along the sarcolemma and "
             "down the T-tubules, and the signal is then converted into a release of Ca2+ from the "
             "sarcoplasmic reticulum."),
            ("Key players", "Acetylcholine opens nicotinic receptors, which produces the end-plate potential. "
             "In the T-tubule membrane the dihydropyridine receptor (DHPR) senses voltage. In skeletal muscle "
             "DHPR is physically linked to RyR1, the Ca2+ release channel of the sarcoplasmic reticulum, and "
             "opens it directly. Ca2+ binds troponin C, which moves tropomyosin and lets myosin bind actin."),
            ("Control and consequences", "Contraction ends when acetylcholinesterase removes acetylcholine "
             "and SERCA pumps Ca2+ back into the sarcoplasmic reticulum, so Ca2+ falls and tropomyosin covers "
             "the binding sites again. Skeletal muscle does not need extracellular Ca2+ for a twitch, unlike "
             "cardiac muscle. Mutations in RyR1 cause malignant hyperthermia, and myasthenia gravis is an "
             "antibody attack on nicotinic receptors."),
        ],
        note=dict(q="Which T-tubule protein senses voltage and opens RyR1 in skeletal muscle?",
                  a="DHPR (dihydropyridine receptor)", wrong=["SERCA", "Troponin C", "Nicotinic receptor"]),
        whatif=dict(q="What happens to a skeletal muscle twitch in a bath with no extracellular Ca2+?",
                    a="It still contracts, because DHPR couples directly to RyR1",
                    wrong=["It fails, because Ca2+ entry must trigger RyR1",
                           "It contracts more strongly because SERCA is blocked",
                           "It fails, because troponin C needs extracellular Ca2+"],
                    why="In skeletal muscle the DHPR acts as a voltage sensor linked to RyR1, so Ca2+ comes from the sarcoplasmic reticulum, not from outside. Cardiac muscle differs."),
    ),
]
