PATHWAYS = [
    dict(
        id="glucagon_glycogenolysis", name="Glucagon and glycogen breakdown", cell="hepatocyte", stage=5,
        kind="signalling",
        trigger="Low blood glucose; glucagon binds the liver cell",
        outcome="Glycogen is broken down and free glucose enters the blood",
        steps=[
            "Glucagon binds its GPCR on the hepatocyte, which triggers GDP-GTP exchange on Gs",
            "Gs α-GTP activates adenylyl cyclase, which makes cAMP from ATP",
            "cAMP binds the regulatory subunits of PKA, releasing active catalytic subunits",
            "PKA phosphorylates and activates phosphorylase kinase",
            "Phosphorylase kinase phosphorylates glycogen phosphorylase b, converting it to the active a form",
            "Glycogen phosphorylase a cleaves glucose units from glycogen as glucose-1-phosphate",
            "Glucose-6-phosphatase frees glucose from glucose-6-phosphate, which leaves the cell",
        ],
        actors=["Glucagon receptor / Gs", "Adenylyl cyclase", "PKA", "PKA", "Phosphorylase kinase",
                "Glycogen phosphorylase a", "Glucose-6-phosphatase"],
        parallel=[],
        decoys=[
            "Glucagon receptor autophosphorylates tyrosine residues and recruits IRS proteins",
            "Phospholipase C cleaves PIP2 into IP3 and DAG, releasing Ca2+ from the ER",
            "Protein phosphatase 1 dephosphorylates glycogen phosphorylase a, switching it off",
        ],
        pages=[
            ("Overview", "When blood glucose falls between meals, alpha cells of the pancreas release glucagon. "
             "Its main target is the liver, where it triggers glycogenolysis, the breakdown of stored glycogen. "
             "The signal passes through a cascade in which each enzyme activates many copies of the next, so a "
             "few hormone molecules at the cell surface lead to the release of a very large amount of glucose "
             "into the blood."),
            ("Key players", "Glucagon binds a G protein-coupled receptor that activates Gs. Gs α-GTP stimulates "
             "adenylyl cyclase, which makes the second messenger cAMP. cAMP activates protein kinase A (PKA), "
             "which phosphorylates phosphorylase kinase. This enzyme converts glycogen phosphorylase b into the "
             "active a form, which releases glucose-1-phosphate. Glucose-6-phosphatase finally releases free "
             "glucose, an enzyme found in liver but not in muscle."),
            ("Control and consequences", "The signal is switched off when glucagon falls, when phosphodiesterase "
             "breaks cAMP down to AMP, and when protein phosphatase 1 removes phosphates from the cascade "
             "enzymes. Insulin opposes the pathway after a meal. Because the cascade multiplies the signal at "
             "every step, the amplification is large. Muscle lacks glucagon receptors and glucose-6-phosphatase, "
             "so it cannot supply blood glucose."),
        ],
        note=dict(q="Which enzyme finally releases free glucose from glucose-6-phosphate in the liver?",
                  a="Glucose-6-phosphatase",
                  wrong=["Glycogen phosphorylase a", "Phosphorylase kinase", "Hexokinase"]),
        whatif=dict(q="What happens in the liver if phosphodiesterase is blocked while glucagon is present?",
                    a="cAMP stays high, so glycogen breakdown is prolonged",
                    wrong=["cAMP falls, so glycogen breakdown stops", "Glucagon can no longer bind its receptor",
                           "Glycogen synthesis is switched on instead"],
                    why="Phosphodiesterase normally converts cAMP to AMP. Without it, PKA stays active and the cascade keeps running."),
    ),
    dict(
        id="insulin_glycogen", name="Insulin and glycogen synthesis", cell="hepatocyte", stage=5,
        kind="signalling",
        trigger="High blood glucose; insulin binds its receptor",
        outcome="Glycogen synthase is active and glycogen is built",
        steps=[
            "Insulin binds the extracellular α subunits of its receptor tyrosine kinase",
            "The receptor's β subunits autophosphorylate on tyrosine residues",
            "The activated receptor phosphorylates IRS proteins on tyrosine",
            "PI3K binds phosphorylated IRS and converts PIP2 into PIP3 in the membrane",
            "PIP3 recruits PDK1 and Akt, and PDK1 phosphorylates and activates Akt",
            "Akt phosphorylates GSK3, which inhibits it",
            "Glycogen synthase is dephosphorylated by PP1, becomes active and extends glycogen",
        ],
        actors=["Insulin receptor", "Insulin receptor", "IRS proteins", "PI3K", "PDK1 / Akt", "Akt",
                "Glycogen synthase"],
        parallel=[],
        decoys=[
            "Gs activates adenylyl cyclase, raising cAMP and activating PKA",
            "PTEN converts PIP2 into PIP3 at the plasma membrane",
            "Glycogen phosphorylase a releases glucose-1-phosphate from glycogen",
        ],
        pages=[
            ("Overview", "After a meal, rising blood glucose makes pancreatic beta cells release insulin. In "
             "the liver, insulin promotes storage of glucose as glycogen. Unlike glucagon, insulin does not use "
             "a G protein. Its receptor is itself an enzyme, a receptor tyrosine kinase, and signals through "
             "phosphorylation and a membrane lipid messenger."),
            ("Key players", "The insulin receptor is a tetramer of two α and two β subunits. When insulin "
             "binds, the β subunits autophosphorylate on tyrosine and then phosphorylate IRS proteins. PI3K "
             "binds IRS and makes PIP3. PIP3 recruits PDK1 and Akt, also called protein kinase B. Akt "
             "phosphorylates glycogen synthase kinase 3 (GSK3) and inhibits it. Glycogen synthase, no longer "
             "held inactive by GSK3 phosphorylation, is dephosphorylated by protein phosphatase 1 (PP1)."),
            ("Control and consequences", "The lipid phosphatase PTEN removes the 3-phosphate from PIP3 and so "
             "switches the pathway off. Loss of PTEN function is common in cancer, because Akt also drives "
             "growth and survival. In type 2 diabetes, tissues respond poorly to insulin, a condition called "
             "insulin resistance, and the liver stores less glycogen while blood glucose stays high."),
        ],
        note=dict(q="Which kinase phosphorylates and inhibits GSK3 in insulin signalling?",
                  a="Akt, also called protein kinase B",
                  wrong=["Protein kinase A", "PDK1", "Phosphorylase kinase"]),
        whatif=dict(q="A PI3K inhibitor is added to hepatocytes. What happens to glycogen synthase after insulin?",
                    a="It stays phosphorylated and inactive",
                    wrong=["It becomes more active than normal", "It is activated by cAMP instead",
                           "It is unaffected, since insulin uses PKA"],
                    why="Without PI3K there is no PIP3 or Akt activation, so GSK3 stays active and keeps glycogen synthase phosphorylated and inactive."),
    ),
    dict(
        id="srebp_cholesterol", name="SREBP-2 cholesterol control", cell="hepatocyte", stage=5,
        kind="synthesis",
        trigger="Low sterol levels in the ER membrane",
        outcome="More cholesterol synthesis and LDL uptake",
        steps=[
            "Falling sterol levels release the SCAP-SREBP-2 complex from Insig in the ER membrane",
            "SCAP escorts SREBP-2 in COPII vesicles from the ER to the Golgi",
            "Site-1 protease cuts SREBP-2 within its luminal loop",
            "Site-2 protease cuts the membrane segment, freeing the N-terminal fragment",
            "The SREBP-2 fragment enters the nucleus and binds sterol regulatory elements (SREs)",
            "Transcription of the HMG-CoA reductase and LDL receptor genes is induced",
            "HMG-CoA reductase and LDL receptors accumulate, raising cholesterol synthesis and uptake",
        ],
        actors=["SCAP / Insig", "SCAP", "Site-1 protease", "Site-2 protease", "SREBP-2 fragment",
                "SREBP-2 fragment", "HMG-CoA reductase"],
        parallel=[],
        decoys=[
            "Insig binds SCAP and keeps the SCAP-SREBP complex in the ER",
            "Cholesterol 7α-hydroxylase converts cholesterol into bile acids",
            "AMPK phosphorylates HMG-CoA reductase, which inactivates it",
        ],
        pages=[
            ("Overview", "Liver cells keep cholesterol within narrow limits by sensing sterols in the "
             "endoplasmic reticulum (ER) membrane. When sterols are low, a membrane-bound transcription factor, "
             "SREBP-2, is carried to the Golgi and cut loose. Its released fragment switches on genes for "
             "cholesterol synthesis and uptake, so the cell restores its supply."),
            ("Key players", "SREBP-2 sits in the ER membrane bound to SCAP, a sterol-sensing escort protein. "
             "When sterols are low, SCAP carries SREBP-2 to the Golgi in COPII vesicles. There, site-1 protease "
             "(S1P) and site-2 protease (S2P) cleave it in turn. The N-terminal fragment travels to the nucleus "
             "and binds sterol regulatory elements (SREs), inducing the genes for HMG-CoA reductase and the "
             "LDL receptor."),
            ("Control and consequences", "When sterols are high, SCAP changes shape and binds Insig, which "
             "retains the SCAP-SREBP complex in the ER, so no cleavage occurs. This negative feedback holds "
             "cholesterol steady. Statins inhibit HMG-CoA reductase, lower cell cholesterol and activate "
             "SREBP-2, which raises LDL receptor numbers and so lowers LDL in the blood."),
        ],
        note=dict(q="Which protein retains the SCAP-SREBP complex in the ER when sterols are high?",
                  a="Insig", wrong=["S1P", "HMG-CoA reductase", "The LDL receptor"]),
        whatif=dict(q="Why do statins raise the number of LDL receptors on liver cells?",
                    a="Falling sterols activate SREBP-2, which induces the LDL receptor gene",
                    wrong=["Statins bind the LDL receptor directly", "Statins block Insig from binding SCAP in the ER",
                           "Statins raise cholesterol, which activates SREBP-2"],
                    why="Statins block HMG-CoA reductase and lower cell sterols, so SCAP releases from Insig and SREBP-2 is processed. More LDL receptors clear blood LDL."),
    ),
    dict(
        id="gsis", name="Glucose-stimulated insulin secretion", cell="beta_cell", stage=5,
        kind="signalling",
        trigger="Blood glucose rises after a meal",
        outcome="Insulin granules are released from the beta cell",
        steps=[
            "GLUT2 carries glucose into the beta cell down its concentration gradient",
            "Glucokinase phosphorylates glucose to glucose-6-phosphate, committing it to metabolism",
            "Glycolysis and mitochondrial oxidation raise the cytosolic ATP/ADP ratio",
            "ATP binds the K-ATP channel, which closes",
            "Reduced K+ efflux depolarizes the plasma membrane",
            "Voltage-gated Ca2+ channels open and Ca2+ flows into the cell",
            "Rising Ca2+ triggers exocytosis of insulin-containing granules",
        ],
        actors=["GLUT2", "Glucokinase", "Glycolysis / mitochondria", "K-ATP channel", "K-ATP channel",
                "Voltage-gated Ca2+ channel", "Insulin granules"],
        parallel=[],
        decoys=[
            "ATP opens the K-ATP channel, hyperpolarizing the beta cell",
            "Glucose binds a surface GPCR that activates Gs and adenylyl cyclase",
            "GLUT4 vesicles fuse with the membrane to import glucose in response to insulin",
        ],
        pages=[
            ("Overview", "Pancreatic beta cells act as glucose sensors. When blood glucose rises, they secrete "
             "insulin in proportion. The sensing does not use a surface receptor for glucose. Instead, glucose "
             "is metabolized inside the cell, and the resulting change in the ATP/ADP ratio is converted into an "
             "electrical signal and then a calcium signal that releases stored insulin."),
            ("Key players", "GLUT2 lets glucose enter freely, so intracellular glucose tracks blood glucose. "
             "Glucokinase, with its high Km, acts as the glucose sensor and sets the rate of metabolism. The "
             "ATP-sensitive potassium channel (K-ATP) is made of Kir6.2 pore subunits and SUR1 regulatory "
             "subunits. ATP closes it. Closure depolarizes the cell and opens voltage-gated Ca2+ channels."),
            ("Control and consequences", "Sulfonylurea drugs used in type 2 diabetes bind SUR1, close K-ATP "
             "channels and trigger insulin release even at low glucose, which can cause hypoglycemia. "
             "Activating mutations of Kir6.2 keep the channel open and cause neonatal diabetes, because the "
             "cell cannot depolarize. Release of insulin lowers blood glucose, which then reduces the signal."),
        ],
        note=dict(q="Which channel's closure depolarizes the beta cell after glucose metabolism?",
                  a="The ATP-sensitive potassium channel (K-ATP)",
                  wrong=["The voltage-gated Ca2+ channel", "GLUT2", "The NMDA receptor"]),
        whatif=dict(q="What does a sulfonylurea drug do to a beta cell at low blood glucose?",
                    a="It closes K-ATP channels and triggers insulin secretion",
                    wrong=["It opens K-ATP channels and blocks secretion", "It blocks GLUT2 uptake of glucose",
                           "Nothing, since secretion needs glucose uptake"],
                    why="Sulfonylureas bind SUR1 and close K-ATP channels directly, so the cell depolarizes and secretes insulin without a glucose signal."),
    ),
    dict(
        id="synaptic_transmission", name="Chemical synaptic transmission", cell="neuron", stage=5,
        kind="signalling",
        trigger="An action potential reaches the presynaptic terminal",
        outcome="A postsynaptic potential, then clearance of the transmitter",
        steps=[
            "An action potential depolarizes the presynaptic terminal",
            "Voltage-gated Ca2+ channels in the terminal open and Ca2+ enters",
            "Synaptotagmin on docked synaptic vesicles binds the incoming Ca2+",
            "SNARE proteins zipper together and fuse the vesicle with the plasma membrane",
            "Neurotransmitter diffuses across the cleft and binds postsynaptic receptors",
            "Ligand-gated ion channels open, producing a postsynaptic potential",
            "Reuptake transporters and enzymes clear the neurotransmitter from the cleft",
        ],
        actors=["Action potential", "Voltage-gated Ca2+ channel", "Synaptotagmin", "SNARE proteins",
                "Neurotransmitter", "Ligand-gated channel", "Transporters / enzymes"],
        parallel=[],
        decoys=[
            "Gs activates adenylyl cyclase in the terminal, directly causing vesicle fusion",
            "Neurotransmitter enters the postsynaptic cell and acts on the nucleus",
            "Botulinum toxin cleaves SNARE proteins, blocking vesicle fusion",
        ],
        pages=[
            ("Overview", "At a chemical synapse, an electrical signal in one neuron is converted into a "
             "chemical signal and back into an electrical one in the next cell. The presynaptic terminal "
             "releases neurotransmitter from vesicles. It crosses the narrow synaptic cleft and changes the "
             "membrane potential of the postsynaptic cell. The delay is only about a millisecond."),
            ("Key players", "Voltage-gated Ca2+ channels near the active zone open when the action potential "
             "arrives. Synaptotagmin is the Ca2+ sensor on synaptic vesicles. The SNARE proteins synaptobrevin "
             "on the vesicle and syntaxin and SNAP-25 on the plasma membrane pull the membranes together to "
             "fuse them. Postsynaptic ligand-gated ion channels, such as the nicotinic acetylcholine receptor, "
             "open when transmitter binds."),
            ("Control and consequences", "Transmitter must be removed so the signal ends. Acetylcholinesterase "
             "breaks down acetylcholine, while transporters take up other transmitters such as glutamate and "
             "serotonin. Botulinum and tetanus toxins cleave SNARE proteins and block release, causing "
             "paralysis. Excitatory channels depolarize the postsynaptic cell, while inhibitory channels such "
             "as the GABA-A receptor, a Cl- channel, hyperpolarize it."),
        ],
        note=dict(q="Which protein acts as the Ca2+ sensor that triggers vesicle fusion?",
                  a="Synaptotagmin",
                  wrong=["Syntaxin", "Synaptobrevin", "Acetylcholinesterase"]),
        whatif=dict(q="What happens at a nerve-muscle synapse if botulinum toxin cleaves the SNARE proteins?",
                    a="Release fails, so the muscle is paralyzed",
                    wrong=["Release is excessive, causing spasm", "Receptors are blocked on the muscle",
                           "Acetylcholine is not broken down"],
                    why="Vesicles cannot fuse without intact SNAREs, so no acetylcholine reaches the muscle receptors even though Ca2+ still enters."),
    ),
    dict(
        id="ltp", name="Long-term potentiation", cell="neuron", stage=5,
        kind="signalling",
        trigger="Strong glutamate input at a glutamatergic synapse",
        outcome="A stronger synapse with more postsynaptic AMPA receptors",
        steps=[
            "Glutamate binds postsynaptic AMPA receptors, which open and let Na+ in",
            "Na+ entry through AMPA receptors depolarizes the postsynaptic membrane",
            "Depolarization expels Mg2+ from the pore of the NMDA receptor",
            "Glutamate-bound NMDA receptors now conduct Ca2+ into the spine",
            "Ca2+ with calmodulin activates CaMKII, which autophosphorylates and stays active",
            "CaMKII phosphorylates AMPA receptors and promotes their insertion into the membrane",
            "Extra AMPA receptors increase the response to glutamate, so the synapse is stronger",
        ],
        actors=["AMPA receptor", "AMPA receptor", "NMDA receptor", "NMDA receptor", "CaMKII", "CaMKII",
                "AMPA receptors"],
        parallel=[],
        decoys=[
            "Calcineurin dephosphorylates AMPA receptors, driving their removal from the synapse",
            "AMPA receptors carry large Ca2+ currents that directly activate CaMKII",
            "CaMKII is activated when cAMP binds its regulatory subunit",
        ],
        pages=[
            ("Overview", "Long-term potentiation (LTP) is a lasting increase in the strength of a synapse "
             "after intense activity. It is a leading cellular model for learning and memory and was first "
             "described in the hippocampus. At many glutamatergic synapses, it needs two things at once: "
             "glutamate released by the presynaptic cell and strong depolarization of the postsynaptic cell."),
            ("Key players", "AMPA receptors carry most of the fast current, letting Na+ in. NMDA receptors are "
             "both ligand-gated and voltage-dependent: at resting potential, Mg2+ blocks their pore. Once "
             "depolarization relieves the Mg2+ block, glutamate-bound NMDA receptors let Ca2+ enter. The Ca2+ "
             "activates calcium/calmodulin-dependent protein kinase II (CaMKII), which phosphorylates AMPA "
             "receptors and promotes their insertion into the postsynaptic membrane."),
            ("Control and consequences", "Because NMDA receptors need both glutamate and depolarization, they "
             "act as coincidence detectors. CaMKII autophosphorylates and can stay active after Ca2+ falls. "
             "Blocking NMDA receptors with the antagonist AP5 prevents LTP induction but leaves normal "
             "AMPA-mediated transmission intact. Weaker, prolonged Ca2+ signals instead activate phosphatases "
             "such as calcineurin and cause long-term depression."),
        ],
        note=dict(q="Which receptor acts as the coincidence detector because of its Mg2+ block?",
                  a="The NMDA receptor",
                  wrong=["The AMPA receptor", "The nicotinic acetylcholine receptor", "The GABA-A receptor"]),
        whatif=dict(q="What does the NMDA antagonist AP5 do to a hippocampal synapse?",
                    a="It prevents LTP induction but spares basic AMPA transmission",
                    wrong=["It abolishes all synaptic transmission", "It strengthens the synapse",
                           "It blocks only the presynaptic release of glutamate"],
                    why="AP5 blocks the Ca2+ entry through NMDA receptors that induces LTP, while AMPA receptors still carry ordinary synaptic current."),
    ),
]
