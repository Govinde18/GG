PATHWAYS = [
    dict(
        id="glycolysis", name="Glycolysis", cell="ecoli", stage=1, kind="energy",
        trigger="Glucose enters the cell",
        outcome="Pyruvate, a net 2 ATP and 2 NADH per glucose",
        steps=[
            "Glucose is phosphorylated to glucose-6-phosphate, which traps it inside the cell",
            "Phosphoglucose isomerase converts glucose-6-phosphate into fructose-6-phosphate",
            "Phosphofructokinase-1 adds a second phosphate, making fructose-1,6-bisphosphate",
            "Aldolase splits it into two three-carbon sugars, DHAP and glyceraldehyde-3-phosphate",
            "GAPDH oxidizes glyceraldehyde-3-phosphate and reduces NAD+ to NADH",
            "Phosphoglycerate kinase passes a phosphate from 1,3-bisphosphoglycerate to ADP, making ATP",
            "Pyruvate kinase transfers the last phosphate from PEP to ADP, forming pyruvate and ATP",
        ],
        actors=["Hexokinase / PTS", "Phosphoglucose isomerase", "Phosphofructokinase-1", "Aldolase",
                "GAPDH", "Phosphoglycerate kinase", "Pyruvate kinase"],
        parallel=[],
        decoys=[
            "Pyruvate dehydrogenase converts pyruvate into acetyl-CoA and releases CO2",
            "Citrate synthase condenses acetyl-CoA with oxaloacetate to form citrate",
            "Fructose-1,6-bisphosphatase removes a phosphate during gluconeogenesis",
        ],
        pages=[
            ("Overview", "Glycolysis splits one six-carbon glucose into two three-carbon pyruvate molecules. "
             "It happens in the cytoplasm, needs no oxygen and is found in almost every living cell. The "
             "pathway has an investment phase that spends 2 ATP and a payoff phase that makes 4 ATP, so the "
             "net gain is 2 ATP and 2 NADH per glucose."),
            ("Key players", "Ten enzymes carry it out. The three big control points are the first kinase, "
             "phosphofructokinase-1 (PFK-1) and pyruvate kinase. PFK-1 makes fructose-1,6-bisphosphate, the "
             "commitment step. GAPDH makes NADH, and phosphoglycerate kinase and pyruvate kinase make ATP "
             "directly by substrate-level phosphorylation, without needing oxygen or a membrane."),
            ("Control and consequences", "PFK-1 is slowed by high ATP and citrate, which tell the cell that "
             "energy is plentiful, and sped up by AMP. Without oxygen, bacteria and yeast recycle NADH "
             "through fermentation so glycolysis can continue. Pyruvate then feeds the citric acid cycle "
             "or fermentation products, depending on whether oxygen is available."),
        ],
        note=dict(q="Which enzyme makes fructose-1,6-bisphosphate, the commitment step?",
                  a="Phosphofructokinase-1", wrong=["Pyruvate kinase", "Aldolase", "GAPDH"]),
        whatif=dict(q="What happens to glycolytic flux when ATP is very high?",
                    a="It slows down because ATP inhibits PFK-1",
                    wrong=["It speeds up to store the extra ATP", "It does not change at all",
                           "It stops because glucose cannot enter"],
                    why="ATP is an allosteric inhibitor of PFK-1, so a high-energy cell throttles glycolysis."),
    ),
]
