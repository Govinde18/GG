PATHWAYS = [
    dict(
        id="lambda_switch", name="Lambda prophage induction", cell="phage", stage=5, kind="regulation",
        trigger="DNA damage hits an E. coli carrying a lambda prophage",
        outcome="The prophage is induced, the host lyses and new phage are released",
        steps=[
            "DNA damage leaves stretches of single-stranded DNA in the host cell",
            "RecA binds the single-stranded DNA and forms an active RecA filament",
            "The RecA filament stimulates the lambda CI repressor to cut itself (autocleavage)",
            "Cleaved CI can no longer hold the operators OR1 and OR2, so the promoters PR and PL open",
            "RNA polymerase transcribes cro and the early lytic genes from the freed promoters",
            "Cro binds OR3 and shuts off cI transcription from PRM, locking in the lytic decision",
            "Late genes make holin and endolysin, which break the cell envelope and release new phage",
        ],
        actors=["DNA damage", "RecA", "CI repressor", "OR1 / OR2 operators", "RNA polymerase", "Cro",
                "Holin and endolysin"],
        parallel=[],
        decoys=[
            "CI dimers bind OR1 and OR2 and switch on cI transcription from the PRM promoter",
            "Lambda integrase inserts the phage genome into the host chromosome at the attachment site",
            "Lactose binds the Lac repressor, which releases the operator",
        ],
        pages=[
            ("Overview", "Bacteriophage lambda can live quietly inside E. coli as a prophage, copied along "
             "with the host chromosome, or it can switch to the lytic program and burst the cell. The decision "
             "rests on a genetic switch between two proteins, the CI repressor and Cro. While CI is abundant "
             "the phage sleeps. When the host is in danger, the switch flips, the prophage is induced and "
             "new phage particles are made."),
            ("Key players", "CI repressor binds as a dimer to the operators OR1 and OR2, blocks the promoter "
             "PR and switches on its own gene from PRM. Cro binds in the opposite order, taking OR3 first, "
             "which shuts off PRM. RecA is the host protein that senses single-stranded DNA. Holin makes holes "
             "in the inner membrane, and endolysin digests the peptidoglycan wall of the cell."),
            ("Control and consequences", "Induction uses the same alarm that drives the host SOS response: "
             "activated RecA stimulates CI to cleave itself, much as it helps cleave LexA. The switch is "
             "bistable, so once Cro wins the decision is hard to reverse. Lysogeny protects the phage while "
             "the host is healthy, and lysis lets it escape a host that is in trouble. Some prophages also "
             "carry toxin genes that the host then expresses."),
        ],
        note=dict(q="Which host protein senses single-stranded DNA and triggers cleavage of CI?",
                  a="RecA", wrong=["LexA", "Cro", "Holin"]),
        whatif=dict(q="A lambda mutant makes a CI repressor that cannot cut itself. What happens after severe DNA damage?",
                    a="The prophage stays dormant and is not induced",
                    wrong=["The phage lyses the cell faster", "Cro is made at very high levels",
                           "RecA stops working in the host"],
                    why="Without autocleavage CI stays on OR1 and OR2, so PR remains blocked and the lytic program never starts."),
    ),
]
