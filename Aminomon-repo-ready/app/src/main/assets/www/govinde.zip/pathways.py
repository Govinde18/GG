"""All pathway content, merged from the paths_*.py files and checked at load."""
import paths_a, paths_b, paths_c, paths_d, paths_e, paths_glyco, paths_phage
import cells

ALL = (paths_glyco.PATHWAYS + paths_a.PATHWAYS + paths_b.PATHWAYS + paths_c.PATHWAYS
       + paths_d.PATHWAYS + paths_e.PATHWAYS + paths_phage.PATHWAYS)
PATH = {p["id"]: p for p in ALL}
assert len(PATH) == len(ALL), "duplicate pathway id"
for _cid, _c in cells.CELLS.items():
    for _pid in _c["order"]:
        assert PATH[_pid]["cell"] == _cid, (_pid, _cid)
assert set(PATH) == {p for c in cells.CELLS.values() for p in c["order"]}, "pathway not in any cell order"


def stage_paths(stage):
    return [p for cid in cells.CELL_ORDER if cells.CELLS[cid]["stage"] == stage for p in cells.CELLS[cid]["order"]]


def cost_of(pid):
    p = PATH[pid]
    n = max(0, p["stage"] - 1)
    return {cells.KIND_COST[p["kind"]]: n} if n else {}
