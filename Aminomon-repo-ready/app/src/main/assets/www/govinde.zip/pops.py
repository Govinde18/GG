"""Spaced repetition: pathways you get wrong come back as pop quizzes, review rounds and exam questions."""
import random

import cells
import dibujo as d
import logic
import pathways
import quiz
import save
import sound
import ultimatum


def solved_ids(j):
    return [p for p in j["solved"] if p in pathways.PATH]


def pick(j, rng=random):
    """Weak pathways are much more likely to be chosen."""
    ids = solved_ids(j)
    if not ids:
        return None
    weights = [1 + 4 * j["weak"].get(p, 0) for p in ids]
    return rng.choices(ids, weights)[0]


def make_question(pid):
    p = pathways.PATH[pid]
    n, w = p["note"], p["whatif"]
    q, a, wr, why = ultimatum._order_question(p)
    return random.choice([(n["q"], n["a"], n["wrong"], None), (w["q"], w["a"], w["wrong"], w["why"]),
                          (q, a, wr, why)])


def ask(win, j, pid, title):
    """True / False, or None when skipped. Updates the weak-spot list."""
    p = pathways.PATH[pid]
    q, a, wr, why = make_question(pid)
    ok = quiz.ask(win, f"{title} · {p['name']}", q, a, wr, why, allow_exit=True)
    if ok is None:
        return None
    if ok:
        logic.weak_ok(j, pid)
        sound.play("good")
    else:
        logic.weak_add(j, pid)
        sound.play("bad")
    return ok


def pop_quiz(win, j):
    pid = pick(j)
    if pid is None:
        return
    weak = pid in j["weak"]
    if d.menu(win, "Govinde pops up!  " + ("I remember you struggled with something..." if weak
                                          else "Quick question, little cell?"),
              ["Answer", "Later"]) != 0:
        return
    ok = ask(win, j, pid, "Pop quiz")
    if ok:
        mat = random.choice(cells.CELLS[pathways.PATH[pid]["cell"]]["makes"])
        logic.gain(j, {mat: 1})
        save.count(j, "popquiz")
        d.popup(win, f"+1 {mat}", "Govinde", ancho=30, attr=d.c("bien"))


def review_round(win, j):
    ids = solved_ids(j)
    if not ids:
        d.popup(win, "Deduce a pathway first. Then Govinde can quiz you on it.", "Review")
        return
    weak = logic.weak_list(j)
    if weak:
        d.popup(win, "Your weak spots, most urgent first:\n\n" + "\n".join(
            f"• {pathways.PATH[p]['name']}" for p in weak[:8]), "Review round", ancho=60)
    pool = weak[:5] + random.sample(ids, min(len(ids), 5))
    seen, order = set(), []
    for p in pool:
        if p not in seen:
            seen.add(p)
            order.append(p)
    order = order[:5]
    score = 0
    for i, pid in enumerate(order, 1):
        r = ask(win, j, pid, f"Review {i}/{len(order)}")
        if r is None:
            break
        score += bool(r)
    gain = score // 2
    j["insight"] += gain
    save.count(j, "reviews")
    save.write(j)
    d.popup(win, f"{score}/{len(order)} correct.\n+{gain} Insight.", "Review round", ancho=40,
            attr=d.c("bien" if score else "mal"))
