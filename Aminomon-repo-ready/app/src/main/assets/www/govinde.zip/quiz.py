"""One multiple-choice question in a box. Returns True / False, or None if the player pressed Esc."""
import curses
import random

import dibujo as d


def ask(win, title, question, correct, wrong, why=None, allow_exit=True, extra_title=None):
    options = [correct] + list(wrong)
    random.shuffle(options)
    alto, ancho = win.getmaxyx()
    w = min(84, ancho - 4)
    lines = d.envolver(question, w - 4)
    opt_lines = [d.envolver(f"{i + 1}) {o}", w - 8) for i, o in enumerate(options)]
    h = len(lines) + sum(len(x) for x in opt_lines) + 6
    y0 = max(0, (alto - h) // 2)
    x0 = (ancho - w) // 2
    with d.capa():
        d.reiniciar_regiones()
        d.limpiar_area(win, y0, x0, h, w)
        d.caja(win, y0, x0, h, w, title)
        d.region(y0, x0, h, w, None)
        y = y0 + 1
        for l in lines:
            d.put(win, y, x0 + 2, l, d.c("texto", curses.A_BOLD))
            y += 1
        y += 1
        for i, ol in enumerate(opt_lines):
            d.region(y, x0 + 1, len(ol), w - 2, str(i + 1))
            for l in ol:
                d.put(win, y, x0 + 4, l, d.c("texto"))
                y += 1
        hint = "Press the number or click an answer" + ("  ·  Esc to skip" if allow_exit else "")
        d.put(win, y0 + h - 2, x0 + 2, hint, d.c("tenue"))
        win.refresh()
        while True:
            k = d.tecla(win)
            if allow_exit and k == d.ESC:
                return None
            if isinstance(k, str) and k.isdigit() and 1 <= int(k) <= len(options):
                chosen = options[int(k) - 1]
                break
    ok = chosen == correct
    text = ("Correct!" if ok else f"Not quite. The answer was: {correct}.")
    if why:
        text += "\n\n" + why
    d.popup(win, text, "Result", ancho=min(76, ancho - 4), attr=d.c("bien" if ok else "mal"))
    return ok
