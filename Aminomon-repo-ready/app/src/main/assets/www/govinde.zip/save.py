"""Saved game: ~/.govinde_signal.json"""
import json
import os

import cells

FILE = os.path.expanduser("~/.govinde_signal.json")


def new():
    return dict(
        version=1, cell="ecoli", cells=["ecoli"], solved={}, paid=[], read={}, insight=2,
        mats={m: 0 for m in cells.MATERIALS} | {"ATP": 3, "Nucleotides": 2}, used={},
        ultimatums=[], final=False, pos=[22, 27], seen=[], picked=[], told=[], weak={}, upgrades=[], charges={}, active={}, field=None, bosses=[], dex=dict(zones=[], stress=[], parts=[], bosses=[]), quests=[], ending=None, player="", looted=[], clock=0, seals=[], stats={}, crosstalk=[], intro=False, sound=True,
    )


def load():
    try:
        with open(FILE, encoding="utf-8") as f:
            j = json.load(f)
    except (OSError, ValueError):
        return None
    base = new()
    for k, v in base.items():
        j.setdefault(k, v)
    for m in cells.MATERIALS:
        j["mats"].setdefault(m, 0)
    for k in ("zones", "stress", "parts", "bosses"):
        j["dex"].setdefault(k, [])
    import upgrades
    for uid in j["upgrades"]:
        if uid in upgrades.UPGRADES and uid not in j["charges"]:
            j["charges"][uid] = upgrades.UPGRADES[uid]["max"]
    return j


def write(j):
    tmp = FILE + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(j, f, indent=1)
        os.replace(tmp, FILE)
    except OSError:
        pass


def count(j, key, n=1):
    j["stats"][key] = j["stats"].get(key, 0) + n
    return j["stats"][key]
