"""Govinde Seals (achievements)."""
import cells
import dibujo as d
import logic
import pathways

SEALS = [
    ("first", "First Deduction", "Deduce your first pathway.", lambda j: len(j["solved"]), 1),
    ("five", "Pathfinder", "Deduce 5 pathways.", lambda j: len(j["solved"]), 5),
    ("fifteen", "Cartographer", "Deduce 15 pathways.", lambda j: len(j["solved"]), 15),
    ("all", "The Whole Map", "Deduce all pathways.", lambda j: len(j["solved"]), len(pathways.ALL)),
    ("flawless3", "Flawless", "Deduce 3 pathways with no mistakes.", lambda j: j["stats"].get("flawless", 0), 3),
    ("nohint3", "Unaided", "Deduce 3 pathways without hints.", lambda j: j["stats"].get("no_hint", 0), 3),
    ("stars", "Star Collector", "Earn 30 stars in total.", logic.total_stars, 30),
    ("reader", "Bookworm", "Read 30 Codex pages.", lambda j: sum(len(v) for v in j["read"].values()), 30),
    ("scholar", "Scholar", "Read the entire Codex.", lambda j: sum(len(v) for v in j["read"].values()), len(pathways.ALL) * 3),
    ("cells3", "Cell Hopper", "Unlock 3 cells.", lambda j: len(j["cells"]), 3),
    ("cells_all", "Every Cell", "Unlock every cell.", lambda j: len(j["cells"]), len(cells.CELLS)),
    ("harvest10", "Farmer", "Harvest 10 times.", lambda j: j["stats"].get("harvests", 0), 10),
    ("ult1", "Phage Apprentice", "Pass the Stage 1 Ultimatum.", lambda j: int(1 in j["ultimatums"]), 1),
    ("ult3", "Nuclear Navigator", "Pass the Stage 3 Ultimatum.", lambda j: int(3 in j["ultimatums"]), 1),
    ("ult5", "Master of Messengers", "Pass the Stage 5 Ultimatum.", lambda j: int(5 in j["ultimatums"]), 1),
    ("link", "Crosstalker", "Make 5 crosstalk links in the lab.", lambda j: len(j["crosstalk"]), 5),
    ("hazard5", "Stress Tested", "Answer 5 stressors.", lambda j: j["stats"].get("hazards", 0), 5),
    ("quest5", "Detective", "Solve 5 crosstalk quests.", lambda j: len(j["quests"]), 5),
    ("questall", "Master Detective", "Solve every crosstalk quest.", lambda j: len(j["quests"]), 13),
    ("organelles", "Organelle Collector", "Find every organelle.", lambda j: len(j["upgrades"]), 7),
    ("pop5", "Always Ready", "Answer 5 pop quizzes.", lambda j: j["stats"].get("popquiz", 0), 5),
    ("review", "Reviewer", "Finish 3 review rounds.", lambda j: j["stats"].get("reviews", 0), 3),
    ("ending", "Govinde's Choice", "Decide what Govinde does.", lambda j: int(bool(j.get("ending"))), 1),
    ("field5", "Field Worker", "Finish field work for 5 pathways.", lambda j: j["stats"].get("fieldwork", 0), 5),
    ("field15", "Lab Veteran", "Finish field work for 15 pathways.", lambda j: j["stats"].get("fieldwork", 0), 15),
    ("boss1", "Boss Slayer", "Defeat a boss stressor.", lambda j: len(j["bosses"]), 1),
    ("bossall", "Stress Master", "Defeat all 5 boss stressors.", lambda j: len(j["bosses"]), 5),
    ("naturalist", "Naturalist", "Fill 60 journal entries.", lambda j: len(j["dex"]["zones"]) + len(j["dex"]["stress"]) + len(j["dex"]["bosses"]) + len(j["quests"]), 60),
    ("final", "Protocol Complete", "Pass the Grand Ultimatum.", lambda j: int(j["final"]), 1),
]
BY_ID = {s[0]: s for s in SEALS}


def progress(j, seal):
    _, _, _, f, goal = seal
    return min(f(j), goal), goal


def check(win, j):
    """Show a popup for each newly earned seal. Returns True if anything was earned."""
    new = False
    for seal in SEALS:
        if seal[0] in j["seals"]:
            continue
        v, goal = progress(j, seal)
        if v >= goal:
            j["seals"].append(seal[0])
            d.popup(win, f"{seal[1]}\n\n{seal[2]}", "Govinde Seal earned", ancho=50, attr=d.c("bien"))
            new = True
    return new


def show(win, j):
    rows = []
    for seal in SEALS:
        v, goal = progress(j, seal)
        rows.append(("♦ " if seal[0] in j["seals"] else "· ") + f"{seal[1]:<22} {v}/{goal:<3} {seal[2]}")
    d.menu(win, f"Govinde Seals {len(j['seals'])}/{len(SEALS)}", rows, ancho=min(100, win.getmaxyx()[1] - 2))
