"""Simple beeps. Real sound only where the Windows console offers winsound; silent elsewhere."""
import threading

try:
    import winsound
except ImportError:          # not Windows
    winsound = None

ENABLED = [True]
TUNES = {
    "pickup": [(880, 45)],
    "gate": [(330, 70), (494, 70), (659, 90)],
    "good": [(523, 70), (659, 70), (784, 110)],
    "bad": [(220, 110), (165, 160)],
    "step": [(660, 40)],
    "hazard": [(196, 90), (147, 90), (196, 90)],
    "win": [(523, 90), (659, 90), (784, 90), (1047, 220)],
    "upgrade": [(659, 60), (784, 60), (988, 60), (1319, 150)],
    "blip": [(740, 35)],
}


def _play(notes):
    for f, ms in notes:
        try:
            winsound.Beep(f, ms)
        except Exception:
            return


def play(name, pitch=0):
    if not ENABLED[0] or winsound is None or name not in TUNES:
        return
    notes = [(f + pitch, ms) for f, ms in TUNES[name]]
    threading.Thread(target=_play, args=(notes,), daemon=True).start()


def set_enabled(on):
    ENABLED[0] = bool(on)
