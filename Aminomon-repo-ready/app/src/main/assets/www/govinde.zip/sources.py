"""Where each component of a pathway is found. One (kind, zone) per step, aligned with the pathway's
'actors' list. The zone must exist in the pathway's home cell (checked by test). Placements follow where
the molecule really works; when it works in the cytosol it is simply listed in the Cytoplasm."""

M, C, N = "Plasma membrane", "Cytoplasm", "Nucleus"
SOURCES = {
    "glycolysis": [("transporter", "Inner membrane"), ("enzyme", C), ("enzyme", C), ("enzyme", C),
                   ("enzyme", C), ("enzyme", C), ("enzyme", C)],
    "lac_operon": [("enzyme", C), ("inducer", C), ("repressor", "Nucleoid"), ("complex", "Nucleoid"),
                   ("enzyme", "Nucleoid"), ("genes", "Nucleoid")],
    "trp_operon": [("repressor", C), ("complex", "Nucleoid"), ("complex", "Ribosomes"), ("ribosome", "Ribosomes"),
                   ("mRNA", "Nucleoid"), ("enzyme", "Nucleoid")],
    "chemotaxis": [("receptor", "Chemoreceptor array"), ("kinase", "Chemoreceptor array"), ("regulator", C),
                   ("complex", "Flagellar motor"), ("enzyme", "Chemoreceptor array"), ("phosphatase", C)],
    "envz_ompr": [("sensor kinase", "Inner membrane"), ("sensor kinase", "Inner membrane"),
                  ("response regulator", C), ("phospho-regulator", C), ("complex", "Nucleoid"),
                  ("porins", "Outer membrane")],
    "sos_response": [("DNA", "Nucleoid"), ("protein", "Nucleoid"), ("complex", "Nucleoid"), ("protein", C),
                     ("genes", "Nucleoid"), ("repair proteins", "Nucleoid")],
    "com_quorum": [("pheromone", "Cell membrane"), ("signal", "Sensor kinases"), ("sensor kinase", "Sensor kinases"),
                   ("response regulator", C), ("complex", "Nucleoid"), ("regulators", C),
                   ("transcription factor", "Nucleoid")],
    "sporulation_phosphorelay": [("kinase", C), ("response regulator", C), ("phosphotransferase", C),
                                 ("response regulator", C), ("transcription factor", "Nucleoid")],
    "light_reactions": [("complex", "Phycobilisomes"), ("carrier", "Thylakoid membranes"),
                        ("complex", "Thylakoid membranes"), ("carrier", "Thylakoid membranes"),
                        ("complex", "Thylakoid membranes"), ("enzyme", "Thylakoid membranes"),
                        ("enzyme", "Thylakoid membranes")],
    "calvin_cycle": [("enzyme", "Carboxysome"), ("enzyme", "Carboxysome"), ("enzyme", C), ("enzyme", C),
                     ("enzymes", C), ("enzyme", C)],
    "kai_clock": [("clock protein", C), ("clock protein", C), ("kinase", "Nucleoid"), ("clock protein", C),
                  ("activity", C), ("clock protein", C)],
    "fermentation": [("substrate", C), ("enzyme", C), ("enzyme", C), ("enzyme", C), ("products", M)],
    "pheromone_mapk": [("receptor", M), ("G protein", M), ("scaffold", M), ("kinases", M),
                       ("kinases", C), ("kinases", C), ("MAP kinase", N)],
    "gcn4_starvation": [("tRNA", C), ("kinase", C), ("kinase complex", C), ("initiation factors", C),
                        ("complex", C), ("transcription factor", N)],
    "upr": [("chaperone", "Endoplasmic reticulum"), ("sensor", "Endoplasmic reticulum"),
            ("enzyme", "Endoplasmic reticulum"), ("enzyme", C), ("mRNA", C), ("transcription factor", N)],
    "autophagy": [("kinase complex", "Vacuole"), ("protein", C), ("kinase", "Vacuole"),
                  ("membrane", "Golgi apparatus"), ("lipidated protein", C), ("vesicle", C),
                  ("enzymes", "Vacuole")],
    "gpcr_camp_pka": [("receptor", M), ("G protein", M), ("complex", M), ("enzyme", M),
                      ("kinase", C), ("complex", N), ("enzyme", C)],
    "rtk_ras_mapk": [("receptor", M), ("kinase", M), ("adaptor", "Cell cortex"),
                     ("GEF", M), ("kinase", C), ("kinases", C), ("MAP kinase", N)],
    "pi3k_akt": [("receptor", M), ("lipid kinase", M), ("lipid signal", M), ("kinase", "Cell cortex"),
                 ("kinase complex", "Cell cortex"), ("kinase", C), ("targets", N)],
    "gpcr_plc_ip3": [("receptor", M), ("G protein", M), ("enzyme", M), ("second messenger", C),
                     ("channel", "Endoplasmic reticulum"), ("kinase", C)],
    "wnt_bcatenin": [("receptor complex", M), ("scaffold", "Cell cortex"), ("complex", C),
                     ("protein", C), ("protein", C), ("transcription factors", N), ("genes", N)],
    "p53_damage": [("kinase", N), ("kinases", N), ("complex", N), ("transcription factor", N),
                   ("complex", N), ("CDK inhibitor", C)],
    "intrinsic_apoptosis": [("proteins", "Mitochondrion"), ("proteins", "Mitochondrion"), ("pores", "Mitochondrion"),
                            ("protein", "Mitochondrion"), ("apoptosome", C), ("proteases", C), ("protease", C)],
    "ubiquitin_proteasome": [("enzyme", C), ("enzyme", C), ("enzyme", C), ("tag", C), ("complex", C),
                             ("complex", N), ("enzymes", C)],
    "glucagon_glycogenolysis": [("receptor", M), ("enzyme", M), ("kinase", C), ("kinase", C),
                                ("kinase", "Glycogen granules"), ("enzyme", "Glycogen granules"),
                                ("enzyme", "Smooth ER")],
    "insulin_glycogen": [("receptor", M), ("receptor", M), ("adaptors", "Cell cortex"), ("lipid kinase", M),
                         ("kinases", M), ("kinase", C), ("enzyme", "Glycogen granules")],
    "srebp_cholesterol": [("sensor complex", "Smooth ER"), ("escort", "Smooth ER"), ("protease", "Golgi apparatus"),
                          ("protease", "Golgi apparatus"), ("transcription factor", N),
                          ("transcription factor", N), ("enzyme", "Smooth ER")],
    "gsis": [("transporter", M), ("enzyme", C), ("metabolism", "Mitochondrion"), ("channel", M), ("channel", M),
             ("channel", M), ("vesicles", "Insulin granules")],
    "synaptic_transmission": [("signal", M), ("channel", "Presynaptic terminal"), ("sensor", "Presynaptic terminal"),
                              ("proteins", "Presynaptic terminal"), ("transmitter", "Presynaptic terminal"),
                              ("receptor", "Postsynaptic spine"), ("clearance", M)],
    "ltp": [("receptor", "Postsynaptic spine"), ("receptor", "Postsynaptic spine"), ("receptor", "NMDA receptors"),
            ("receptor", "NMDA receptors"), ("kinase", "Postsynaptic spine"), ("kinase", "Postsynaptic spine"),
            ("receptors", "Postsynaptic spine")],
    "ec_coupling": [("transmitter", "Sarcolemma"), ("receptor", "Sarcolemma"), ("signal", "Sarcolemma"),
                    ("sensor", "Sarcolemma cortex"), ("channel", "Sarcoplasmic reticulum"),
                    ("Ca2+ sensor", "Sarcomere"), ("motor", "Sarcomere")],
    "lambda_switch": [("signal", C), ("host protein", C), ("repressor", "CI repressor dimers"),
                      ("DNA sites", "Phage genome"), ("enzyme", "Phage genome"), ("repressor", "Phage genome"),
                      ("lysis proteins", C)],
}
# harmless look-alikes sprinkled around so the right one has to be identified
FILLERS = ["Water", "ATP", "NADH", "Mg2+", "Ca2+", "Glucose", "Phosphate", "Chloride", "Proton"]


def components(pid, actors):
    """Unique components of a pathway: list of (name, kind, zone) in order of first use."""
    seen, out = set(), []
    for name, (kind, zone) in zip(actors, SOURCES[pid]):
        if name not in seen:
            seen.add(name)
            out.append((name, kind, zone))
    return out
