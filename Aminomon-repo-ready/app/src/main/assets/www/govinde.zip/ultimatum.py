"""Govinde's Ultimatum: an exam at the end of each stage, built from the Codex text. Only players who
deduced every pathway AND read every Codex page of the stage may take it."""
import random

import cells
import dibujo as d
import logic
import pathways
import quiz
import save
import sound

NAME2PID = {p["name"]: p["id"] for p in pathways.ALL}


def _order_question(p):
    steps, dec = p["steps"], p["decoys"]
    last_free = all(len(steps) - 1 not in g for g in p["parallel"])
    if random.random() < 0.5 or not last_free:
        q, right, pool = f"In '{p['name']}', which event happens FIRST?", steps[0], steps[1:]
    else:
        q, right, pool = f"In '{p['name']}', which event happens LAST?", steps[-1], steps[:-1]
    wrong = random.sample(pool, 2) + [random.choice(dec)]
    return q, right, wrong, None


def build(pids, total, weak=None):
    """Pick the exam questions. Pathways you have been getting wrong are more likely to be included."""
    weak = weak or {}
    questions = []
    for pid in pids:
        p = pathways.PATH[pid]
        questions.append((p["name"], p["note"]["q"], p["note"]["a"], p["note"]["wrong"], None))
    extra = []
    for pid in pids:
        p = pathways.PATH[pid]
        w = p["whatif"]
        extra.append((p["name"], w["q"], w["a"], w["wrong"], w["why"]))
        q, a, wr, why = _order_question(p)
        extra.append((p["name"], q, a, wr, why))
    random.shuffle(extra)
    questions += extra
    random.shuffle(questions)
    questions.sort(key=lambda q: -weak.get(NAME2PID.get(q[0]), 0) * random.random())
    return questions[:total]


def _run(win, j, title, questions, pass_pct):
    score = 0
    for i, (name, q, a, wrong, why) in enumerate(questions, 1):
        ok = quiz.ask(win, f"{title} · {i}/{len(questions)} · {name}", q, a, wrong, why, allow_exit=False)
        score += bool(ok)
        pid = NAME2PID.get(name)
        if pid:
            if ok:
                logic.weak_ok(j, pid)
            else:
                logic.weak_add(j, pid)
        sound.play("good" if ok else "bad")
    need = -(-len(questions) * pass_pct // 100)
    return score, need


def _reward(j):
    logic.gain(j, {m: 2 for m in cells.MATERIALS})
    logic.refill(j)


def stage_ultimatum(win, j, stage):
    """Returns True if the player passed."""
    st = cells.STAGES[stage]
    if stage in j["ultimatums"]:
        d.popup(win, f"You already passed this Ultimatum. Title earned: {st['title']}.", "Govinde")
        return False
    block = logic.ultimatum_blockers(j, stage)
    if block:
        d.popup(win, "Govinde is not ready to test you yet.\n\n" + "\n".join("• " + b for b in block),
                "Govinde's Ultimatum", ancho=84, attr=d.c("mal"))
        return False
    pids = pathways.stage_paths(stage)
    total = max(8, min(14, len(pids) * 2))
    need = -(-total * st["pass_pct"] // 100)
    if d.menu(win, f"{st['name']}: Govinde's Ultimatum", ["Begin the Ultimatum", "Not yet"],
              ayuda=f"{total} questions, you need {need} correct. No hints.") != 0:
        return False
    score, need = _run(win, j, "Ultimatum", build(pids, total, j["weak"]), st["pass_pct"])
    save.count(j, "ultimatums_taken")
    if score >= need:
        j["ultimatums"].append(stage)
        _reward(j)
        save.write(j)
        nxt = cells.GOVINDE["stage_start"].get(stage + 1)
        msg = f"{score}/{total}. PASSED!\n\nTitle earned: {st['title']}.\nReward: +2 of every material."
        if nxt:
            msg += "\n\n" + nxt + f"\nNew cells can now be unlocked in {cells.STAGES[stage + 1]['name']}."
        d.popup(win, msg, "Govinde's Ultimatum", ancho=70, attr=d.c("bien"))
        return True
    save.write(j)
    d.popup(win, f"{score}/{total}. You needed {need}.\n\nGo back to the Codex: the questions come from "
                 "what you read. You can retry any time.", "Govinde's Ultimatum", ancho=64, attr=d.c("mal"))
    return False


def grand_ultimatum(win, j):
    if j["final"]:
        d.popup(win, "You already completed the Govinde Protocol. Well done.", "Govinde")
        return False
    block = logic.final_blockers(j)
    allp = [p["id"] for p in pathways.ALL]
    unread = [p for p in allp if logic.pages_read(j, p) < 3]
    if unread:
        block.append(f"{len(unread)} pathways still have unread Codex pages")
    if block:
        d.popup(win, "The Grand Ultimatum opens when every stage Ultimatum is passed and the whole Codex "
                     "is read.\n\n" + "\n".join("• " + b for b in block), "Govinde's Grand Ultimatum",
                ancho=80, attr=d.c("mal"))
        return False
    total, pct = 20, cells.FINAL["pass_pct"]
    need = -(-total * pct // 100)
    if d.menu(win, cells.FINAL["name"], ["Begin", "Not yet"],
              ayuda=f"{total} questions from every pathway, you need {need}.") != 0:
        return False
    pick = random.sample(allp, total)
    qs = []
    for pid in pick:
        p = pathways.PATH[pid]
        if random.random() < 0.5:
            qs.append((p["name"], p["note"]["q"], p["note"]["a"], p["note"]["wrong"], None))
        else:
            w = p["whatif"]
            qs.append((p["name"], w["q"], w["a"], w["wrong"], w["why"]))
    score, need = _run(win, j, "Grand Ultimatum", qs, pct)
    if score >= need:
        j["final"] = True
        save.write(j)
        d.dialogo(win, [f"{score}/{total}. PASSED!"] + cells.GOVINDE["ending"], "Govinde")
        return True
    d.popup(win, f"{score}/{total}. You needed {need}. Review the Codex and try again.",
            "Govinde's Grand Ultimatum", attr=d.c("mal"))
    return False
