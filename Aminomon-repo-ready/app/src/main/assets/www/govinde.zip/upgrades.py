"""Organelle upgrades hidden in the cells. Each one has limited charges: it fades when they run out and a
new organelle grows back in its cell so you can restore it. Every upgrade can be switched on and off."""

UPGRADES = {
    "flagellum": dict(name="Flagellum", cell="ecoli", pos=(-12, 5), max=150, unit="boosted steps",
                      text="Press V to swim twice as fast. Each boosted step uses a charge.", start_on=False),
    "ribosome": dict(name="Ribosome", cell="bacillus", pos=(-12, 3), max=6, unit="harvests",
                     text="Harvests give +1 extra of each material."),
    "chloroplast": dict(name="Chloroplast", cell="cyano", pos=(-9, 3), max=12, unit="pickups",
                        text="Material pickups give 2 instead of 1."),
    "mitochondrion": dict(name="Mitochondrion", cell="yeast", pos=(10, 4), max=6, unit="extra harvests",
                          text="Each pathway can be harvested one extra time."),
    "chaperone": dict(name="Chaperone", cell="fibroblast", pos=(-12, 4), max=3, unit="deductions",
                      text="You get one extra life in a deduction that has lives."),
    "receptor": dict(name="Extra receptor", cell="hepatocyte", pos=(10, -3), max=5, unit="hints",
                     text="A hint during a deduction costs no Insight."),
    "vesicle": dict(name="Secretory vesicle", cell="beta_cell", pos=(-10, -3), max=4, unit="stressors",
                    text="Answering a stressor gives double rewards."),
}
FADED = []          # names of upgrades that just ran out (the screen shows a message)


def owned(j, uid):
    return uid in j["upgrades"]


def charges(j, uid):
    return j["charges"].get(uid, 0) if owned(j, uid) else 0


def is_on(j, uid):
    return j["active"].get(uid, UPGRADES[uid].get("start_on", True))


def active(j, uid):
    """Owned, switched on and still charged."""
    return owned(j, uid) and is_on(j, uid) and charges(j, uid) > 0


def use(j, uid, n=1):
    if not owned(j, uid):
        return
    j["charges"][uid] = max(0, j["charges"].get(uid, 0) - n)
    if j["charges"][uid] == 0:
        FADED.append(UPGRADES[uid]["name"])


def chest_visible(j, uid):
    """The organelle is there to be found, or has grown back after fading."""
    return charges(j, uid) == 0


def collect(j, uid):
    """Returns True if it was found for the first time."""
    first = not owned(j, uid)
    if first:
        j["upgrades"].append(uid)
    j["charges"][uid] = UPGRADES[uid]["max"]
    j["active"].setdefault(uid, UPGRADES[uid].get("start_on", True))
    return first


def toggle(j, uid):
    j["active"][uid] = not is_on(j, uid)
    return j["active"][uid]


# kept for older callers
has = active
