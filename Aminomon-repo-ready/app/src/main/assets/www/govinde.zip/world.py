"""The world map. Cells are large ellipses with layered envelopes and many organelles; the extracellular
matrix joins them through plazas and corridors; membrane gates, pathway stations, Govinde, quests,
organelle chests and raw-material pickups are placed on top. Everything is designed in small 'design
units' and scaled up here, so the geometry stays proportionate."""
import random
from collections import deque

import cells
import pathways
import bosses
import quests
import upgrades

KX, KY = 2.5, 1.75


def sx(v):
    return int(round(v * KX))


def sy(v):
    return int(round(v * KY))


def zx_(v):
    return int(round(v * 1.6))


def zy_(v):
    return int(round(v * 1.3))


W, H = sx(232) + 4, sy(110) + 4
WALL, VOID, FLOOR, BAND, ECM = "█", " ", "·", "◦", "▒"

PERI = ("≈", "Periplasm")
PEPT = ("≡", "Peptidoglycan layer")
MEMB = ("◦", "Inner membrane")

# cell: centre, radii, envelope layers (outermost first; the first one is the solid wall),
# zones (name, glyph, (dx, dy, rx, ry)) and the offsets of the pathway stations
DESIGN = {
    "ecoli": dict(c=(22, 22), r=(19, 8),
                  layers=[(WALL, "Outer membrane"), PERI, MEMB],
                  zones=[("Nucleoid", "§", (0, 0, 8, 3)), ("Plasmid", "°", (-9, -3, 1, 1)),
                         ("Plasmid", "°", (10, 3, 1, 1)), ("Ribosomes", "÷", (-11, -4, 3, 1)),
                         ("Ribosomes", "÷", (-12, 4, 3, 1)), ("Ribosomes", "÷", (12, -4, 3, 1)),
                         ("Ribosomes", "÷", (11, 4, 3, 1)), ("Storage granules", "●", (-6, 5, 2, 1)),
                         ("Storage granules", "●", (5, -5, 2, 1)),
                         ("Flagellar motor", "☼", (-17, 3, 1, 1)), ("Chemoreceptor array", "▪", (16, 0, 1, 2))],
                  stations={"glycolysis": (-10, 0), "lac_operon": (-3, -2), "trp_operon": (3, -2),
                            "chemotaxis": (14, 1), "envz_ompr": (8, 6), "sos_response": (0, 2)}),
    "bacillus": dict(c=(98, 10), r=(17, 6), layers=[(WALL, "Cell wall"), PEPT, ("◦", "Cell membrane")],
                     zones=[("Nucleoid", "§", (-2, 0, 7, 2)), ("Forespore", "●", (11, 0, 4, 3)),
                            ("Ribosomes", "÷", (-10, -3, 3, 1)), ("Ribosomes", "÷", (-10, 3, 3, 1)),
                            ("Sensor kinases", "▪", (-14, 0, 1, 2)), ("Storage granules", "●", (3, 4, 2, 0))],
                     stations={"com_quorum": (-12, -1), "sporulation_phosphorelay": (7, 2)}),
    "cyano": dict(c=(98, 34), r=(17, 6), layers=[(WALL, "Outer membrane"), PERI, ("◦", "Plasma membrane")],
                  zones=[("Thylakoid membranes", "═", (-2, -2, 11, 1)), ("Thylakoid membranes", "═", (-2, 2, 11, 1)),
                         ("Carboxysome", "▓", (11, 0, 3, 2)), ("Nucleoid", "§", (-13, 0, 3, 2)),
                         ("Phycobilisomes", "▪", (-2, -4, 9, 0)), ("Ribosomes", "÷", (-2, 4, 6, 0))],
                  stations={"light_reactions": (-6, 0), "calvin_cycle": (8, 3), "kai_clock": (-13, 0)}),
    "yeast": dict(c=(174, 22), r=(17, 7), layers=[(WALL, "Cell wall"), ("◦", "Plasma membrane")],
                  zones=[("Endoplasmic reticulum", "░", (-3, -1, 10, 5)), ("Nucleus", "§", (-3, -1, 6, 3)),
                         ("Vacuole", "●", (10, 2, 4, 3)), ("Mitochondrion", "☼", (-12, 4, 2, 1)),
                         ("Mitochondrion", "☼", (11, -4, 2, 1)), ("Mitochondrion", "☼", (4, 5, 2, 1)),
                         ("Golgi apparatus", "═", (5, -5, 3, 1)), ("Spindle pole body", "▪", (-3, -5, 1, 0))],
                  stations={"fermentation": (-14, 1), "pheromone_mapk": (13, -3), "gcn4_starvation": (-8, 5),
                            "upr": (-11, -1), "autophagy": (9, 3)}),
    "fibroblast": dict(c=(174, 70), r=(18, 8), layers=[(WALL, "Plasma membrane"), ("◦", "Cell cortex")],
                       zones=[("Endoplasmic reticulum", "░", (-5, 0, 11, 6)), ("Nucleus", "§", (-5, 0, 6, 4)),
                              ("Golgi apparatus", "═", (9, -4, 4, 1)), ("Mitochondrion", "☼", (11, 3, 3, 1)),
                              ("Mitochondrion", "☼", (-13, 5, 2, 1)), ("Lysosome", "●", (14, -2, 1, 1)),
                              ("Focal adhesions", "▪", (-16, 0, 1, 3)), ("Centrosome", "▪", (1, -5, 1, 1)),
                              ("Microtubules", "─", (4, 6, 6, 0)), ("Peroxisome", "°", (11, 6, 1, 1))],
                       stations={"gpcr_camp_pka": (-15, -2), "rtk_ras_mapk": (-15, 3), "pi3k_akt": (-10, 5),
                                 "gpcr_plc_ip3": (-10, -5), "wnt_bcatenin": (4, -6), "p53_damage": (-5, 0),
                                 "intrinsic_apoptosis": (11, 3), "ubiquitin_proteasome": (12, -2)}),
    "hepatocyte": dict(c=(130, 50), r=(14, 6), layers=[(WALL, "Plasma membrane"), ("◦", "Cell cortex")],
                       zones=[("Glycogen granules", "●", (-5, 2, 3, 2)), ("Smooth ER", "░", (6, 0, 5, 3)),
                              ("Nucleus", "§", (0, -2, 3, 1)), ("Mitochondrion", "☼", (8, -3, 2, 1)),
                              ("Peroxisome", "°", (-4, -3, 1, 1)), ("Lipid droplets", "●", (3, 3, 2, 1)),
                              ("Golgi apparatus", "═", (-2, 4, 3, 0))],
                       stations={"glucagon_glycogenolysis": (-10, -2), "insulin_glycogen": (-10, 2),
                                 "srebp_cholesterol": (6, 0)}),
    "beta_cell": dict(c=(90, 72), r=(14, 6), layers=[(WALL, "Plasma membrane"), ("◦", "Cell cortex")],
                      zones=[("Insulin granules", "●", (6, 1, 5, 3)), ("Nucleus", "§", (-3, -2, 4, 2)),
                             ("Endoplasmic reticulum", "░", (-5, 3, 3, 1)), ("Golgi apparatus", "═", (2, -4, 3, 0)),
                             ("Mitochondrion", "☼", (-11, 2, 1, 1))],
                      stations={"gsis": (-9, 1)}),
    "neuron": dict(c=(88, 96), r=(14, 6), layers=[(WALL, "Plasma membrane"), ("◦", "Cell cortex")],
                   zones=[("Presynaptic terminal", "●", (-9, 0, 3, 3)), ("Postsynaptic spine", "◦", (9, 0, 3, 3)),
                          ("Nucleus", "§", (0, -2, 3, 2)), ("Microtubule track", "─", (0, 3, 7, 0)),
                          ("NMDA receptors", "▪", (12, 0, 0, 2))],
                   stations={"synaptic_transmission": (-6, 0), "ltp": (6, 0)}),
    "muscle": dict(c=(130, 96), r=(16, 6), layers=[(WALL, "Sarcolemma"), ("◦", "Sarcolemma cortex")],
                   zones=[("Sarcomere", "║", (-12, 0, 0, 4)), ("Sarcomere", "║", (-6, 0, 0, 4)),
                          ("Sarcomere", "║", (0, 0, 0, 4)), ("Sarcomere", "║", (6, 0, 0, 4)),
                          ("Sarcomere", "║", (12, 0, 0, 4)), ("Sarcoplasmic reticulum", "░", (-3, 3, 10, 1)),
                          ("Mitochondrion", "☼", (-14, 3, 1, 1)), ("Mitochondrion", "☼", (14, -3, 1, 1)),
                          ("Nucleus", "§", (-14, -3, 1, 1))],
                   stations={"ec_coupling": (-3, 1)}),
    "phage": dict(c=(214, 96), r=(13, 6), layers=[(WALL, "Capsid shell"), ("◦", "Inner shell")],
                  zones=[("Phage genome", "§", (-1, 0, 6, 2)), ("Tail fibres", "═", (-10, 0, 2, 0)),
                         ("Capsid head proteins", "▓", (6, -3, 3, 0)), ("CI repressor dimers", "▪", (5, 3, 2, 0))],
                  stations={"lambda_switch": (5, 0)}),
}
PLAZA_DESIGN = {
    "ecm1": ((60, 22), (9, 6), "Extracellular matrix I"),
    "ecm2": ((136, 22), (9, 6), "Extracellular matrix II"),
    "ecm3": ((174, 46), (9, 5), "Extracellular matrix III"),
    "ecm4": ((130, 72), (10, 7), "Extracellular matrix IV"),
    "ecm5": ((174, 96), (11, 6), "The Basement Membrane"),
}
JUNCTIONS = {"J1": (75, 22), "J2": (122, 22), "J3": (124, 84)}
# gate id: (cell, side of the cell, mode). "in": entering needs the cell unlocked; "out": leaving needs it solved
GATE_DEF = {
    "g_ecoli_out": ("ecoli", "E", "out"),
    "g_bacillus_in": ("bacillus", "W", "in"), "g_bacillus_out": ("bacillus", "E", "out"),
    "g_cyano_in": ("cyano", "W", "in"), "g_cyano_out": ("cyano", "E", "out"),
    "g_yeast_in": ("yeast", "W", "in"), "g_yeast_out": ("yeast", "S", "out"),
    "g_fibroblast_in": ("fibroblast", "N", "in"), "g_fibroblast_out": ("fibroblast", "W", "out"),
    "g_hepatocyte_in": ("hepatocyte", "S", "in"), "g_beta_cell_in": ("beta_cell", "E", "in"),
    "g_muscle_in": ("muscle", "N", "in"), "g_neuron_in": ("neuron", "N", "in"),
    "g_muscle_out": ("muscle", "E", "out"), "g_phage_in": ("phage", "W", "in"),
}
LINKS = [("g_ecoli_out", "ecm1", "hv"), ("ecm1", "J1", "hv"), ("J1", "g_bacillus_in", "vh"),
         ("J1", "g_cyano_in", "vh"), ("g_bacillus_out", "J2", "hv"), ("g_cyano_out", "J2", "hv"),
         ("J2", "ecm2", "hv"), ("ecm2", "g_yeast_in", "hv"), ("g_yeast_out", "ecm3", "vh"),
         ("ecm3", "g_fibroblast_in", "vh"), ("g_fibroblast_out", "ecm4", "hv"),
         ("ecm4", "g_hepatocyte_in", "vh"), ("ecm4", "g_beta_cell_in", "hv"), ("ecm4", "g_muscle_in", "vh"),
         ("ecm4", "J3", "vh"), ("J3", "g_neuron_in", "hv"), ("g_muscle_out", "ecm5", "hv"),
         ("ecm5", "g_phage_in", "hv")]
NPC_STAGE = {"ecm1": 1, "ecm2": 2, "ecm3": 3, "ecm4": 4, "ecm5": 5}

INFO = {
    "Nucleoid": "The bacterial chromosome, a single folded loop of DNA with no nuclear membrane.",
    "Plasmid": "A small circular DNA that can carry extra genes, such as resistance.",
    "Ribosomes": "Protein factories. Bacterial ribosomes are 70S.",
    "Storage granules": "Reserves of glycogen, polyphosphate or lipid.",
    "Flagellar motor": "A rotary motor in the envelope that spins the flagellum.",
    "Chemoreceptor array": "Receptor clusters at the cell pole that sense attractants and repellents.",
    "Outer membrane": "Gram-negative outer barrier with lipopolysaccharide.",
    "Periplasm": "The compartment between the two membranes, with a thin peptidoglycan wall.",
    "Inner membrane": "The plasma membrane: transporters, sensor kinases and the electron transport chain.",
    "Cell wall": "A rigid layer that protects the cell and resists osmotic pressure.",
    "Peptidoglycan layer": "The thick cross-linked sugar and peptide mesh of Gram-positive bacteria.",
    "Cell membrane": "The single plasma membrane of a Gram-positive cell.",
    "Plasma membrane": "The cell's boundary, full of receptors, channels and pumps.",
    "Forespore": "The developing endospore that Bacillus builds when starving.",
    "Sensor kinases": "Membrane histidine kinases that start two-component signalling.",
    "Thylakoid membranes": "Internal membrane stacks where the light reactions run.",
    "Carboxysome": "A protein shell packed with RuBisCO that concentrates CO2.",
    "Phycobilisomes": "Antenna complexes that harvest light for photosystem II.",
    "Endoplasmic reticulum": "Membrane network that folds proteins and stores calcium.",
    "Nucleus": "Holds the chromosomes and is where many signals end by changing gene expression.",
    "Vacuole": "Storage and recycling compartment, the yeast lysosome.",
    "Mitochondrion": "Makes most ATP and holds the cytochrome c that triggers apoptosis.",
    "Golgi apparatus": "Sorts and modifies proteins for secretion or other organelles.",
    "Spindle pole body": "The yeast microtubule-organising centre.",
    "Lysosome": "Acidic compartment that digests worn-out material.",
    "Focal adhesions": "Integrin clusters where the cell grips the matrix and signals inward.",
    "Centrosome": "The animal microtubule-organising centre.",
    "Microtubules": "Tracks for transport of vesicles and organelles.",
    "Peroxisome": "Breaks down fatty acids and hydrogen peroxide.",
    "Cell cortex": "The actin-rich layer just under the plasma membrane.",
    "Glycogen granules": "The liver's stored glucose.",
    "Smooth ER": "Makes lipids and detoxifies drugs.",
    "Lipid droplets": "Fat stores bounded by a single lipid layer.",
    "Insulin granules": "Secretory vesicles loaded with insulin, released on a calcium signal.",
    "Presynaptic terminal": "Releases neurotransmitter from vesicles.",
    "Postsynaptic spine": "Receives the signal with glutamate receptors.",
    "Microtubule track": "Carries vesicles toward the terminal.",
    "NMDA receptors": "Receptors that need glutamate and depolarisation, key to LTP.",
    "Sarcomere": "The contractile unit of muscle, built from actin and myosin.",
    "Sarcoplasmic reticulum": "Muscle calcium store opened by ryanodine receptors.",
    "Sarcolemma": "The muscle fibre's plasma membrane.",
    "Sarcolemma cortex": "The layer just under the sarcolemma, with dystrophin and the T-tubule openings.",
    "Capsid shell": "The protein head of the phage that holds its DNA.",
    "Phage genome": "Lambda's 48.5 kb DNA, with the CI/Cro switch.",
    "Tail fibres": "Fibres that recognise and grab the host.",
    "Capsid head proteins": "Proteins that assemble the head of new phage.",
    "CI repressor dimers": "Hold the lysogenic state by covering OR1 and OR2.",
    "Inner shell": "The inner lining of the capsid.",
}


def _scaled():
    geo = {}
    for cid, g in DESIGN.items():
        (cx, cy), (rx, ry) = g["c"], g["r"]
        geo[cid] = dict(
            c=(sx(cx), sy(cy)), r=(sx(rx), sy(ry)), layers=g["layers"], band=g["layers"][-1][1],
            zones=[(n, gl, (sx(dx), sy(dy), zx_(zx), zy_(zy))) for n, gl, (dx, dy, zx, zy) in g["zones"]],
            stations={p: (sx(dx), sy(dy)) for p, (dx, dy) in g["stations"].items()})
    return geo


GEO = _scaled()
PLAZAS = {pid: dict(c=(sx(c[0]), sy(c[1])), r=(sx(r[0]), sy(r[1])), name=n)
          for pid, (c, r, n) in PLAZA_DESIGN.items()}
NPCS = {PLAZAS[p]["c"]: s for p, s in NPC_STAGE.items()}
START = (GEO["ecoli"]["c"][0] + sx(0), GEO["ecoli"]["c"][1] + sy(5))


def _inside(x, y, cx, cy, rx, ry):
    if rx <= 0 and ry <= 0:
        return x == cx and y == cy
    if rx <= 0:
        return x == cx and abs(y - cy) <= ry
    if ry <= 0:
        return y == cy and abs(x - cx) <= rx
    return ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0


def gate_tile(cid, side):
    (cx, cy), (rx, ry) = GEO[cid]["c"], GEO[cid]["r"]
    return {"E": (cx + rx, cy), "W": (cx - rx, cy), "N": (cx, cy - ry), "S": (cx, cy + ry)}[side]


GATES = [dict(id=gid, t=gate_tile(cid, side), cell=cid, mode=mode) for gid, (cid, side, mode) in GATE_DEF.items()]


class World:
    def __init__(self):
        self.g = [[VOID] * W for _ in range(H)]          # glyph
        self.region = [[None] * W for _ in range(H)]     # cell / plaza / corridor id
        self.zone = [[""] * W for _ in range(H)]         # name of the place
        self.stations, self.npcs, self.gates, self.pickups = {}, {}, {}, {}
        self.names = {}
        self._cells()
        self._plazas()
        self._corridors()
        self._gates()
        self._stations()
        self._pickups()
        self._extras()

    # ------------------------------------------------------------ building
    def _cells(self):
        for cid, geo in GEO.items():
            (cx, cy), (rx, ry) = geo["c"], geo["r"]
            layers = geo["layers"]
            self.names[cid] = cells.CELLS[cid]["name"]
            for y in range(cy - ry, cy + ry + 1):
                for x in range(cx - rx, cx + rx + 1):
                    if not _inside(x, y, cx, cy, rx, ry):
                        continue
                    self.region[y][x] = cid
                    for k, (glyph, name) in enumerate(layers):
                        if not _inside(x, y, cx, cy, rx - (k + 1), ry - (k + 1)):
                            self.g[y][x], self.zone[y][x] = glyph, name
                            break
                    else:
                        self.g[y][x], self.zone[y][x] = FLOOR, "Cytoplasm"
            for name, glyph, (dx, dy, zx, zy) in geo["zones"]:
                for y in range(cy + dy - zy, cy + dy + zy + 1):
                    for x in range(cx + dx - zx, cx + dx + zx + 1):
                        if (0 <= x < W and 0 <= y < H and self.region[y][x] == cid
                                and self.g[y][x] not in (WALL, VOID, BAND, "◦", "≈", "≡")
                                and _inside(x, y, cx + dx, cy + dy, zx, zy)):
                            self.g[y][x], self.zone[y][x] = glyph, name

    def _plazas(self):
        for pid, p in PLAZAS.items():
            (cx, cy), (rx, ry) = p["c"], p["r"]
            self.names[pid] = p["name"]
            for y in range(cy - ry, cy + ry + 1):
                for x in range(cx - rx, cx + rx + 1):
                    if _inside(x, y, cx, cy, rx, ry) and self.g[y][x] == VOID:
                        self.g[y][x], self.region[y][x], self.zone[y][x] = ECM, pid, p["name"]

    def _node(self, name):
        if name in JUNCTIONS:
            return sx(JUNCTIONS[name][0]), sy(JUNCTIONS[name][1])
        if name in PLAZAS:
            return PLAZAS[name]["c"]
        cid, side, _ = GATE_DEF[name]
        return gate_tile(cid, side)

    def _carve(self, a, b, rid):
        (x1, y1), (x2, y2) = a, b
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for ox in range(-1, 2):
                    for oy in range(-1, 2):
                        if (x1 == x2 and oy) or (y1 == y2 and ox):
                            continue
                        xx, yy = x + ox, y + oy
                        if 0 <= xx < W and 0 <= yy < H and self.g[yy][xx] == VOID:
                            self.g[yy][xx], self.region[yy][xx] = ECM, rid
                            self.zone[yy][xx] = "Extracellular matrix"

    def _corridors(self):
        for n, (a, b, order) in enumerate(LINKS):
            (x1, y1), (x2, y2) = self._node(a), self._node(b)
            rid = f"corr{n}"
            mid = (x1, y2) if order == "vh" else (x2, y1)
            self._carve((x1, y1), mid, rid)
            self._carve(mid, (x2, y2), rid)

    def _gates(self):
        for gd in GATES:
            x, y = gd["t"]
            self.g[y][x] = "╬"
            self.gates[(x, y)] = gd
            self.zone[y][x] = "Membrane gate"

    def _stations(self):
        for cid, geo in GEO.items():
            cx, cy = geo["c"]
            for pid, (dx, dy) in geo["stations"].items():
                self.stations[(cx + dx, cy + dy)] = pid
        for pos, stage in NPCS.items():
            self.npcs[pos] = stage

    def _pickups(self):
        rng = random.Random(7)
        for cid, geo in GEO.items():
            (cx, cy), (rx, ry) = geo["c"], geo["r"]
            spots = [(x, y) for y in range(cy - ry + 2, cy + ry - 1) for x in range(cx - rx + 2, cx + rx - 1)
                     if self.region[y][x] == cid and self.g[y][x] not in (WALL, VOID, BAND, "◦", "≈", "≡")
                     and (x, y) not in self.stations]
            rng.shuffle(spots)
            for i, pos in enumerate(spots[:14]):
                self.pickups[pos] = (cid, i)

    def _extras(self):
        self.quests, self.chests, self.spawn, self.bosses = {}, {}, {}, {}
        for b in bosses.BOSSES:
            cx, cy = GEO[b["cell"]]["c"]
            self.bosses[(cx + sx(b["pos"][0]), cy + sy(b["pos"][1]))] = b["id"]
        for q in quests.QUESTS:
            cx, cy = GEO[q["cell"]]["c"]
            self.quests[(cx + sx(q["pos"][0]), cy + sy(q["pos"][1]))] = q["id"]
        for uid, u in upgrades.UPGRADES.items():
            cx, cy = GEO[u["cell"]]["c"]
            self.chests[(cx + sx(u["pos"][0]), cy + sy(u["pos"][1]))] = uid
        solid = set(self.stations) | set(self.quests) | set(self.chests) | set(self.bosses)
        for cid, geo in GEO.items():
            cx, cy = geo["c"]
            best = None
            for y in range(cy - 4, cy + 5):
                for x in range(cx - 12, cx + 13):
                    if self.region[y][x] == cid and self.g[y][x] == FLOOR and (x, y) not in solid \
                            and all(n not in solid for n in self.neighbours(x, y)):
                        dd = abs(x - cx) + 2 * abs(y - cy)
                        if best is None or dd < best[0]:
                            best = (dd, (x, y))
            self.spawn[cid] = best[1] if best else (cx, cy)
        for pid, p in PLAZAS.items():
            cx, cy = p["c"]
            self.spawn[pid] = (cx + 3, cy + 2)

    # ------------------------------------------------------------- queries
    def walkable(self, x, y):
        return 0 <= x < W and 0 <= y < H and self.g[y][x] not in (VOID, WALL)

    def region_at(self, x, y):
        return self.region[y][x] if 0 <= x < W and 0 <= y < H else None

    def place_name(self, x, y):
        r = self.region[y][x]
        if r in GEO:
            return f"{self.names[r]} · {self.zone[y][x]}"
        return self.zone[y][x] or ""

    def neighbours(self, x, y):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            yield x + dx, y + dy

    def path(self, start, goal, blocked=()):
        """Shortest walkable route (tiles after the start). Stations, quests and NPCs are only entered as the
        goal. Gate rules are checked while walking, not here."""
        if start == goal:
            return []
        solid = set(self.stations) | set(self.npcs) | set(self.quests) | set(self.bosses)
        q, prev = deque([start]), {start: None}
        while q:
            cur = q.popleft()
            if cur == goal:
                break
            for n in self.neighbours(*cur):
                if n in prev or not self.walkable(*n) or (n in solid and n != goal) or n in blocked:
                    continue
                prev[n] = cur
                q.append(n)
        if goal not in prev:
            return []
        out, n = [], goal
        while n != start:
            out.append(n)
            n = prev[n]
        return out[::-1]


def validate(w):
    """Every station, NPC, pickup, quest, chest and gate must be reachable from the start."""
    q, seen = deque([START]), {START}
    solid = set(w.stations) | set(w.npcs) | set(w.quests) | set(w.bosses)
    while q:
        cur = q.popleft()
        for n in w.neighbours(*cur):
            if n in seen or not w.walkable(*n) or n in solid:
                continue
            seen.add(n)
            q.append(n)
    problems = []
    marks = list(w.stations) + list(w.npcs) + list(w.quests) + list(w.chests) + list(w.bosses)
    if len(marks) != len(set(marks)):
        problems.append("two special tiles share a position")
    for pos, pid in w.stations.items():
        if not w.walkable(*pos):
            problems.append(f"station {pid} on a blocked tile {pos}")
        elif not any(n in seen for n in w.neighbours(*pos)):
            problems.append(f"station {pid} unreachable {pos}")
    for pos, st in w.npcs.items():
        if not any(n in seen for n in w.neighbours(*pos)):
            problems.append(f"npc {st} unreachable {pos}")
    for pos in w.pickups:
        if pos not in seen:
            problems.append(f"pickup unreachable {pos}")
    for pos, gd in w.gates.items():
        if pos not in seen:
            problems.append(f"gate {gd['id']} unreachable {pos}")
    for pos, qid in w.quests.items():
        if not w.walkable(*pos) or not any(n in seen for n in w.neighbours(*pos)):
            problems.append(f"quest {qid} blocked/unreachable {pos}")
    for pos, bid in w.bosses.items():
        if not w.walkable(*pos) or not any(n in seen for n in w.neighbours(*pos)):
            problems.append(f"boss {bid} blocked/unreachable {pos}")
    for pos, uid in w.chests.items():
        if pos not in seen:
            problems.append(f"chest {uid} unreachable/blocked {pos}")
    for k, pos in w.spawn.items():
        if pos not in seen:
            problems.append(f"spawn {k} unreachable {pos}")
    allp = {p for geo in GEO.values() for p in geo["stations"]}
    if allp != {p["id"] for p in pathways.ALL}:
        problems.append(f"station/pathway mismatch {allp ^ {p['id'] for p in pathways.ALL}}")
    for cid, geo in GEO.items():
        if set(geo["stations"]) != set(cells.CELLS[cid]["order"]):
            problems.append(f"{cid} stations differ from cell order")
        for name, _, _ in geo["zones"]:
            if name not in INFO:
                problems.append(f"no info text for {name}")
        for _, name in geo["layers"]:
            if name not in INFO:
                problems.append(f"no info text for {name}")
    if not w.walkable(*START):
        problems.append("start blocked")
    return problems


if __name__ == "__main__":
    import time
    t = time.time()
    w = World()
    print(W, H, round(time.time() - t, 2), "s")
    print(validate(w) or "world OK")
